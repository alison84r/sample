﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AABB;
using FemAutomation.ConfigFilesReadingHelper;
using NXOpen;
using NXOpen.Assemblies;
using NXOpen.CAE;
using NXOpen.CAE.Xyplot;
using NXOpen.Features;
using NXOpen.GeometricUtilities;
using NXOpen.UF;
using NXOpen.Utilities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using BodyCollection = NXOpen.CAE.BodyCollection;
using Operation = AABB.Operation;
using Parallel = System.Threading.Tasks.Parallel;
using Plane = NXOpen.Plane;

namespace FemAutomation
{
    public class NxHelper
    {
        public Logger Log = new Logger("NxHelper");
        private SessionData _sessionData;
        public Random randomInt;
        
        public Dictionary<double, double> FastenersSizes = new Dictionary<double, double>
        {
            {5.5, 10.0},
            {6.0, 10.0},
            {7.0,12.5},
            {9.0,17.475},
            {11.0,20.625},
            {13.5,26.975},
            {15.5,29.36},
            {17.5,33.325},
            {22.0,37.313}
        };
        //private readonly List<FastenerStandardPart> _fastenerStandardParts;
        public NxHelper(SessionData sessionData)
        {
            _sessionData = sessionData;
            randomInt = new Random();
            //_fastenerStandardParts = new List<FastenerStandardPart>(0);
            //_fastenerStandardParts.AddRange(iFastenerStandardParts);
        }

        /// <summary>
        /// Creating the FEM Simulation file.
        /// </summary>
        public Part CreateFemSimulationSolution(out FemPart oFemPart, out SimPart oSimPart)
        {
            //_sessionData.TheSession.ApplicationSwitchImmediate("UG_APP_SFEM");
            var baseTemplateManager1 = _sessionData.TheSession.XYPlotManager.TemplateManager;
            oFemPart = null;
            oSimPart = null;
            Part idealizedPart = null;
            try
            {
                Part partsDisplay = _sessionData.TheSession.Parts.Display;
                if (partsDisplay != null)
                {
                    string partsDisplayName = partsDisplay.Name;
                    string partsDisplayFullPath = partsDisplay.FullPath;
                    FileInfo fileInfo = new FileInfo(partsDisplayFullPath);
                    string directoryFullPath = fileInfo.DirectoryName; // contains "C:\MyDirectory"


                    string partName = Path.GetFileNameWithoutExtension(partsDisplayFullPath);
                    string femPartName = partName + "_fem1.fem";
                    if (directoryFullPath != null)
                    {
                        string femPartFullPath = Path.Combine(directoryFullPath, femPartName);
                        if (File.Exists(femPartFullPath))
                        {
                            File.Delete(femPartFullPath);
                        }
                        BasePart basePart1 =
                            _sessionData.TheSession.Parts.NewBaseDisplay(femPartFullPath,
                                BasePart.Units.Millimeters);

                        //workPart = null;
                        //displayPart = null;
                        FemPart workFemPart = ((FemPart)_sessionData.TheSession.Parts.BaseWork);
                        FemPart displayFemPart = ((FemPart)_sessionData.TheSession.Parts.BaseDisplay);
                        FemPart femPart1 = workFemPart;
                        femPart1.PolygonGeometryMgr.SetPolygonBodyResolutionOnFemBodies(PolygonGeometryManager.PolygonBodyResolutionType.Standard);

                        FemPart femPart2 = workFemPart;
                        FemCreationOptions femCreationOptions1 = femPart2.NewFemCreationOptions();
                        

                        FemPart femPart3 = workFemPart;
                        FemSynchronizeOptions femSynchronizeOptions1 = femPart3.NewFemSynchronizeOptions();

                        Part part1 = partsDisplay;
                        string femIdealPartName = partName + "_fem1_i.fem";
                        string femIdealPartFullPath = Path.Combine(directoryFullPath, femIdealPartName);
                        if (File.Exists(femIdealPartFullPath))
                        {
                            File.Delete(femIdealPartFullPath);
                        }
                        femCreationOptions1.SetCadData(part1, femIdealPartFullPath);


                        femCreationOptions1.SetLayerVisibilityOptions(FemCreationOptions.LayerVisibilityOption
                            .Part);

                        femCreationOptions1.SetSolverOptions("NX NASTRAN", "Structural",
                            BaseFemPart.AxisymAbstractionType.None);

                        string[] description1 = new string[0];
                        femCreationOptions1.SetDescription(description1);

                        femCreationOptions1.SetMorphingFlag(false);

                        femCreationOptions1.SetCyclicSymmetryData(false, null);

                        FemPart femPart4 = workFemPart;
                        femPart4.FinalizeCreation(femCreationOptions1);

                        femSynchronizeOptions1.Dispose();
                        femCreationOptions1.Dispose();
                        BaseTemplateManager baseTemplateManager2 =
                            _sessionData.TheSession.XYPlotManager.TemplateManager;

                        string simPartName = partName + "_sim1.sim";
                        string simPartFullPath = Path.Combine(directoryFullPath, simPartName);
                        if (File.Exists(simPartFullPath))
                        {
                            File.Delete(simPartFullPath);
                        }
                        BasePart basePart2 =
                            _sessionData.TheSession.Parts.NewBaseDisplay(simPartFullPath, BasePart.Units.Millimeters);

                        SimPart workSimPart = ((SimPart)_sessionData.TheSession.Parts.BaseWork);
                        SimPart displaySimPart = ((SimPart)_sessionData.TheSession.Parts.BaseDisplay);
                        SimPart simPart1 = workSimPart;
                        string[] description2 = new string[0];
                        simPart1.FinalizeCreation(femPart4, -1, description2);

                       
                        _sessionData.TheSession.CleanUpFacetedFacesAndEdges();

                        //Solution
                        SimPart simPart2 = workSimPart;
                        SimSimulation simSimulation1 = simPart2.Simulation;

                        SimSolution simSolution1 = simSimulation1.CreateSolution("NX NASTRAN", "Structural",
                            "SESTATIC 101 - Single Constraint", "Solution 1",
                            SimSimulation.AxisymAbstractionType.None);

                        PropertyTable propertyTable1 = simSolution1.PropertyTable;

                        CaePart caePart1 = workSimPart;
                        ModelingObjectPropertyTable modelingObjectPropertyTable1 =
                            caePart1.ModelingObjectPropertyTables.CreateModelingObjectPropertyTable(
                                "Bulk Data Echo Request", "NX NASTRAN - Structural", "NX NASTRAN",
                                "Bulk Data Echo Request1", 1);

                        CaePart caePart2 = workSimPart;
                        ModelingObjectPropertyTable modelingObjectPropertyTable2 =
                            caePart2.ModelingObjectPropertyTables.CreateModelingObjectPropertyTable(
                                "Structural Output Requests", "NX NASTRAN - Structural", "NX NASTRAN",
                                "Structural Output Requests1", 2);

                        Session.UndoMarkId markId10;
                        markId10 = _sessionData.TheSession.SetUndoMark(Session.MarkVisibility.Invisible, null);

                        PropertyTable propertyTable2 = simSolution1.PropertyTable;

                        propertyTable2.SetNamedPropertyTablePropertyValue("Bulk Data Echo Request",
                            modelingObjectPropertyTable1);

                        propertyTable2.SetNamedPropertyTablePropertyValue("Output Requests",
                            modelingObjectPropertyTable2);

                        Session.UndoMarkId id1 = _sessionData.TheSession.NewestVisibleUndoMark;

                        int nErrs1;
                        nErrs1 = _sessionData.TheSession.UpdateManager.DoUpdate(id1);

                        SimSolutionStep simSolutionStep1 = simSolution1.CreateStep(0, true, "Subcase - Static Loads 1");

                        int nErrs2;
                        nErrs2 = _sessionData.TheSession.UpdateManager.DoUpdate(markId10);

                        _sessionData.TheSession.DeleteUndoMark(markId10, null);

                        _sessionData.TheSession.SetUndoMarkName(id1, "Solution");

                        _sessionData.TheSession.CleanUpFacetedFacesAndEdges();

                        _sessionData.TheSession.Parts.SetWork(femPart4);

                        workFemPart =
                            ((FemPart)_sessionData.TheSession.Parts.BaseWork); // wave_component_fem1
                        _sessionData.TheSession.CleanUpFacetedFacesAndEdges();
                        CaePart femPart = workSimPart.FemPart;
                        oFemPart = workFemPart;
                        oSimPart = workSimPart;
                        idealizedPart = workFemPart.IdealizedPart;
                        if (idealizedPart != null)
                        {
                            PartLoadStatus partLoadStatus;
                            _sessionData.TheSession.Parts.SetActiveDisplay(idealizedPart,
                                DisplayPartOption.ReplaceExisting, PartDisplayPartWorkPartOption.SameAsDisplay,
                                out partLoadStatus);
                            workFemPart = null;
                            displaySimPart = null;
                            partLoadStatus.Dispose();
                        }
                    }

                }

                //_sessionData.TheUi.NXMessageBox.Show("SIM creation", NXMessageBox.DialogType.Information,
                //    "FEM and SIM solution created");
            }
            catch (Exception e)
            {
                _sessionData.TheUi.NXMessageBox.Show("SIM creation", NXMessageBox.DialogType.Error,
                    "FEM and SIM solution creation Failed");
            }

            return idealizedPart;
        }
        public Component GetRootComponent()
        {
            ComponentAssembly componentAssembly = _sessionData.TheSession.Parts.Work.ComponentAssembly;
            if (componentAssembly != null)
            {
                Component rootComponent = componentAssembly.RootComponent;
                return rootComponent;
            }
            return null;
        }
        public void CreateWaveLinkBodies(List<FastenerStandardPart> iFastenerStandardParts)
        {
            Component iComponent = GetRootComponent();
            if (iComponent == null)
            {
                return;
            }

            Component[] components = iComponent.GetChildren();
            if (components.Length == 1)
            {
                List<Body> allBodies = GetAllInstanceBodiesFromComponents(components[0], iFastenerStandardParts);
                Log.Info("Collected all the bodies in the assembly...");
                if (allBodies.Any())
                {
                    try
                    {
                        WaveLinkBuilder waveLinkBuilder1 =
                            _sessionData.TheSession.Parts.Work.BaseFeatures.CreateWaveLinkBuilder(null);
                        ExtractFaceBuilder extractFaceBuilder1 = waveLinkBuilder1.ExtractFaceBuilder;
                        waveLinkBuilder1.Type = WaveLinkBuilder.Types.BodyLink;
                        extractFaceBuilder1.ParentPart = ExtractFaceBuilder.ParentPartType.OtherPart;
                        extractFaceBuilder1.Associative = true;
                        extractFaceBuilder1.MakePositionIndependent = false;
                        extractFaceBuilder1.FixAtCurrentTimestamp = false;
                        extractFaceBuilder1.HideOriginal = true;
                        extractFaceBuilder1.InheritDisplayProperties = false;
                        extractFaceBuilder1.CopyThreads = true;
                        extractFaceBuilder1.FeatureOption = ExtractFaceBuilder.FeatureOptionType.OneFeatureForAllBodies;
                        extractFaceBuilder1.FeatureOption = ExtractFaceBuilder.FeatureOptionType.SeparateFeatureForEachBody;

                        Body[] bodies1 = new Body[allBodies.Count];
                        for (int i = 0; i < allBodies.Count; i++)
                        {
                            bodies1[i] = allBodies[i];
                        }

                        BodyDumbRule bodyDumbRule1;
                        bodyDumbRule1 = _sessionData.TheSession.Parts.Work.ScRuleFactory.CreateRuleBodyDumb(bodies1);

                        ScCollector scCollector1 = extractFaceBuilder1.ExtractBodyCollector;
                        //selectionIntentRuleOptions1.Dispose();
                        SelectionIntentRule[] rules1 = new SelectionIntentRule[1];
                        rules1[0] = bodyDumbRule1;
                        scCollector1.ReplaceRules(rules1, false);
                        
                        NXObject nxObject1 = waveLinkBuilder1.Commit();
                        NXObject[] committedObjects = waveLinkBuilder1.GetCommittedObjects();
                        waveLinkBuilder1.Destroy();
                        _sessionData.TheSession.CleanUpFacetedFacesAndEdges();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        Log.Error("Error in Wave-linking of bodies...",e);
                    }
                }
                else
                {
                    Log.Info("No solid bodies are there for creating Wave linking...");
                }
            }
            

        }

        public void CueLog(string iCue)
        {
            _sessionData.TheUfSession.Ui.SetPrompt(iCue);
        }
        public void CreateWaveLinkBodies(List<PartData> iPartDatas)
        {
            if (!iPartDatas.Any())
            {
                return;
            }

            #region Old Implementation
            //foreach (PartData iPartData in iPartDatas)
            //{
            //    iPartData.CadComponent.OwningPart.LoadFully();
            //    List<Body> allBodies = GetAllInstanceBodiesFromComponents(iPartData);
            //    Log.Info("Collected all the bodies in the "+ iPartData.PartNumber+"...");
            //    if (allBodies.Any())
            //    {
            //        int bodyCnt = 1;
            //        foreach (Body instanceBody in allBodies)
            //        {
            //            try
            //            {
            //                BodyFeature linkedBody = CreateLinkedBody(instanceBody);
            //                if (linkedBody != null)
            //                {
            //                    instanceBody.Blank();
            //                    iPartData.LinkedBodyFeature = linkedBody;
            //                    //LB stands for linked Body
            //                    linkedBody.SetName(iPartData.PartNumber + "_" + bodyCnt);
            //                    bodyCnt++;
            //                }
            //            }
            //            catch (Exception e)
            //            {
            //                Console.WriteLine(e);
            //                Log.Error("Error in Wave-linking of bodies...", e);
            //            }
            //        }
            //    }
            //    else
            //    {
            //        Log.Info("No solid bodies are there for creating Wave linking...");
            //    }
            //}
            #endregion

            List<BodyFeature> linkedBodies = new List<BodyFeature>(0);
            List<Body> bodies = GetAllInstanceBodiesFromComponents(iPartDatas);
            foreach (Body body in bodies)
            {
                BodyFeature linkedBodyFeature = CreateLinkedBody(body);
               
                Component bodyOwningComponent = body.OwningComponent;
                PartData partData = (from iPartData in iPartDatas
                    where iPartData.CadComponent==bodyOwningComponent
                    select iPartData).FirstOrDefault();
                if (partData != null)
                {
                    partData.LinkedBodyFeature = linkedBodyFeature;
                    linkedBodyFeature.SetName(partData.PartNumber);
                    Body[] linkedBodyFeatures = linkedBodyFeature.GetBodies();
                    foreach (Body bodyFeature in linkedBodyFeatures)
                    {
                        SetAttribute(bodyFeature, Constants.PARENT_PART_NO, partData.PartNumber + "_"+partData.PartId);
                        bodyFeature.SetName(partData.PartNumber);
                    }
                }
            }
            //linkedBodies = CreateLinkedBodies(bodies);
            //foreach (BodyFeature linkedBodyFeature in linkedBodies)
            //{
            //    UFWave.LinkedFeatureInfo nameStore;
            //    _sessionData.TheUfSession.Wave.AskLinkedFeatureInfo(linkedBodyFeature.Tag, out nameStore);
            //    string featureName = nameStore.feature_name;
            //    PartData partData = (from iPartData in iPartDatas
            //        where iPartData.PartNumber.Equals(nameStore.source_part_name,
            //            StringComparison.CurrentCultureIgnoreCase)
            //        select iPartData).FirstOrDefault();
            //    if (partData != null)
            //    {
            //        linkedBodyFeature.SetName(partData.PartNumber);
            //        Body[] linkedBodyFeatures = linkedBodyFeature.GetBodies();
            //        foreach (Body bodyFeature in linkedBodyFeatures)
            //        {
            //            SetAttribute(bodyFeature, Constants.PARENT_PART_NO, partData.PartNumber);
            //            bodyFeature.SetName(partData.PartNumber);
            //        }
            //        Tag sourceTag;
            //        _sessionData.TheUfSession.Wave.AskLinkSource(linkedBodyFeature.Tag, true, out sourceTag);
            //        TaggedObject taggedObject = _sessionData.TheSession.GetObjectManager().GetTaggedObject(sourceTag);
            //        if (taggedObject is Body)
            //        {
            //            Body parentOfLinkedBody = taggedObject as Body;
            //            Body occParentBodyOfLinkedFeat = partData.CadComponent.FindOccurrence(parentOfLinkedBody) as Body;
            //            if (occParentBodyOfLinkedFeat != null)
            //            {
            //                partData.LinkedBodyFeature = linkedBodyFeature;
            //                SetAttribute(occParentBodyOfLinkedFeat, Constants.PARENT_PART_NO, partData.PartNumber);

            //            }
            //        }
            //    }
               
            //}
        }

        public void FindMatingParts(List<PartData> iPartDatas)
        {
            List<Body> bodyOccs = new List<Body>(0);
            foreach (PartData iPartData in iPartDatas)
            {
                bodyOccs.Add(iPartData.ComponentBody);
            }

            ClearanceSet oClearanceSet = ClearanceAnalysisBetweenAllBodies(bodyOccs.ToArray(), 0.5);
            if (oClearanceSet != null)
            {
                int numberOfInterferences = oClearanceSet.GetNumberOfInterferences();
                DisplayableObject interObj1 = null;
                DisplayableObject interObj2 = null;
                for (int i = 0; i < numberOfInterferences; i++)
                {
                    oClearanceSet.GetNextInterference(interObj1, interObj2, out interObj1, out interObj2);
                    Body interferenceBody1 = (Body)interObj1;
                    Body interferenceBody2 = (Body)interObj2;
                    Component interferenceBody1OwningComponent = interferenceBody1.OwningComponent;
                    Component interferenceBody2OwningComponent = interferenceBody2.OwningComponent;
                    PartData partData1 = (from ipart in iPartDatas where ipart.CadComponent == interferenceBody1OwningComponent select ipart)
                        .FirstOrDefault();
                    PartData partData2 = (from ipart in iPartDatas where ipart.CadComponent == interferenceBody2OwningComponent select ipart)
                        .FirstOrDefault();

                    if (partData1 != null && partData2 != null)
                    {
                        ClearanceSet.InterferenceType interfType;
                        bool newInterference;
                        DisplayableObject[] interferenceBodies;
                        Point3d point1;
                        Point3d point2;
                        string text;
                        int interNumb;
                        int config;
                        int depthResult;
                        double depth;
                        Vector3d direction;
                        Point3d minPoint;
                        Point3d maxPoint;
                        oClearanceSet.GetInterferenceData(interObj1, interObj2, out interfType,
                            out newInterference, out interferenceBodies, out point1, out point2, out text,
                            out interNumb, out config, out depthResult, out depth, out direction, out minPoint,
                            out maxPoint);
                        if (interfType == ClearanceSet.InterferenceType.Touch ||
                            interfType == ClearanceSet.InterferenceType.Hard ||
                            interfType == ClearanceSet.InterferenceType.Soft)
                        {
                            if (depth >= -0.5 && depth <= 0.5)
                            {
                                //It is intersecting
                                partData1.MatingParts.Add(partData2);
                                partData2.MatingParts.Add(partData1);

                                //Find Mating Holes of the Parts
                                AabbTree newHoleAabbTree = new AabbTree(true);
                                foreach (HoleData holeData in partData1.HolesData)
                                {
                                    newHoleAabbTree.Add(new AabbExternalNode { Data = holeData }, holeData.AabbBox);
                                }
                                foreach (HoleData holeData in partData2.HolesData)
                                {
                                    newHoleAabbTree.Add(new AabbExternalNode { Data = holeData }, holeData.AabbBox);
                                }
                                newHoleAabbTree.finalize();
                                // get all the overlapping pairs of holes
                                List<Tuple<AabbExternalNode, AabbExternalNode>> overlappingHoles =
                                    new List<Tuple<AabbExternalNode, AabbExternalNode>>(0);
                                int overlappingPairs = newHoleAabbTree.GetOverlappingPairs(overlappingHoles);

                                foreach (Tuple<AabbExternalNode, AabbExternalNode> overlappingHole in overlappingHoles)
                                {
                                    HoleData holeDataTemp1 = overlappingHole.Item1.Data as HoleData;
                                    HoleData holeDataTemp2 = overlappingHole.Item2.Data as HoleData;

                                    holeDataTemp1.MatingHoles.Add(holeDataTemp2);
                                    holeDataTemp2.MatingHoles.Add(holeDataTemp1);
                                }

                            }
                        }
                    }
                }

                oClearanceSet.Delete();

            }
        }

       
        public List<Face> AskBodyCylindricalConicalFaces(PartData iPartData)
        {
            List<Face> faceList = new List<Face>(0);
            Body iFinalBody = iPartData.ComponentBody;
            Face[] faces = null;
            try
            {
                faces = iFinalBody.GetFaces();
            }
            catch (Exception e)
            {
                //Log.Error(e);
            }

            if (faces != null)
            {

                foreach (Face face in faces)
                {
                    //face.SetName("Temp_" + fcCnt.ToString());
                    //fcCnt++;
                    if (face.SolidFaceType == Face.FaceType.Cylindrical)
                    {
                        int faceType;
                        double[] axisPnt = new double[3];
                        double[] axisDirection = new double[3];
                        double[] faceBox = new double[6];
                        double radius;
                        double radData;
                        int normDir;
                        _sessionData.TheUfSession.Modl.AskFaceData(face.Tag, out faceType, axisPnt, axisDirection, faceBox,
                            out radius,
                            out radData, out normDir);

                        // Is there material on the axis or not - eliminates convex faces
                        int pntStatus;
                        _sessionData.TheUfSession.Modl.AskPointContainment(axisPnt, iFinalBody.Tag, out pntStatus);

                        // Does the cylinder go 360 degrees - eliminates concave blends
                        double[] uvMinMax = new double[4];
                        try
                        {
                            _sessionData.TheUfSession.Modl.AskFaceUvMinmax(face.Tag, uvMinMax);
                            if (IsHoleFace(face) && pntStatus == 2)
                            //&& ((Math.Abs(uvMinMax[0]) < 0.001) && (Math.Abs(uvMinMax[1] - Math.PI * 2) < 0.001)) )
                            {
                                if (Math.Abs(uvMinMax[0]) < 0.001 && Math.Abs(uvMinMax[1] - Math.PI) <= Math.PI * 2 ||
                                    Math.Abs(uvMinMax[0] - Math.PI) < 0.001 &&
                                    (Math.Abs(uvMinMax[1] - Math.PI * 2) < 0.001) ||
                                    Math.Abs(uvMinMax[0]) < 0.001 && Math.Abs(uvMinMax[1] - Math.PI * 2) < 0.001)
                                {
                                    faceList.Add(face);
                                    Point3 min = new Point3(faceBox[0], faceBox[1], faceBox[2]);
                                    Point3 max = new Point3(faceBox[3], faceBox[4], faceBox[5]);
                                    HoleData holeData= new HoleData();
                                    //Body bodyOccurrence = (Body)componentChild.FindOccurrence(protoBody);
                                    holeData.HoleFace = face;
                                    holeData.HoleEdges = GetCircularEdgesOfFace(holeData.HoleFace);
                                    
                                    holeData.HoleDirection = axisDirection;
                                    holeData.ID = randomInt.Next();
                                    holeData.ParentPartData = iPartData;
                                    holeData.AabbBox = new AabbBox(min,max);
                                    iPartData.HolesData.Add(holeData);
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            //Log.Error(e);
                        }

                    }
                }
            }
            return faceList;
        }

        public bool IsHoleFace(Face cylindricalFace)
        {
            // distinguish between a hole face and a boss face
            // hole face: face normal points toward the face axis
            // boss face: face normal points away from the face axis

            // ask face type
            int faceType;
            _sessionData.TheUfSession.Modl.AskFaceType(cylindricalFace.Tag, out faceType);
            switch (faceType)
            {
                case UFConstants.UF_MODL_CYLINDRICAL_FACE:
                {
                    break;
                }

                case UFConstants.UF_MODL_CONICAL_FACE:
                {
                    break;
                }

                default:
                {
                    return false;
                }
            }

            // find cylindrical face axis and point on the axis
            double[] axisPt = new double[3];
            double[] axisDir = new double[3];
            double[] bbox = new double[6];
            double faceMajorRadius;
            double faceMinorRadius;
            int normalDir;
            _sessionData.TheUfSession.Modl.AskFaceData(cylindricalFace.Tag, out faceType, axisPt, axisDir, bbox, out faceMajorRadius, out faceMinorRadius, out normalDir);
            // lw.WriteLine("normalDir: " & normalDir.ToString)
            // +1 = boss face
            // -1 = hole face

            if (normalDir < 0)
                return true;
            return false;
        }
        public BodyFeature CreateLinkedBody(Body theBodyOccurrence)
        {
            WaveLinkBuilder waveLinkBuilder1 =
                _sessionData.TheSession.Parts.Work.BaseFeatures.CreateWaveLinkBuilder(null);
            waveLinkBuilder1.Type = WaveLinkBuilder.Types.BodyLink;

            ExtractFaceBuilder extractFaceBuilder1
                = waveLinkBuilder1.ExtractFaceBuilder;

            extractFaceBuilder1.FaceOption =
                ExtractFaceBuilder.FaceOptionType.FaceChain;
            extractFaceBuilder1.ParentPart =
                ExtractFaceBuilder.ParentPartType.OtherPart;
            extractFaceBuilder1.HideOriginal = true;
            extractFaceBuilder1.FeatureOption = ExtractFaceBuilder.FeatureOptionType.SeparateFeatureForEachBody;

            Body[] body = { theBodyOccurrence };
            SelectionIntentRule[] bodyDumbRule1 = { _sessionData.TheSession.Parts.Work.ScRuleFactory.CreateRuleBodyDumb(body) };

            extractFaceBuilder1.ExtractBodyCollector.ReplaceRules(bodyDumbRule1, true);

            
            BodyFeature theLinkedBody = waveLinkBuilder1.Commit() as BodyFeature;

            waveLinkBuilder1.Destroy();
            _sessionData.TheSession.CleanUpFacetedFacesAndEdges();

            return theLinkedBody;

        }

        public List<BodyFeature> CreateLinkedBodies(List<Body> theBodies)
        {
            List<BodyFeature> linkedBodyFeature = new List<BodyFeature>(0);
            WaveLinkBuilder waveLinkBuilder1 =
                _sessionData.TheSession.Parts.Work.BaseFeatures.CreateWaveLinkBuilder(null);
            waveLinkBuilder1.Type = WaveLinkBuilder.Types.BodyLink;

            ExtractFaceBuilder extractFaceBuilder1
                = waveLinkBuilder1.ExtractFaceBuilder;

            extractFaceBuilder1.FaceOption =
                ExtractFaceBuilder.FaceOptionType.FaceChain;
            extractFaceBuilder1.ParentPart =
                ExtractFaceBuilder.ParentPartType.OtherPart;
            extractFaceBuilder1.HideOriginal = true;
            extractFaceBuilder1.FeatureOption = ExtractFaceBuilder.FeatureOptionType.SeparateFeatureForEachBody;

            Body[] body = new Body[theBodies.Count];
            for (int i = 0; i < theBodies.Count; i++)
            {
                body[i] = theBodies[i];
            }
            
            SelectionIntentRule[] bodyDumbRule1 = { _sessionData.TheSession.Parts.Work.ScRuleFactory.CreateRuleBodyDumb(body) };

            extractFaceBuilder1.ExtractBodyCollector.ReplaceRules(bodyDumbRule1, true);


            NXObject theLinkedBody = waveLinkBuilder1.Commit();
            NXObject[] committedObjects = waveLinkBuilder1.GetCommittedObjects();
            waveLinkBuilder1.Destroy();
            foreach (NXObject committedObject in committedObjects)
            {
                ExtractFace commExtractFace = committedObject as ExtractFace;
                if (committedObject is BodyFeature)
                {
                    BodyFeature bodyFeature = committedObject as BodyFeature;
                    linkedBodyFeature.Add(bodyFeature);
                }
            }
            _sessionData.TheSession.CleanUpFacetedFacesAndEdges();

           return linkedBodyFeature;

        }

        public void UpdateIPartDataWithChildOfIdealParts(List<PartData> iPartsData)
        {
            Component iComponent = GetRootComponent();
           
            if (iComponent != null)
            {
                UpdateAllIPartsData(iComponent,iPartsData);
            }

        }

        public void UpdateAllIPartsData(Component iComponent, List<PartData> iPartsData)
        {
            List<Component> childrenComponents = iComponent.GetChildren().ToList();
            foreach (Component childrenComponent in childrenComponents)
            {
                if (!ComponentIsAssembly(childrenComponent))
                {
                    if (childrenComponent.HasInstanceUserAttribute(Constants.PART_ID, NXObject.AttributeType.String,
                        -1))
                    {
                        string partId = childrenComponent.GetInstanceStringUserAttribute(Constants.PART_ID, -1);
                        PartData firstOrDefault =
                            (from partData in iPartsData where partData.PartId == partId select partData)
                            .FirstOrDefault();
                        if (firstOrDefault != null)
                        {
                            firstOrDefault.CadComponent = childrenComponent;
                            //delete the attribute
                            firstOrDefault.CadComponent.DeleteInstanceUserAttribute(NXObject.AttributeType.String,
                                Constants.PART_ID, true, Update.Option.Now);
                        }
                    }
                }

                UpdateAllIPartsData(childrenComponent, iPartsData);
            }
        }

        public List<PartData> GetAllComponents()
        {
            List<PartData> parts = new List<PartData>(0);
            Component iComponent = GetRootComponent();
            int partCnt = 0;
            if (iComponent == null)
            {
                return parts;
            }
            GetAllComponentsWithBody(iComponent, parts,partCnt);
            //Component[] components = iComponent.GetChildren();
            //if (components.Length == 1)
            //{
               
            //}
            return parts;
        }
        private void GetAllComponentsWithBody(Component iComponent,List<PartData> components,int partCnt)
        {
            List<Component> childrenComponents = iComponent.GetChildren().ToList();
            foreach (Component childrenComponent in childrenComponents)
            {
                if (!ComponentIsAssembly(childrenComponent))
                {
                    if (!childrenComponent.IsBlanked && !childrenComponent.IsSuppressed)
                    {
                        Body occuranceBody = GetOccuranceBody(childrenComponent);
                        if (occuranceBody != null)
                        {
                            PartData partData = new PartData();
                            partData.PartId = partCnt.ToString();
                            partData.CadComponent = childrenComponent;
                            partData.PartNumber = childrenComponent.DisplayName;
                            partData.Material = GetAttribute(childrenComponent, Constants.MATERIAL_ATTR_NAME);
                            partData.ComponentBody = occuranceBody;
                            partData.AabbBBox = AskBodyBoundingBox(occuranceBody);
                            FillBodyPlanarFacesData(partData);
                            List<Face> faces = AskBodyCylindricalConicalFaces(partData);
                            components.Add(partData);
                            partCnt++;
                            childrenComponent.SetInstanceUserAttribute(Constants.PART_ID, -1, partData.PartId, Update.Option.Now);
                        }
                    }
                }
                GetAllComponentsWithBody(childrenComponent, components,partCnt);
            }
        }

        public AabbBox AskBodyBoundingBox(Body iBody)
        {
            double[] bBox = new double[6];
            _sessionData.TheUfSession.Modl.AskBoundingBox(iBody.Tag, bBox);
            Point3 min = new Point3(bBox[0], bBox[1], bBox[2]);
            Point3 max = new Point3(bBox[3], bBox[4], bBox[5]);

            AabbBox bodyBBox = new AabbBox(min, max);

            return bodyBBox;
        }
        public Body GetOccuranceBody(Component iComponent)
        {
            if (iComponent != null)
            {
                if (iComponent.OwningPart != null)
                {
                    if (iComponent.IsOccurrence)
                    {

                        if (iComponent.Prototype.OwningPart != null)
                        {
                            // Get the prototype of the component
                            Part iGeoPrototype = (Part)iComponent.Prototype;
                            // For each body in the prototype, find its occurrence in the component object and add it to the list

                            foreach (Body protoBody in iGeoPrototype.Bodies)
                            {
                                if (protoBody != null)
                                {
                                    Body bodyOccurrence = (Body)iComponent.FindOccurrence(protoBody);
                                    if (bodyOccurrence != null)
                                    {
                                        //if (bodyOccurrence.IsSolidBody)
                                        if (bodyOccurrence.IsSolidBody && !bodyOccurrence.IsBlanked)
                                        {
                                            return bodyOccurrence;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return null;
        }
        public void GetBoundingBoxOfComponent(Component iComponent)
        {
            //_sessionData.TheUfSession.Modl.bou
        }
        public List<Component> GetAllChildComponents(Component iComponent)
        {
            List<Component> childComps = new List<Component>(0);
            List<Component> childrenComponents = iComponent.GetChildren().ToList();
            foreach (Component childrenComponent in childrenComponents)
            {
                if (!ComponentIsAssembly(childrenComponent))
                {
                    childComps.Add(childrenComponent);
                }
                GetAllChildComponents(childrenComponent);
            }
            return childComps;
        }

        public List<Body> GetAllInstanceBodiesFromComponents(Component iComponent,
            List<FastenerStandardPart> iFastenerStandardParts)
        {
            List<Body> occuranceBodies = new List<Body>(0);
            List<Component> componentChildren = GetAllChildComponents(iComponent);
            List<Component> componentChildren2 = iComponent.GetChildren().ToList();
            List<Component> firstLevelFilter =
                GeneralFunctions.FilteredComponents(componentChildren, iFastenerStandardParts);
            //List<Component> secondLevelFilter = GeneralFunctions.FilteredComponents(firstLevelFilter, iExceptionParts);
            if (firstLevelFilter.Any())
            {
                foreach (Component componentChild in firstLevelFilter)
                {
                    if (componentChild.IsSuppressed || componentChild.IsBlanked)
                    {
                        continue;
                    }
                    //Get the parts has to be ignored. 

                    if (componentChild.OwningPart != null)
                    {
                        if (componentChild.IsOccurrence)
                        {

                            if (componentChild.Prototype.OwningPart != null)
                            {
                                // Get the prototype of the component
                                Part iGeoPrototype = (Part)componentChild.Prototype;
                                // For each body in the prototype, find its occurrence in the component object and add it to the list

                                foreach (Body protoBody in iGeoPrototype.Bodies)
                                {
                                    if (protoBody != null)
                                    {
                                        Body bodyOccurrence = (Body)componentChild.FindOccurrence(protoBody);
                                        if (bodyOccurrence != null)
                                        {
                                            //if (bodyOccurrence.IsSolidBody)
                                            if (bodyOccurrence.IsSolidBody && !bodyOccurrence.IsBlanked)
                                            {
                                                occuranceBodies.Add(
                                                    (Body)componentChild.FindOccurrence(protoBody));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //else
            //{
            //    if (iComponent.OwningPart != null)
            //    {
            //        if (iComponent.IsOccurrence)
            //        {

            //            if (iComponent.Prototype.OwningPart != null)
            //            {
            //                // Get the prototype of the component
            //                Part iGeoPrototype = (Part)iComponent.Prototype;
            //                // For each body in the prototype, find its occurrence in the component object and add it to the list
            //                int Length = iGeoPrototype.Bodies.ToArray().Length;
            //                if (Length == 2)
            //                {
            //                    Console.WriteLine(@"Found");
            //                }
            //                foreach (Body protoBody in iGeoPrototype.Bodies)
            //                {
            //                    if (protoBody != null)
            //                    {
            //                        int protoBodyLayer = protoBody.Layer;
            //                        //if (protoBodyLayer == iLayer)
            //                        {
            //                            Body bodyOccurrence = (Body)iComponent.FindOccurrence(protoBody);
            //                            if (bodyOccurrence != null)
            //                            {
            //                                //if (bodyOccurrence.IsSolidBody)
            //                                if (bodyOccurrence.IsSolidBody && !bodyOccurrence.IsBlanked)
            //                                {
            //                                    occuranceBodies.Add(
            //                                        (Body)iComponent.FindOccurrence(protoBody));
            //                                }
            //                            }
            //                        }
            //                    }
            //                }
            //            }
            //        }
            //    }
            //}
            return occuranceBodies;
        }

        public List<Body> GetAllInstanceBodiesFromComponents(PartData ipartData)
        {
            Component componentChild = ipartData.CadComponent;
            List<Body> occuranceBodies = new List<Body>(0);
            if (componentChild.IsSuppressed || componentChild.IsBlanked)
            {
                return occuranceBodies;
            }
            //Get the parts has to be ignored. 

            if (componentChild.OwningPart != null)
            {
                if (componentChild.IsOccurrence)
                {

                    if (componentChild.Prototype.OwningPart != null)
                    {
                        // Get the prototype of the component
                        Part iGeoPrototype = (Part)componentChild.Prototype;
                        // For each body in the prototype, find its occurrence in the component object and add it to the list

                        foreach (Body protoBody in iGeoPrototype.Bodies)
                        {
                            if (protoBody != null)
                            {
                                Body bodyOccurrence = (Body)componentChild.FindOccurrence(protoBody);
                                if (bodyOccurrence != null)
                                {
                                    //if (bodyOccurrence.IsSolidBody)
                                    if (bodyOccurrence.IsSolidBody && !bodyOccurrence.IsBlanked)
                                    {
                                        occuranceBodies.Add(
                                            (Body)componentChild.FindOccurrence(protoBody));
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return occuranceBodies;
        }

        public List<Body> GetAllInstanceBodiesFromComponents(List<PartData> iPartsData)
        {
            List<Body> occuranceBodies = new List<Body>(0);
            foreach (PartData partData in iPartsData)
            {
                Component componentChild = partData.CadComponent;
                if (componentChild.IsSuppressed || componentChild.IsBlanked)
                {
                    return occuranceBodies;
                }
                //Get the parts has to be ignored. 

                if (componentChild.OwningPart != null)
                {
                    if (componentChild.IsOccurrence)
                    {

                        if (componentChild.Prototype.OwningPart != null)
                        {
                            // Get the prototype of the component
                            Part iGeoPrototype = (Part)componentChild.Prototype;
                            // For each body in the prototype, find its occurrence in the component object and add it to the list

                            foreach (Body protoBody in iGeoPrototype.Bodies)
                            {
                                if (protoBody != null)
                                {
                                    Body bodyOccurrence = (Body)componentChild.FindOccurrence(protoBody);
                                    if (bodyOccurrence != null)
                                    {
                                        //if (bodyOccurrence.IsSolidBody)
                                        if (bodyOccurrence.IsSolidBody && !bodyOccurrence.IsBlanked)
                                        {
                                            partData.ComponentBody = bodyOccurrence;
                                            occuranceBodies.Add(
                                                (Body)componentChild.FindOccurrence(protoBody));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return occuranceBodies;
        }

        public Face AskLargestPlanarFace(Body iBody)
        {
            Face[] theFaces = iBody.GetFaces();
            double bigArea = 0;
            Face bigFace = null;

            Unit area_units = _sessionData.TheSession.Parts.Work.UnitCollection.GetBase("Area");
            Unit Length_units = _sessionData.TheSession.Parts.Work.UnitCollection.GetBase("Length");

            for (int ii = 0; ii < theFaces.Length; ii++)
            {
                Face theFace = theFaces[ii];
                if (theFace.SolidFaceType == Face.FaceType.Planar)
                {
                    IParameterizedSurface[] theSurface = { theFace };
                    MeasureFaces theMeasure = _sessionData.TheSession.Parts.Work.MeasureManager.NewFaceProperties(
                        area_units, Length_units, 0.999,
                        theSurface);

                    if (theMeasure.Area > bigArea)
                    {
                        bigArea = theMeasure.Area;
                        bigFace = theFace;
                    }
                }
            }

            return bigFace;
        }

        public Face AskLargestFaceByArea(Body iBody)
        {
            Face[] theFaces = iBody.GetFaces();
            double bigArea = 0;
            Face bigFace = null;

            Unit area_units = _sessionData.TheSession.Parts.Work.UnitCollection.GetBase("Area");
            Unit Length_units = _sessionData.TheSession.Parts.Work.UnitCollection.GetBase("Length");

            for (int ii = 0; ii < theFaces.Length; ii++)
            {
                Face theFace = theFaces[ii];
                //if (theFace.SolidFaceType == Face.FaceType.Planar)
                {
                    IParameterizedSurface[] theSurface = { theFace };
                    MeasureFaces theMeasure = _sessionData.TheSession.Parts.Work.MeasureManager.NewFaceProperties(
                        area_units, Length_units, 0.999,
                        theSurface);

                    if (theMeasure.Area > bigArea)
                    {
                        bigArea = theMeasure.Area;
                        bigFace = theFace;
                    }
                }
            }

            return bigFace;
        }


        public Face AskLargestPlanarFace(List<Face> iPlanarFaces)
        {
            if (!iPlanarFaces.Any())
            {
                return null;
            }
            Face[] theFaces = iPlanarFaces.ToArray();
            double bigArea = 0;
            Face bigFace = null;

            Unit area_units = _sessionData.TheSession.Parts.Work.UnitCollection.GetBase("Area");
            Unit Length_units = _sessionData.TheSession.Parts.Work.UnitCollection.GetBase("Length");

            for (int ii = 0; ii < theFaces.Length; ii++)
            {
                Face theFace = theFaces[ii];
                if (theFace.SolidFaceType == Face.FaceType.Planar)
                {
                    IParameterizedSurface[] theSurface = { theFace };
                    MeasureFaces theMeasure = _sessionData.TheSession.Parts.Work.MeasureManager.NewFaceProperties(
                        area_units, Length_units, 0.999,
                        theSurface);

                    if (theMeasure.Area > bigArea)
                    {
                        bigArea = theMeasure.Area;
                        bigFace = theFace;
                    }
                }
            }

            return bigFace;
        }

        public void CreateOffsetMidSurface(PartData partData,Body iBody)
        {
            Face theSeedFace = AskLargestPlanarFace(iBody);
            try
            {
                // best practice cliff angle = 5, suggested max is 15
                Tag midSurfTag;
                _sessionData.TheUfSession.Sf.CreateOffsetMidsrf(theSeedFace.Tag, 
                    5, 50, out midSurfTag);
                if (midSurfTag != Tag.Null)
                {
                    Body taggedObject = NXObjectManager.Get(midSurfTag) as Body;
                    Feature[] features = taggedObject.GetFeatures();
                    foreach (Feature feature in features)
                    {
                        partData.MidSurfaceFeatures.Add(feature);
                        feature.SetName("FP_" + partData.LinkedBodyFeature.Name);
                        Body[] bodies = feature.GetBodies();
                        foreach (Body body in bodies)
                        {
                            body.SetName("FP_" + partData.LinkedBodyFeature.Name);
                            SetAttribute(body, Constants.PARENT_PART_NO, partData.PartNumber + "_" + partData.PartId);
                        }
                    }
                }
            }
            catch (NXException ex)
            {

            }
        }

        public bool CreateFacePairsMidSurface(PartData partData,Body iBody)
        {
            Face seedface1 = AskLargestPlanarFace(iBody);
            Face seedface2 = null;
            //Find parallel and Coplanar face the seed face
            Face[] faces = iBody.GetFaces();
            BasePart iBodyOwningPart = iBody.OwningPart;
            string partName = string.Empty;
            if (iBodyOwningPart != null)
            {
                partName = iBodyOwningPart.Name;
            }
            List<Face> parallelFaces = new List<Face>(0);
            foreach (Face face in faces)
            {
                if (face.SolidFaceType == Face.FaceType.Planar)
                {
                    bool isParallel = IsParallelAndOppositeFaces(seedface1, face);
                    if (isParallel)
                    {
                        parallelFaces.Add(face);
                        //seedface2 = face;
                        //break;
                    }
                }
            }

            if (parallelFaces.Any())
            {
                seedface2 = AskLargestPlanarFace(parallelFaces);
            }

            if (seedface1 != null && seedface2 != null)
            {
                //Get all tangent Faces of seedface1 and Seedface2
                List<Face> seedFace1TangentFaces = GetTangentFaces(seedface1);
                List<Face> seedFace2TangentFaces = GetTangentFaces(seedface2);
                bool isMidSurfaceByFacePairs = CreateMidSurfaceByFacePairs(partData, iBody, seedFace1TangentFaces.ToArray(),
                    seedFace2TangentFaces.ToArray());
                return isMidSurfaceByFacePairs;
            }

            return false;
        }

        public bool CreateMidSurfaceByFacePairs(PartData partData,Body iLinkedBody,Face[] faces1, Face[] faces2)
        {
            Session theSession = _sessionData.TheSession;
            Part workPart = theSession.Parts.Work;
            Part displayPart = theSession.Parts.Display;

            Session.UndoMarkId markId1;
            markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start");
            theSession.SetUndoMarkName(markId1, "Midsurface by Face Pairs");
            try
            {
                MidSurfaceByFacePairsBuilder midSurfaceByFacePairsBuilder1 = workPart.Features.CreateMidSurfaceByFacePairsBuilder(null);
                Body body1 = iLinkedBody;
                bool added1;
                added1 = midSurfaceByFacePairsBuilder1.BodySelection.Add(body1);

                midSurfaceByFacePairsBuilder1.ValidateSelection(0);
                midSurfaceByFacePairsBuilder1.SetupFacePairInContext(null);
                midSurfaceByFacePairsBuilder1.PairingStrategy = MidSurfaceByFacePairsBuilder.PairingStrategyType.Manual;

                SelectionIntentRuleOptions selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions();

                selectionIntentRuleOptions1.SetSelectedFromInactive(false);
                FaceDumbRule faceDumbRule1 = workPart.ScRuleFactory.CreateRuleFaceDumb(faces1, selectionIntentRuleOptions1);

                selectionIntentRuleOptions1.Dispose();
                SelectionIntentRule[] rules1 = new SelectionIntentRule[1];
                rules1[0] = faceDumbRule1;
                midSurfaceByFacePairsBuilder1.SideOneSelection.ReplaceRules(rules1, false);
                midSurfaceByFacePairsBuilder1.ValidateSelection(1);

                SelectionIntentRuleOptions selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions();

                selectionIntentRuleOptions2.SetSelectedFromInactive(false);
                FaceDumbRule faceDumbRule2;
                faceDumbRule2 = workPart.ScRuleFactory.CreateRuleFaceDumb(faces2, selectionIntentRuleOptions2);

                selectionIntentRuleOptions2.Dispose();
                SelectionIntentRule[] rules2 = new SelectionIntentRule[1];
                rules2[0] = faceDumbRule2;
                midSurfaceByFacePairsBuilder1.SideTwoSelection.ReplaceRules(rules2, false);

                midSurfaceByFacePairsBuilder1.ValidateSelection(2);
                midSurfaceByFacePairsBuilder1.HideBodyOption = true;

                Feature[] facepairs1;
                facepairs1 = midSurfaceByFacePairsBuilder1.CreateFacePair();

                midSurfaceByFacePairsBuilder1.ValidateSelection(0);
                midSurfaceByFacePairsBuilder1.SetupFacePairInContext(null);
                midSurfaceByFacePairsBuilder1.SetupFacePairInContext(null);

                MidSurfaceByFacePairs nXObject1;
                nXObject1 = midSurfaceByFacePairsBuilder1.Commit() as MidSurfaceByFacePairs;
                midSurfaceByFacePairsBuilder1.Destroy();
                theSession.CleanUpFacetedFacesAndEdges();
                if (nXObject1 != null)
                {
                    nXObject1.SetName("FP_" + partData.LinkedBodyFeature.Name);
                    MidSurfaceFacePair[] midSurfaceFacePairs = nXObject1.FindFacePairs();
                    foreach (MidSurfaceFacePair midSurfaceFacePair in midSurfaceFacePairs)
                    {
                        partData.MidSurfaceFeatures.Add(midSurfaceFacePair);
                        Body[] bodies1 = midSurfaceFacePair.GetBodies();
                        foreach (Body body in bodies1)
                        {
                            body.SetName("FP_" + partData.LinkedBodyFeature.Name);
                            SetAttribute(body, Constants.PARENT_PART_NO, partData.PartNumber + "_" + partData.PartId);
                        }
                    }
                    
                }
            }
            catch (Exception e)
            {
                theSession.UndoToMark(markId1, "Midsurface by Face Pairs");
                Log.Error("Error in creating Mid Surface by face pairs");

                return false;
            }
            theSession.DeleteUndoMark(markId1,null);
            return true;
        }
        public bool IsParallelAndOppositeFaces(Face iFace1, Face iFace2)
        {
            bool isParallelAndOpposite = false;
            double[] faceNorm1 = GetFaceNormal(iFace1);
            double[] faceNorm2 = GetFaceNormal(iFace2);
            double dotProduct1 = (faceNorm1[0] * faceNorm2[0] + faceNorm1[1] * faceNorm2[1] +
                                  faceNorm1[2] * faceNorm2[2]);
            double abs = Math.Abs(Math.Round(dotProduct1, 2) + 1);
            if (abs < 0.0001523)
            {
                isParallelAndOpposite = true;
            }
            return isParallelAndOpposite;
        }
        public double[] GetFaceNormal(Face iFace)
        {
            double[] param = new double[2];
            double[] p1 = new double[3];
            double[] u1 = new double[3];
            double[] v1 = new double[3];
            double[] u2 = new double[3];
            double[] v2 = new double[3];
            double[] unitNorm = new double[3];
            double[] radii = new double[2];
            double[] uvMinMax = new double[4];

            _sessionData.TheUfSession.Modl.AskFaceUvMinmax(iFace.Tag, uvMinMax);
            param[0] = (uvMinMax[0] + uvMinMax[1]) / 2;
            param[1] = (uvMinMax[2] + uvMinMax[3]) / 2;
            _sessionData.TheUfSession.Modl.AskFaceProps(iFace.Tag, param, p1, u1, v1, u2, v2, unitNorm, radii);

            return unitNorm;
        }
        /// <summary>
        /// Create Mid Surface
        /// </summary>
        /// <param name="iFacePairMidSurfComponents"></param>
        /// <param name="iOffsetMidSurfComponents"></param>
        public void CreateMidSurfaces(List<Component> iFacePairMidSurfComponents,
            List<Component> iOffsetMidSurfComponents)
        {
            //Get the displayed part wave linked bodies
            try
            {
                List<Body> linkedBodiesFromWorkPart = GetLinkedBodiesFromWorkPart(iFacePairMidSurfComponents);
                foreach (Body linkedBody in linkedBodiesFromWorkPart)
                {
                    //CreateFacePairsMidSurface(linkedBody);
                    //CreateOffsetMidSurface(linkedBody);
                    Hide(linkedBody);
                }

                linkedBodiesFromWorkPart = new List<Body>(0);
                linkedBodiesFromWorkPart = GetLinkedBodiesFromWorkPart(iOffsetMidSurfComponents);
                foreach (Body linkedBody in linkedBodiesFromWorkPart)
                {
                    //CreateOffsetMidSurface(linkedBody);
                    Hide(linkedBody);
                }
            }
            catch (Exception e)
            {
                Log.Error("mid Surface creation failed...",e);
            }
           
        }

        public void CreateMidSurfaces(List<PartData> iPartsData)
        {
            foreach (PartData partData in iPartsData)
            {
                if (partData.MeshType == Constants.MeshType.Mesh2D && 
                    partData.LinkedBodyFeature != null && 
                    partData.PartType == Constants.PartType.SheetMetal)
                {
                    try
                    {
                        CueLog("Creating Midsurface for Linked Body " + partData.LinkedBodyFeature.Name);
                        List<Body> linkedBodiesFromWorkPart = partData.LinkedBodyFeature.GetBodies().ToList();
                        foreach (Body linkedBody in linkedBodiesFromWorkPart)
                        {
                            CreateFacePairsMidSurface(partData,linkedBody);
                            Hide(linkedBody);
                            partData.IsMidSurfaceCreated = true;
                        }

                    }
                    catch (Exception e)
                    {
                        Log.Error("mid Surface creation failed for " + partData.LinkedBodyFeature.Name);
                        Log.Error("ERROR", e);
                    }
                }

                if (partData.MeshType == Constants.MeshType.Mesh2D &&
                    partData.LinkedBodyFeature != null &&
                    partData.PartType == Constants.PartType.PipeOrTube)
                {
                    try
                    {
                        CueLog("Creating Midsurface for Linked Body " + partData.LinkedBodyFeature.Name);
                        List<Body> linkedBodiesFromWorkPart = partData.LinkedBodyFeature.GetBodies().ToList();
                        foreach (Body linkedBody in linkedBodiesFromWorkPart)
                        {
                            CreateOffsetMidSurface(partData,linkedBody);
                            Hide(linkedBody);
                            partData.IsMidSurfaceCreated = true;
                        }

                    }
                    catch (Exception e)
                    {
                        Log.Error("mid Surface creation failed for " + partData.LinkedBodyFeature.Name);
                        Log.Error("ERROR", e);
                    }
                }
                if (partData.MeshType == Constants.MeshType.Mesh3D &&
                    partData.LinkedBodyFeature != null && (
                    partData.PartType == Constants.PartType.CastingOrForging ||
                    partData.PartType == Constants.PartType.Plastics))
                {
                    List<Body> linkedBodiesFromWorkPart = partData.LinkedBodyFeature.GetBodies().ToList();
                    foreach (Body linkedBody in linkedBodiesFromWorkPart)
                    {
                        SetAttribute(linkedBody, Constants.PARENT_PART_NO, partData.PartNumber + "_" + partData.PartId);
                        
                    }
                }


            }
            //Get the displayed part wave linked bodies
            
           
        }

        /// <summary>
        /// Get all Linked bodies from the work part
        /// </summary>
        /// <returns></returns>
        public List<Body> GetLinkedBodiesFromWorkPart(List<Component> iComponents)
        {
            List<Body> linkedBodies = new List<Body>(0);
            List<Feature> linkedFeaturesFromWorkPart = GetLinkedFeaturesFromWorkPart();
            foreach (Feature linkedFeature in linkedFeaturesFromWorkPart)
            {
                Component linkedFeatureParentComponent = GetLinkedFeatureParentComponent(linkedFeature);
                List<Component> linkedComps = (from iComponent in iComponents
                    where iComponent.DisplayName.Contains(linkedFeatureParentComponent.DisplayName)
                    select iComponent).ToList();
                if (linkedComps.Any())
                {
                    Body[] bodies = linkedFeature.GetBodies();
                    foreach (Body linkedBody in bodies)
                    {
                        linkedBodies.Add(linkedBody);
                    }
                }
                
            }
            return linkedBodies;

        }
        /// <summary>
        /// Get Linked features from Work Part
        /// </summary>
        /// <returns></returns>
        public List<Feature> GetLinkedFeaturesFromWorkPart()
        {
            List<Feature> partLinkedFeatures = new List<Feature>(0);
            Feature[] features = _sessionData.TheSession.Parts.Work.Features.GetFeatures();
            foreach (Feature feat in features)
            {
                if (feat.FeatureType == "LINKED_BODY")
                {
                    partLinkedFeatures.Add(feat);
                }
            }
            return partLinkedFeatures;
        }
        public List<Body> GetMidSurfaceBodiesFromWorkPart()
        {
            List<Body> linkedBodies = new List<Body>(0);
            List<Feature> midSurfaceFeats = GetMidSurfaceFeaturesFromWorkPart();
            foreach (Feature midSurfaceFeat in midSurfaceFeats)
            {
                Body[] bodies = midSurfaceFeat.GetBodies();
                foreach (Body midSurfaceBody in bodies)
                {
                    linkedBodies.Add(midSurfaceBody);
                }
            }

            return linkedBodies;
        }
        /// <summary>
        /// Get Offset Mid Surface Features
        /// </summary>
        /// <returns></returns>
        public List<Feature> GetMidSurfaceFeaturesFromWorkPart()
        {
            List<Feature> partLinkedFeatures = new List<Feature>(0);
            Feature[] features = _sessionData.TheSession.Parts.Work.Features.GetFeatures();
            foreach (Feature feature in features)
            {
                
                string featureType = feature.FeatureType;
                if (featureType == "MIDSURFACE" || featureType == "FACEPAIR_DEF")
                {
                    partLinkedFeatures.Add(feature);
                }
            }
            return partLinkedFeatures;
        }

        /// <summary>
        /// Creating Washer Imprint
        /// </summary>
        public void CreateWasherImprint(List<PartData> iPartsData)
        {
            //Get parts with mating parts
            List<PartData> partsDataWithOneMating = (from partData in iPartsData
                where partData.MatingParts.Any() && partData.MatingParts.Count == 1
                select partData).ToList();
            List<PartData> sandwichedPartsData = (from partData in iPartsData
                where partData.MatingParts.Any() && partData.MatingParts.Count > 1
                select partData).ToList();
          
            foreach (PartData matingPart1 in sandwichedPartsData)
            {
                foreach (PartData matingPart2 in matingPart1.MatingParts)
                {
                    if (partsDataWithOneMating.Contains(matingPart2))
                    {
                        partsDataWithOneMating.Remove(matingPart2);
                    }
                    //Create washer between extreme parts that is mating parts only
                    CreateWasherImprintBetweenTwoMatingParts(matingPart2, matingPart1);
                }
            }
            
            List<PartData> partsMatingWith2DMesh = (from partData in partsDataWithOneMating
                                                    where partData.MatingParts.Any() && 
                      partData.MatingParts.Count == 1 && 
                      partData.MeshType==Constants.MeshType.Mesh2D && 
                      partData.MatingParts[0].MeshType==Constants.MeshType.Mesh2D
                select partData).ToList();
           
            foreach (PartData partData in partsMatingWith2DMesh)
            {
                PartData partDataMatingPart = partData.MatingParts[0];
                CreateWasherImprintBetweenTwoMatingParts(partData, partDataMatingPart);
                CreateWasherImprintBetweenTwoMatingParts(partDataMatingPart, partData);
            }
           
            
            //Create Washer imprint only between mating Parts Parts
            //Part1=Mesh2d && Part2=Mesh2D

            ////foreach (PartData partData in iPartsData)
            ////{
            ////    if (!partData.MatingParts.Any())
            ////    {
            ////        continue;
            ////    }

            ////    if (partData.MatingParts.Count == 1)
            ////    {

            ////    }

            ////    if (partData.MatingParts.Count >= 1)
            ////    {

            ////    }
            ////    List<Feature> midSurfaceFeatures = partData.MidSurfaceFeatures;
            ////    foreach (Feature midSurfaceFeature in midSurfaceFeatures)
            ////    {
            ////        //List<Body> midSurfaceBodies = GetMidSurfaceBodiesFromWorkPart();
            ////        foreach (Body midSurfaceBody in midSurfaceFeature.GetBodies())
            ////        {
            ////            try
            ////            {
            ////                Face[] faces = midSurfaceBody.GetFaces();
            ////                foreach (Face midSurfaceFace in faces)
            ////                {
            ////                    List<EdgeData> circularEdgesOfFace = GetFullCircularEdgesOfFace(midSurfaceFace);
            ////                    if (partData.MatingParts.Any() && circularEdgesOfFace.Any())
            ////                    {
            ////                        List<EdgeData> matingCircularEdges = GetMatingCircularEdges(partData,midSurfaceFace);
            ////                        IEnumerable<IGrouping<double, EdgeData>> edgesGroup =
            ////                            matingCircularEdges.GroupBy(edges => edges.Diameter);
            ////                        foreach (IGrouping<double, EdgeData> edgeDataS in edgesGroup)
            ////                        {
            ////                            if (edgeDataS.Any())
            ////                            {
            ////                                EdgeData firstOrDefault = edgeDataS.FirstOrDefault();
            ////                                if (firstOrDefault.IsWasherSizeInDb)
            ////                                {
            ////                                    double washerDia = firstOrDefault.WasherSize;
            ////                                    double holeDia = firstOrDefault.Diameter;
            ////                                    double offset = washerDia - holeDia;
            ////                                    Edge offsetEdge = firstOrDefault.OEdge;

            ////                                    List<Edge> edges = new List<Edge>(0);
            ////                                    List<EdgeData> edgesData = new List<EdgeData>(0);
            ////                                    foreach (EdgeData edgeData in edgeDataS)
            ////                                    {
            ////                                        edges.Add(edgeData.OEdge);
            ////                                       // edgeData.OEdge.SetName("Washer_Edge");
            ////                                        partData.WasherEdgesData.Add(edgeData);
            ////                                        edgesData.Add(edgeData);
            ////                                    }

            ////                                    if (edges.Any())
            ////                                    {
            ////                                        List<Curve> arcs = DrawCircle(edgesData);
            ////                                        DivideFace1(partData, midSurfaceBody, arcs);
            ////                                        //OffsetEdge(offset.ToString(), midSurfaceBody, edges);
            ////                                        //DivideFace(offset.ToString(), midSurfaceBody, edges);
            ////                                    }
            ////                                }

            ////                            }
            ////                        }
            ////                    }
                                
            ////                }
            ////            }
            ////            catch (Exception e)
            ////            {
            ////                Log.Error("Error in creating washer imprint");
            ////            }

            ////        }
            ////    }
            ////}

        }

        public void BoltAndNutMesh(List<PartData> iPartsData)
        {
            //Get parts with mating parts
            List<PartData> partsDataWithOneMating = (from partData in iPartsData
                where partData.MatingParts.Any() && partData.MatingParts.Count == 1
                select partData).ToList();
            List<PartData> sandwichedPartsData = (from partData in iPartsData
                where partData.MatingParts.Any() && partData.MatingParts.Count == 2
                select partData).ToList();

            foreach (PartData matingPart1 in sandwichedPartsData)
            {
                PartData sP = matingPart1;
                PartData p1 = matingPart1.MatingParts[0];
                PartData p2 = matingPart1.MatingParts[1];
                if (partsDataWithOneMating.Contains(p1) && partsDataWithOneMating.Contains(p2))
                {
                    partsDataWithOneMating.Remove(p1);
                    partsDataWithOneMating.Remove(p2);
                }

                Mesh1DBolt(p1,sP,p2);
              

            }
            List<PartData> partsMatingWith2DMesh = (from partData in partsDataWithOneMating
                where partData.MatingParts.Any() &&
                      partData.MatingParts.Count == 1 &&
                      partData.MeshType == Constants.MeshType.Mesh2D &&
                      partData.MatingParts[0].MeshType == Constants.MeshType.Mesh2D
                select partData).ToList();

            foreach (PartData partData in partsMatingWith2DMesh)
            {
                PartData partDataMatingPart = partData.MatingParts[0];
                Mesh1DBolt(partData, partDataMatingPart);
            }


        }
        public List<EdgeData> GetCircularCaeEdgesOfMidSurfaces(PartData iPartData1, PartData iPartData2)
        {
            List<EdgeData> matingCircularEdges = new List<EdgeData>(0);
            List<Feature> midSurfaceFeatures = iPartData1.MidSurfaceFeatures;

            foreach (Feature midSurfaceFeature in midSurfaceFeatures)
            {
                //List<Body> midSurfaceBodies = GetMidSurfaceBodiesFromWorkPart();
                foreach (Body midSurfaceBody in midSurfaceFeature.GetBodies())
                {
                    Face[] faces = midSurfaceBody.GetFaces();
                    foreach (Face midSurfaceFace in faces)
                    {
                        List<EdgeData> circularEdgesOfFace = GetFullCircularEdgesOfFace(midSurfaceFace);
                        if (iPartData1.MatingParts.Any() && circularEdgesOfFace.Any())
                        {
                            matingCircularEdges = GetMatingCircularEdges(iPartData1, midSurfaceFace, iPartData2);
                        }
                    }

                }
            }

            return matingCircularEdges;
        }
        private void Mesh1D(PartData p1, PartData sP,PartData p2)
        {

            List<EdgeData> p1Head = GetCircularEdgesOfMidSurfaces(p1,sP);
            List<CAEEdge> p1Edges = new List<CAEEdge>(0);
            List<EdgeData> p2Nut = GetCircularEdgesOfMidSurfaces(p2, sP);
            List<CAEEdge> p2Edges = new List<CAEEdge>(0);
            List<EdgeData> sPJunction = GetCircularEdgesOfMidSurfaces(sP, p1);
            List<CAEEdge> sPEdges = new List<CAEEdge>(0);
            Session theSession = _sessionData.TheSession;
            FemPart workFemPart = ((FemPart)theSession.Parts.BaseWork);
            BodyCollection bodyCollection = workFemPart.Bodies;
            Tag[] polybodies;
            int polygonBodiesCnt;
            _sessionData.TheUfSession.Sf.AskAllPolygonBodies(out polygonBodiesCnt,out polybodies);
            foreach (Tag polybody in polybodies)
            {
                CAEBody caeBody = _sessionData.TheSession.GetObjectManager().GetTaggedObject(polybody) as CAEBody;
                string attributeValue = GetAttribute(caeBody, Constants.PARENT_PART_NO);
                if (!string.IsNullOrEmpty(attributeValue))
                {
                    //p1CaeEdge
                    if (attributeValue.Equals(p1.PartNumber + "_" + p1.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag,out numCaeEdges,out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().
                                    GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
                                    p1Edges.Add(caeEdge);
                                }
                            }
                        }
                    }

                    //p2
                    if (attributeValue.Equals(p2.PartNumber + "_" + p2.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
p2Edges.Add(caeEdge);
                                }
                            }
                        }
                    }

                    if (attributeValue.Equals(sP.PartNumber + "_" + sP.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().GetTaggedObject(caeEdgeTag) as CAEEdge;
                                foreach (EdgeData edgeData in sPJunction)
                                {
                                    if (caeEdge.Name.Contains("WASHER_EDGE"))
                                    {
                                        sPEdges.Add(caeEdge);
                                    }
                                }
                            }
                        }
                    }
                }
            }
          

            Session.UndoMarkId markId1;
            markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start");

            FemPart femPart = (FemPart)theSession.Parts.BaseWork;
            BaseFEModel feModel = femPart.BaseFEModel;
            BoltBuilder boltBuilder1 = feModel.Bolts.CreateBoltBuilder(null);
            try
            {
                MeshCollector meshCollector1;
                meshCollector1 = boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer;
                boltBuilder1.ShankElementType.DestinationCollector.ElementContainer = meshCollector1;
                boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer = meshCollector1;

                boltBuilder1.HeadSpiderScale = 120.0;
                boltBuilder1.NutSpiderScale = 120.0;
                boltBuilder1.JunctionSpiderScale = 120.0;
                boltBuilder1.Junction1SpiderScale = 120.0;
                boltBuilder1.Junction2SpiderScale = 120.0;

                boltBuilder1.ShankElementType.ElementDimension = ElementTypeBuilder.ElementType.Beam;
                boltBuilder1.ShankElementType.DestinationCollector.ElementContainer = null;

                boltBuilder1.SpiderElementType.ElementDimension = ElementTypeBuilder.ElementType.Spider;
                boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer = null;

                boltBuilder1.Junction = true;
                boltBuilder1.ShankElementType.ElementTypeName = "RBE2";
                boltBuilder1.SpiderElementType.ElementTypeName = "RBE2";
                boltBuilder1.Midnode = true;

                theSession.SetUndoMarkName(markId1, "Bolt Connection Dialog");

                TaggedObject[] objects1 = new TaggedObject[p1Edges.Count];
                for (int i = 0; i < p1Edges.Count; i++)
                {
                    objects1[i] = p1Edges[i];
                }
                bool added1;
                added1 = boltBuilder1.HeadEdge.Add(objects1);

                TaggedObject[] objects2 = new TaggedObject[p2Edges.Count];
                for (int i = 0; i < p2Edges.Count; i++)
                {
                    objects2[i] = p2Edges[i];
                }
                bool added2;
                added2 = boltBuilder1.NutEdge.Add(objects2);

                TaggedObject[] objects3 = new TaggedObject[sPEdges.Count];
                for (int i = 0; i < sPEdges.Count; i++)
                {
                    objects3[i] = sPEdges[i];
                }
                bool added3;
                added3 = boltBuilder1.JunctionEdge.Add(objects3);


                boltBuilder1.OperationType = BoltBuilder.BoltOperation.BoltNut;
                boltBuilder1.SpiderElementType.ElementDimension = ElementTypeBuilder.ElementType.Spider;
                boltBuilder1.SpiderElementType.ElementTypeName = "RBE2";

                DestinationCollectorBuilder destinationCollectorBuilder1 = boltBuilder1.ShankElementType.DestinationCollector;
                destinationCollectorBuilder1.ElementContainer = null;
                destinationCollectorBuilder1.AutomaticMode = true;



                DestinationCollectorBuilder destinationCollectorBuilder2 = boltBuilder1.SpiderElementType.DestinationCollector;
                destinationCollectorBuilder2.ElementContainer = null;
                destinationCollectorBuilder2.AutomaticMode = true;



                //Point point1;
                //point1 = workFemPart.Points.CreatePoint(cAEEdge1, SmartObject.UpdateOption.AfterModeling);
                //point1.SetVisibility(SmartObject.VisibilityOption.Visible);

                //Point point2;
                //point2 = workFemPart.Points.CreatePoint(cAEEdge2, SmartObject.UpdateOption.AfterModeling);
                //point2.SetVisibility(SmartObject.VisibilityOption.Visible);

                //Point point3;
                //point3 = workFemPart.Points.CreatePoint(cAEEdge3, SmartObject.UpdateOption.AfterModeling);
                //point3.SetVisibility(SmartObject.VisibilityOption.Visible);



                Bolt bolt1;
                bolt1 = boltBuilder1.CommitBolt();

                theSession.SetUndoMarkName(markId1, "Bolt Connection");
                boltBuilder1.Destroy();
                theSession.CleanUpFacetedFacesAndEdges();
            }
            catch (Exception e)
            {
                Log.Error("Error in creating 1D mesh");
            }
          

            
        }

        private void Mesh1D(PartData p1, PartData p2)
        {

           
            List<CAEEdge> p1Edges = new List<CAEEdge>(0); ;
            List<CAEEdge> p2Edges = new List<CAEEdge>(0);
            List<CAEEdge> sPEdges = new List<CAEEdge>(0);
            Session theSession = _sessionData.TheSession;
            FemPart workFemPart = ((FemPart)theSession.Parts.BaseWork);
            BodyCollection bodyCollection = workFemPart.Bodies;
            Tag[] polybodies;
            int polygonBodiesCnt;
            _sessionData.TheUfSession.Sf.AskAllPolygonBodies(out polygonBodiesCnt, out polybodies);
            foreach (Tag polybody in polybodies)
            {
                CAEBody caeBody = _sessionData.TheSession.GetObjectManager().GetTaggedObject(polybody) as CAEBody;
                string attributeValue = GetAttribute(caeBody, Constants.PARENT_PART_NO);
                if (!string.IsNullOrEmpty(attributeValue))
                {
                    //p1CaeEdge
                    if (attributeValue.Equals(p1.PartNumber + "_" + p1.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().
                                    GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
                                    p1Edges.Add(caeEdge);
                                }
                            }
                        }
                    }

                    //p2
                    if (attributeValue.Equals(p2.PartNumber + "_" + p2.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
                                    p2Edges.Add(caeEdge);
                                }
                            }
                        }
                    }

                    
                }
            }


            Session.UndoMarkId markId1;
            markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start");

            FemPart femPart = (FemPart)theSession.Parts.BaseWork;
            BaseFEModel feModel = femPart.BaseFEModel;
            BoltBuilder boltBuilder1 = feModel.Bolts.CreateBoltBuilder(null);
            try
            {
                MeshCollector meshCollector1;
                meshCollector1 = boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer;
                boltBuilder1.ShankElementType.DestinationCollector.ElementContainer = meshCollector1;
                boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer = meshCollector1;

                boltBuilder1.HeadSpiderScale = 120.0;
                boltBuilder1.NutSpiderScale = 120.0;
                boltBuilder1.JunctionSpiderScale = 120.0;
                boltBuilder1.Junction1SpiderScale = 120.0;
                boltBuilder1.Junction2SpiderScale = 120.0;

                boltBuilder1.ShankElementType.ElementDimension = ElementTypeBuilder.ElementType.Beam;
                boltBuilder1.ShankElementType.DestinationCollector.ElementContainer = null;

                boltBuilder1.SpiderElementType.ElementDimension = ElementTypeBuilder.ElementType.Spider;
                boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer = null;

                boltBuilder1.Junction = true;
                boltBuilder1.ShankElementType.ElementTypeName = "RBE2";
                boltBuilder1.SpiderElementType.ElementTypeName = "RBE2";
                boltBuilder1.Midnode = true;

                theSession.SetUndoMarkName(markId1, "Bolt Connection Dialog");

                TaggedObject[] objects1 = new TaggedObject[p1Edges.Count];
                for (int i = 0; i < p1Edges.Count; i++)
                {
                    objects1[i] = p1Edges[i];
                }
                bool added1;
                added1 = boltBuilder1.HeadEdge.Add(objects1);

                TaggedObject[] objects2 = new TaggedObject[p2Edges.Count];
                for (int i = 0; i < p2Edges.Count; i++)
                {
                    objects2[i] = p2Edges[i];
                }
                bool added2;
                added2 = boltBuilder1.NutEdge.Add(objects2);

                //TaggedObject[] objects3 = new TaggedObject[sPEdges.Count];
                //for (int i = 0; i < sPEdges.Count; i++)
                //{
                //    objects3[i] = sPEdges[i];
                //}
                //bool added3;
                //added3 = boltBuilder1.JunctionEdge.Add(objects3);

                boltBuilder1.Junction = false;
                boltBuilder1.OperationType = BoltBuilder.BoltOperation.BoltNut;
                boltBuilder1.SpiderElementType.ElementDimension = ElementTypeBuilder.ElementType.Spider;
                boltBuilder1.SpiderElementType.ElementTypeName = "RBE2";

                DestinationCollectorBuilder destinationCollectorBuilder1 = boltBuilder1.ShankElementType.DestinationCollector;
                destinationCollectorBuilder1.ElementContainer = null;
                destinationCollectorBuilder1.AutomaticMode = true;



                DestinationCollectorBuilder destinationCollectorBuilder2 = boltBuilder1.SpiderElementType.DestinationCollector;
                destinationCollectorBuilder2.ElementContainer = null;
                destinationCollectorBuilder2.AutomaticMode = true;



                //Point point1;
                //point1 = workFemPart.Points.CreatePoint(cAEEdge1, SmartObject.UpdateOption.AfterModeling);
                //point1.SetVisibility(SmartObject.VisibilityOption.Visible);

                //Point point2;
                //point2 = workFemPart.Points.CreatePoint(cAEEdge2, SmartObject.UpdateOption.AfterModeling);
                //point2.SetVisibility(SmartObject.VisibilityOption.Visible);

                //Point point3;
                //point3 = workFemPart.Points.CreatePoint(cAEEdge3, SmartObject.UpdateOption.AfterModeling);
                //point3.SetVisibility(SmartObject.VisibilityOption.Visible);



                Bolt bolt1;
                bolt1 = boltBuilder1.CommitBolt();

                theSession.SetUndoMarkName(markId1, "Bolt Connection");
                boltBuilder1.Destroy();
                theSession.CleanUpFacetedFacesAndEdges();
            }
            catch (Exception e)
            {
                Log.Error("Error in creating 1D mesh");
            }



        }

        private void Mesh1DBolt(PartData p1, PartData sP, PartData p2)
        {
            List<CAEEdge> p1WasherEdges = new List<CAEEdge>(0);
            List<CAEEdge> p2WasherEdges = new List<CAEEdge>(0);
            List<CAEEdge> sPWasherEdges = new List<CAEEdge>(0);


            Session theSession = _sessionData.TheSession;
            FemPart workFemPart = ((FemPart)theSession.Parts.BaseWork);
            BodyCollection bodyCollection = workFemPart.Bodies;
            Tag[] polybodies;
            int polygonBodiesCnt;
            _sessionData.TheUfSession.Sf.AskAllPolygonBodies(out polygonBodiesCnt, out polybodies);
            foreach (Tag polybody in polybodies)
            {
                CAEBody caeBody = _sessionData.TheSession.GetObjectManager().GetTaggedObject(polybody) as CAEBody;
                string attributeValue = GetAttribute(caeBody, Constants.PARENT_PART_NO);
                if (!string.IsNullOrEmpty(attributeValue))
                {
                    //p1CaeEdge
                    if (attributeValue.Equals(p1.PartNumber + "_" + p1.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().
                                    GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
                                    p1WasherEdges.Add(caeEdge);
                                }
                            }
                        }
                    }

                    //p2
                    if (attributeValue.Equals(p2.PartNumber + "_" + p2.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
                                    p2WasherEdges.Add(caeEdge);
                                }
                            }
                        }
                    }

                    if (attributeValue.Equals(sP.PartNumber + "_" + sP.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
                                    sPWasherEdges.Add(caeEdge);
                                }
                            }
                        }
                    }
                }
            }

            List<CAEEdge> allWasherEdges = p1WasherEdges.Concat(p2WasherEdges).Concat(sPWasherEdges).ToList();
            foreach (HoleData holeData in sP.HolesData)
            {
                List<CAEEdge> caEEdges = new List<CAEEdge>(0);
                if (holeData.MatingHoles.Any())
                {
                    foreach (CAEEdge washerEdge in p1WasherEdges)
                    {
                        double[] centerSp = AskCaeEdgeParameterAtLocation(washerEdge);
                        bool pointIsInAabb = Operation.PointIsInAabb(centerSp[0], centerSp[1], centerSp[2],
                            holeData.OverAllAaBbBox);
                        if (pointIsInAabb)
                        {
                            caEEdges.Add(washerEdge);
                            break;
                        }
                    }
                    foreach (CAEEdge washerEdge in p2WasherEdges)
                    {
                        double[] centerSp = AskCaeEdgeParameterAtLocation(washerEdge);
                        bool pointIsInAabb = Operation.PointIsInAabb(centerSp[0], centerSp[1], centerSp[2],
                            holeData.OverAllAaBbBox);
                        if (pointIsInAabb)
                        {
                            caEEdges.Add(washerEdge);
                            break;
                        }
                    }
                    foreach (CAEEdge washerEdge in sPWasherEdges)
                    {
                        double[] centerSp = AskCaeEdgeParameterAtLocation(washerEdge);
                        bool pointIsInAabb = Operation.PointIsInAabb(centerSp[0], centerSp[1], centerSp[2],
                            holeData.OverAllAaBbBox);
                        if (pointIsInAabb)
                        {
                            caEEdges.Add(washerEdge);
                            break;
                        }
                    }

                    if (caEEdges.Any() && caEEdges.Count == 3)
                    {
                        try
                        {
                            BaseFEModel feModel = workFemPart.BaseFEModel;
                            BoltBuilder boltBuilder1 = feModel.Bolts.CreateBoltBuilder(null);
                            MeshCollector meshCollector1;
                            meshCollector1 = boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer;
                            boltBuilder1.ShankElementType.DestinationCollector.ElementContainer = meshCollector1;
                            boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer = meshCollector1;

                            boltBuilder1.HeadSpiderScale = 120.0;
                            boltBuilder1.NutSpiderScale = 120.0;
                            boltBuilder1.JunctionSpiderScale = 120.0;
                            boltBuilder1.Junction1SpiderScale = 120.0;
                            boltBuilder1.Junction2SpiderScale = 120.0;

                            boltBuilder1.ShankElementType.ElementDimension = ElementTypeBuilder.ElementType.Beam;
                            boltBuilder1.ShankElementType.DestinationCollector.ElementContainer = null;

                            boltBuilder1.SpiderElementType.ElementDimension = ElementTypeBuilder.ElementType.Spider;
                            boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer = null;

                            boltBuilder1.Junction = true;
                            boltBuilder1.ShankElementType.ElementTypeName = "RBE2";
                            boltBuilder1.SpiderElementType.ElementTypeName = "RBE2";
                            boltBuilder1.Midnode = true;

                            

                            TaggedObject[] objects1 = new TaggedObject[1];
                            objects1[0] = caEEdges[0];
                            
                            bool added1;
                            added1 = boltBuilder1.HeadEdge.Add(objects1);

                            TaggedObject[] objects2 = new TaggedObject[1];
                            objects2[0] = caEEdges[1];
                            bool added2;
                            added2 = boltBuilder1.NutEdge.Add(objects2);

                            TaggedObject[] objects3 = new TaggedObject[1];
                            objects3[0] = caEEdges[2];
                            bool added3;
                            added3 = boltBuilder1.JunctionEdge.Add(objects3);

                            boltBuilder1.Junction = true;
                            boltBuilder1.OperationType = BoltBuilder.BoltOperation.BoltNut;
                            boltBuilder1.SpiderElementType.ElementDimension = ElementTypeBuilder.ElementType.Spider;
                            boltBuilder1.SpiderElementType.ElementTypeName = "RBE2";

                            DestinationCollectorBuilder destinationCollectorBuilder1 = boltBuilder1.ShankElementType.DestinationCollector;
                            destinationCollectorBuilder1.ElementContainer = null;
                            destinationCollectorBuilder1.AutomaticMode = true;



                            DestinationCollectorBuilder destinationCollectorBuilder2 = boltBuilder1.SpiderElementType.DestinationCollector;
                            destinationCollectorBuilder2.ElementContainer = null;
                            destinationCollectorBuilder2.AutomaticMode = true;



                            //Point point1;
                            //point1 = workFemPart.Points.CreatePoint(cAEEdge1, SmartObject.UpdateOption.AfterModeling);
                            //point1.SetVisibility(SmartObject.VisibilityOption.Visible);

                            //Point point2;
                            //point2 = workFemPart.Points.CreatePoint(cAEEdge2, SmartObject.UpdateOption.AfterModeling);
                            //point2.SetVisibility(SmartObject.VisibilityOption.Visible);

                            //Point point3;
                            //point3 = workFemPart.Points.CreatePoint(cAEEdge3, SmartObject.UpdateOption.AfterModeling);
                            //point3.SetVisibility(SmartObject.VisibilityOption.Visible);



                            Bolt bolt1;
                            bolt1 = boltBuilder1.CommitBolt();

                            //theSession.SetUndoMarkName(markId1, "Bolt Connection");
                            boltBuilder1.Destroy();
                            theSession.CleanUpFacetedFacesAndEdges();
                        }
                        catch (Exception e)
                        {
                            Log.Error("Error in creating 1D mesh");
                        }
                    }
                }
            }
        }
        private void Mesh1DBolt(PartData p1, PartData p2)
        {
            List<CAEEdge> p1WasherEdges = new List<CAEEdge>(0);
            List<CAEEdge> p2WasherEdges = new List<CAEEdge>(0);
            List<CAEEdge> sPWasherEdges = new List<CAEEdge>(0);


            Session theSession = _sessionData.TheSession;
            FemPart workFemPart = ((FemPart)theSession.Parts.BaseWork);
            BodyCollection bodyCollection = workFemPart.Bodies;
            Tag[] polybodies;
            int polygonBodiesCnt;
            _sessionData.TheUfSession.Sf.AskAllPolygonBodies(out polygonBodiesCnt, out polybodies);
            foreach (Tag polybody in polybodies)
            {
                CAEBody caeBody = _sessionData.TheSession.GetObjectManager().GetTaggedObject(polybody) as CAEBody;
                string attributeValue = GetAttribute(caeBody, Constants.PARENT_PART_NO);
                if (!string.IsNullOrEmpty(attributeValue))
                {
                    //p1CaeEdge
                    if (attributeValue.Equals(p1.PartNumber + "_" + p1.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().
                                    GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
                                    p1WasherEdges.Add(caeEdge);
                                }
                            }
                        }
                    }

                    //p2
                    if (attributeValue.Equals(p2.PartNumber + "_" + p2.PartId))
                    {
                        int numCaeEdges;
                        Tag[] caeEdges;
                        _sessionData.TheUfSession.Sf.BodyAskEdges(caeBody.Tag, out numCaeEdges, out caeEdges);
                        if (numCaeEdges > 0)
                        {
                            foreach (Tag caeEdgeTag in caeEdges)
                            {
                                CAEEdge caeEdge = _sessionData.TheSession.GetObjectManager().GetTaggedObject(caeEdgeTag) as CAEEdge;
                                if (caeEdge.Name.Contains("WASHER_EDGE"))
                                {
                                    p2WasherEdges.Add(caeEdge);
                                }
                            }
                        }
                    }

                   
                }
            }

            List<CAEEdge> allWasherEdges = p1WasherEdges.Concat(p2WasherEdges).Concat(sPWasherEdges).ToList();
            foreach (HoleData holeData in p1.HolesData)
            {
                List<CAEEdge> caEEdges = new List<CAEEdge>(0);
                if (holeData.MatingHoles.Any())
                {
                    foreach (CAEEdge washerEdge in p1WasherEdges)
                    {
                        double[] centerSp = AskCaeEdgeParameterAtLocation(washerEdge);
                        bool pointIsInAabb = Operation.PointIsInAabb(centerSp[0], centerSp[1], centerSp[2],
                            holeData.OverAllAaBbBox);
                        if (pointIsInAabb)
                        {
                            caEEdges.Add(washerEdge);
                            break;
                        }
                    }
                    foreach (CAEEdge washerEdge in p2WasherEdges)
                    {
                        double[] centerSp = AskCaeEdgeParameterAtLocation(washerEdge);
                        bool pointIsInAabb = Operation.PointIsInAabb(centerSp[0], centerSp[1], centerSp[2],
                            holeData.OverAllAaBbBox);
                        if (pointIsInAabb)
                        {
                            caEEdges.Add(washerEdge);
                            break;
                        }
                    }
                   

                    if (caEEdges.Any() && caEEdges.Count == 2)
                    {
                        try
                        {
                            BaseFEModel feModel = workFemPart.BaseFEModel;
                            BoltBuilder boltBuilder1 = feModel.Bolts.CreateBoltBuilder(null);
                            MeshCollector meshCollector1;
                            meshCollector1 = boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer;
                            boltBuilder1.ShankElementType.DestinationCollector.ElementContainer = meshCollector1;
                            boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer = meshCollector1;

                            boltBuilder1.HeadSpiderScale = 120.0;
                            boltBuilder1.NutSpiderScale = 120.0;
                            boltBuilder1.JunctionSpiderScale = 120.0;
                            boltBuilder1.Junction1SpiderScale = 120.0;
                            boltBuilder1.Junction2SpiderScale = 120.0;

                            boltBuilder1.ShankElementType.ElementDimension = ElementTypeBuilder.ElementType.Beam;
                            boltBuilder1.ShankElementType.DestinationCollector.ElementContainer = null;

                            boltBuilder1.SpiderElementType.ElementDimension = ElementTypeBuilder.ElementType.Spider;
                            boltBuilder1.SpiderElementType.DestinationCollector.ElementContainer = null;

                            boltBuilder1.Junction = true;
                            boltBuilder1.ShankElementType.ElementTypeName = "RBE2";
                            boltBuilder1.SpiderElementType.ElementTypeName = "RBE2";
                            boltBuilder1.Midnode = true;



                            TaggedObject[] objects1 = new TaggedObject[1];
                            objects1[0] = caEEdges[0];

                            bool added1;
                            added1 = boltBuilder1.HeadEdge.Add(objects1);

                            TaggedObject[] objects2 = new TaggedObject[1];
                            objects2[0] = caEEdges[1];
                            bool added2;
                            added2 = boltBuilder1.NutEdge.Add(objects2);

                            //TaggedObject[] objects3 = new TaggedObject[1];
                            //objects3[0] = caEEdges[2];
                            //bool added3;
                            //added3 = boltBuilder1.JunctionEdge.Add(objects3);

                            boltBuilder1.Junction = false;
                            boltBuilder1.OperationType = BoltBuilder.BoltOperation.BoltNut;
                            boltBuilder1.SpiderElementType.ElementDimension = ElementTypeBuilder.ElementType.Spider;
                            boltBuilder1.SpiderElementType.ElementTypeName = "RBE2";

                            DestinationCollectorBuilder destinationCollectorBuilder1 = boltBuilder1.ShankElementType.DestinationCollector;
                            destinationCollectorBuilder1.ElementContainer = null;
                            destinationCollectorBuilder1.AutomaticMode = true;



                            DestinationCollectorBuilder destinationCollectorBuilder2 = boltBuilder1.SpiderElementType.DestinationCollector;
                            destinationCollectorBuilder2.ElementContainer = null;
                            destinationCollectorBuilder2.AutomaticMode = true;



                            //Point point1;
                            //point1 = workFemPart.Points.CreatePoint(cAEEdge1, SmartObject.UpdateOption.AfterModeling);
                            //point1.SetVisibility(SmartObject.VisibilityOption.Visible);

                            //Point point2;
                            //point2 = workFemPart.Points.CreatePoint(cAEEdge2, SmartObject.UpdateOption.AfterModeling);
                            //point2.SetVisibility(SmartObject.VisibilityOption.Visible);

                            //Point point3;
                            //point3 = workFemPart.Points.CreatePoint(cAEEdge3, SmartObject.UpdateOption.AfterModeling);
                            //point3.SetVisibility(SmartObject.VisibilityOption.Visible);



                            Bolt bolt1;
                            bolt1 = boltBuilder1.CommitBolt();

                            //theSession.SetUndoMarkName(markId1, "Bolt Connection");
                            boltBuilder1.Destroy();
                            theSession.CleanUpFacetedFacesAndEdges();
                        }
                        catch (Exception e)
                        {
                            Log.Error("Error in creating 1D mesh");
                        }
                    }
                }
            }
        }
        public double[] AskCaeEdgeParameterAtLocation(NXOpen.CAE.CAEEdge theCurve)
        {
            double[] arcCenter = new double[3];
            double[] startTangent = new double[3];
            try
            {
                double[] startPt = new double[3];
                double[] endPt = new double[3];
                double[] endTangent = new double[3];
                _sessionData.TheUfSession.Sf.EdgeAskEndPoints(theCurve.Tag,startPt,endPt,startTangent,endTangent);
               
                arcCenter = startPt;
            }
            catch (Exception e)
            {
                Log.Error("Error in getting CAE edge data...");
            }
            

            return arcCenter;
        }
        public List<EdgeData> GetCircularEdgesOfMidSurfaces(PartData iPartData1,PartData iPartData2)
        {
            List<EdgeData> matingCircularEdges = new List<EdgeData>(0);
            List<Feature> midSurfaceFeatures = iPartData1.MidSurfaceFeatures;
            foreach (Feature midSurfaceFeature in midSurfaceFeatures)
            {
                //List<Body> midSurfaceBodies = GetMidSurfaceBodiesFromWorkPart();
                foreach (Body midSurfaceBody in midSurfaceFeature.GetBodies())
                {
                    Face[] faces = midSurfaceBody.GetFaces();
                    foreach (Face midSurfaceFace in faces)
                    {
                        List<EdgeData> circularEdgesOfFace = GetFullCircularEdgesOfFace(midSurfaceFace);
                        if (iPartData1.MatingParts.Any() && circularEdgesOfFace.Any())
                        {
                            matingCircularEdges = GetMatingCircularEdges(iPartData1, midSurfaceFace, iPartData2);
                        }
                    }
                       
                }
            }

            return matingCircularEdges;
        }
        private bool CreateWasherImprintBetweenTwoMatingParts(PartData iPartData1,PartData iPartData2)
        {
            try
            {
                List<Feature> midSurfaceFeatures = iPartData1.MidSurfaceFeatures;
                foreach (Feature midSurfaceFeature in midSurfaceFeatures)
                {
                    //List<Body> midSurfaceBodies = GetMidSurfaceBodiesFromWorkPart();
                    foreach (Body midSurfaceBody in midSurfaceFeature.GetBodies())
                    {
                        try
                        {
                            Face[] faces = midSurfaceBody.GetFaces();
                            foreach (Face midSurfaceFace in faces)
                            {
                                List<EdgeData> circularEdgesOfFace = GetFullCircularEdgesOfFace(midSurfaceFace);
                                if (iPartData1.MatingParts.Any() && circularEdgesOfFace.Any())
                                {
                                    List<EdgeData> matingCircularEdges =
                                        GetMatingCircularEdges(iPartData1, midSurfaceFace, iPartData2);
                                    List<EdgeData> ipart2MidSurfaceCirEdges =
                                        GetCircularEdgesOfMidSurfaces(iPartData2, iPartData1);
                                    if (ipart2MidSurfaceCirEdges.Any() && matingCircularEdges.Any())
                                    {
                                        IEnumerable<IGrouping<double, EdgeData>> edgesGroup =
                                            matingCircularEdges.GroupBy(edges => edges.Diameter);

                                        foreach (IGrouping<double, EdgeData> edgeDataS in edgesGroup)
                                        {
                                            if (edgeDataS.Any())
                                            {
                                                EdgeData firstOrDefault = edgeDataS.FirstOrDefault();
                                                if (firstOrDefault.IsWasherSizeInDb)
                                                {
                                                    double washerDia = firstOrDefault.WasherSize;
                                                    double holeDia = firstOrDefault.Diameter;
                                                    double offset = washerDia - holeDia;
                                                    Edge offsetEdge = firstOrDefault.OEdge;

                                                    List<Edge> edges = new List<Edge>(0);
                                                    List<EdgeData> edgesData = new List<EdgeData>(0);
                                                    foreach (EdgeData edgeData in edgeDataS)
                                                    {
                                                        if (!edgeData.OEdge.Name.Equals("Washer_Edge"))
                                                        {
                                                            edges.Add(edgeData.OEdge);
                                                            edgeData.OEdge.SetName("Washer_Edge");
                                                            iPartData1.WasherEdgesData.Add(edgeData);
                                                            edgesData.Add(edgeData);
                                                        }
                                                    }

                                                    if (edges.Any())
                                                    {
                                                        List<Curve> arcs = DrawCircle(edgesData);
                                                        DivideFace1(iPartData1, midSurfaceBody, arcs);
                                                        //OffsetEdge(offset.ToString(), midSurfaceBody, edges);
                                                        //DivideFace(offset.ToString(), midSurfaceBody, edges);
                                                    }
                                                }

                                            }
                                        }
                                    }
                                }

                            }
                        }
                        catch (Exception e)
                        {
                            Log.Error("Error in creating washer imprint");
                        }

                    }
                }
            }
            catch (Exception e)
            {
                return false;
            }


            return false;

        }

        public List<EdgeData> GetMatingCircularEdges(PartData partData, Face midSurfaceFace, PartData matingPartData)
        {
            List<EdgeData> reqCircularEdge = new List<EdgeData>(0);
            double[] midSurfFaceNormal = GetFaceNormal(midSurfaceFace);
            List<EdgeData> circularEdgesOfFace = GetFullCircularEdgesOfFace(midSurfaceFace);
            //foreach (HoleData holeData in partData.HolesData)
            //{
            //    if (partData.MeshType == Constants.MeshType.Mesh2D)
            //    {
            //        List<HoleData> holeDataMatingHoles = matingPartData.HolesData;
            //        if (holeDataMatingHoles.Any())
            //        {
            //            foreach (HoleData matingHoleData in holeDataMatingHoles)
            //            {
            //                if (matingHoleData.ParentPartData.MeshType == Constants.MeshType.Mesh2D)
            //                {
            //                    foreach (EdgeData edgeData in circularEdgesOfFace)
            //                    {
            //                        double[] ec = edgeData.Center;
            //                        bool pointIsInAabb = Operation.PointIsInAabb(ec[0], ec[1], ec[2],
            //                            matingHoleData.OverAllAaBbBox);
            //                        if (pointIsInAabb)
            //                        {
            //                            reqCircularEdge.Add(edgeData);
            //                            //edgeData.OEdge.SetName("PossibleWasherEdge");
            //                        }
            //                    }
            //                }

            //            }

            //        }
            //    }
            //}
            //foreach (PartData partDataMatingPart in partData.MatingParts)
            {
                //Filter required Edges which are mating
                foreach (EdgeData edgeData in circularEdgesOfFace)
                {
                    foreach (HoleData matingHoleData in matingPartData.HolesData)
                    {
                        var rayCorrectDir = new AabbTreeRay
                        {
                            Direction = new Vector3(matingHoleData.HoleDirection[0], matingHoleData.HoleDirection[1], matingHoleData.HoleDirection[2]),
                            Origin = new Point3(edgeData.Center[0], edgeData.Center[1], edgeData.Center[2])
                        };

                        //If Circular edge is intersecting holes
                        bool intersectRay2 = Operation.IntersectRayBox4(matingHoleData.AabbBox, rayCorrectDir);
                        if (intersectRay2)
                        {
                            if (!reqCircularEdge.Contains(edgeData))
                            {
                                reqCircularEdge.Add(edgeData);


                                int parentHoleId = 0;
                                foreach (HoleData parentHoleData in partData.HolesData)
                                {
                                    double[] ec = edgeData.Center;
                                    bool pointIsInAabb = Operation.PointIsInAabb(ec[0], ec[1], ec[2], parentHoleData.AabbBox);
                                    if (pointIsInAabb)
                                    {
                                        parentHoleId = parentHoleData.ID;
                                        break;
                                    }
                                }
                                edgeData.OEdge.SetName("WASHER_EDGE");
                               // edgeData.OEdge.SetName(parentHoleId + "_WasherEdge_" + matingHoleData.ID);
                            }
                        }

                        //Reverse the direction
                        rayCorrectDir = new AabbTreeRay
                        {
                            Direction =
                                new Vector3(-matingHoleData.HoleDirection[0], -matingHoleData.HoleDirection[1], -matingHoleData.HoleDirection[2]),
                            Origin = new Point3(edgeData.Center[0], edgeData.Center[1], edgeData.Center[2])
                        };

                        //If Circular edge is intersecting holes
                        bool intersectRay = Operation.IntersectRayBox4(matingHoleData.AabbBox, rayCorrectDir);
                        if (intersectRay)
                        {
                            if (!reqCircularEdge.Contains(edgeData))
                            {
                                reqCircularEdge.Add(edgeData);
                                edgeData.OEdge.SetName("WASHER_EDGE");
                            }
                        }
                    }
                }
            }

            return reqCircularEdge;
        }
        public void AddLinkedBodiesToFemPart(FemPart iFemPart)
        {
            PartLoadStatus partLoadStatus;
            _sessionData.TheSession.Parts.SetActiveDisplay(iFemPart,
                DisplayPartOption.ReplaceExisting, PartDisplayPartWorkPartOption.SameAsDisplay,
                out partLoadStatus);

            partLoadStatus.Dispose();

            FemPart workFemPart = ((FemPart)_sessionData.TheSession.Parts.BaseWork);
            FemPart displayFemPart = ((FemPart)_sessionData.TheSession.Parts.BaseDisplay);

           
            Part idealizedPart = workFemPart.IdealizedPart;
            Body[] bodies = idealizedPart.Bodies.ToArray();
            List<Body> visBodies = new List<Body>(0);
            foreach (Body body in bodies)
            {
                if (!body.IsBlanked)
                {
                    visBodies.Add(body);
                }
            }

            if (visBodies.Any())
            {
                FemSynchronizeOptions newFemSynchronizeOptions = workFemPart.NewFemSynchronizeOptions();
                workFemPart.SetGeometryData(FemPart.UseBodiesOption.VisibleBodies, visBodies.ToArray(), newFemSynchronizeOptions);
                newFemSynchronizeOptions.Dispose();

                BodyCollection bodyCollection = workFemPart.Bodies;
                foreach (CAEBody body in bodyCollection)
                {
                    string attribute = GetAttribute(body, Constants.PARENT_PART_NO);
                    if (!string.IsNullOrEmpty(attribute))
                    {
                    }

                }
            }
       
        }

        public List<Curve> DrawCircle(List<EdgeData> edgesData)
        {
            List<Curve> createdCurves = new List<Curve>(0);
            Session theSession = _sessionData.TheSession;
            Part workPart = theSession.Parts.Work;

            Session.UndoMarkId markId1;
            markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start");
            foreach (EdgeData edgeData in edgesData)
            {
                try
                {
                    var associativeArcBuilder1 = workPart.BaseFeatures.CreateAssociativeArcBuilder((AssociativeArc)null);

                    Point3d origin1 = new Point3d(0.0, 0.0, 0.0);
                    Vector3d normal1 = new Vector3d(0.0, 0.0, 1.0);
                    Plane plane1;
                    plane1 = workPart.Planes.CreatePlane(origin1, normal1, SmartObject.UpdateOption.WithinModeling);

                    Unit unit1;
                    unit1 = associativeArcBuilder1.Radius.Units;

                    Expression expression1;
                    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1);
                    Expression expression2;
                    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1);


                    associativeArcBuilder1.Associative = false;
                    associativeArcBuilder1.Type = AssociativeArcBuilder.Types.ArcFromCenter;
                    associativeArcBuilder1.EndPointOptions = AssociativeArcBuilder.EndOption.Diameter;
                    associativeArcBuilder1.Diameter.SetFormula(edgeData.WasherSize.ToString());
                    associativeArcBuilder1.Limits.FullCircle = true;
                    theSession.SetUndoMarkName(markId1, "Arc/Circle Dialog");
                    Point point1;
                    point1 = workPart.Points.CreatePoint(edgeData.OEdge, SmartObject.UpdateOption.WithinModeling);
                    associativeArcBuilder1.CenterPoint.Value = point1;

                    Session.UndoMarkId markId3;
                    markId3 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Arc/Circle");

                    NXObject nXObject1;
                    nXObject1 = associativeArcBuilder1.Commit();

                    NXObject[] objects1;
                    objects1 = associativeArcBuilder1.GetCommittedObjects();
                    if (objects1.Any())
                    {
                        foreach (NXObject nxObject in objects1)
                        {
                            if (nxObject is Curve)
                            {
                                createdCurves.Add(nxObject as Curve);
                            }
                        }
                    }
                    theSession.DeleteUndoMark(markId3, null);
                    theSession.SetUndoMarkName(markId1, "Arc/Circle");
                    associativeArcBuilder1.Destroy();

                    try
                    {
                        // Expression is still in use.
                        workPart.Expressions.Delete(expression2);
                    }
                    catch (NXException ex)
                    {
                        ex.AssertErrorCode(1050029);
                    }

                    try
                    {
                        // Expression is still in use.
                        workPart.Expressions.Delete(expression1);
                    }
                    catch (NXException ex)
                    {
                        ex.AssertErrorCode(1050029);
                    }
                    plane1.DestroyPlane();
                    theSession.CleanUpFacetedFacesAndEdges();
                }
                catch (Exception e)
                {
                    
                }
            }

            return createdCurves;
        }
        public void OffsetEdge(string iOffset, Body iBody, List<Edge> iEdges)
        {
            Session theSession = _sessionData.TheSession;
            Part workPart = theSession.Parts.Work;
            foreach (Edge iEdge in iEdges)
            {


                Session.UndoMarkId markId1;
                markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start");
                try
                {

                    OffsetEdgeBuilder offsetEdgeBuilder1 =
                        workPart.Features.SynchronousEdgeCollection.CreateOffsetEdgeBuilder(null);

                    var selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions();
                    selectionIntentRuleOptions2.SetSelectedFromInactive(false);
                    Edge[] edges1 = new Edge[1];
                    edges1[0] = iEdge;
                    //for (int i = 0; i < iEdges.Count; i++)
                    //{
                    //    edges1[i] = iEdges[i];
                    //}

                    var edgeDumbRule1 = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges1, selectionIntentRuleOptions2);
                    selectionIntentRuleOptions2.Dispose();
                    SelectionIntentRule[] rules1 = new SelectionIntentRule[1];
                    rules1[0] = edgeDumbRule1;
                    offsetEdgeBuilder1.EdgeToOffset.ReplaceRules(rules1, false);

                    offsetEdgeBuilder1.ReverseOffsetSide = false;
                    offsetEdgeBuilder1.Method = OffsetEdgeBuilder.OffsetEdgeMethod.AlongPlaneofEdge;
                    offsetEdgeBuilder1.EndFaceBehavior = OffsetEdgeBuilder.EndFaceBehaviourType.Morph;
                    offsetEdgeBuilder1.Distance.SetFormula(iOffset);


                    Session.UndoMarkId markId3;
                    markId3 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Offset Edge");


                    NXObject nXObject1;
                    if (offsetEdgeBuilder1.Validate())
                    {
                        try
                        {
                            nXObject1 = offsetEdgeBuilder1.Commit();
                        }
                        catch (Exception e)
                        {
                            offsetEdgeBuilder1.ReverseOffsetSide = true;
                            nXObject1 = offsetEdgeBuilder1.Commit();
                        }

                    }

                    theSession.DeleteUndoMark(markId3, null);
                    Expression expression1 = offsetEdgeBuilder1.Distance;
                    offsetEdgeBuilder1.Destroy();
                }
                catch (Exception e)
                {
                    theSession.UndoToMark(markId1, "Undo Offset Edge");
                }

                theSession.CleanUpFacetedFacesAndEdges();
                theSession.DeleteUndoMark(markId1, null);
            }

        }

        public void DivideFace1(PartData partData,Body iBody,List<Curve> iCurves)
        {
            try
            {
                Session theSession = _sessionData.TheSession;
                Part workPart = theSession.Parts.Work;
                Session.UndoMarkId markId1;
                markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start");
                theSession.SetUndoMarkName(markId1, "Divide Face Dialog");

                var dividefaceBuilder1 = workPart.Features.CreateDividefaceBuilder(null);
                dividefaceBuilder1.BlankOption = true;

                var projectionOptions1 = dividefaceBuilder1.ProjectionOption;

                var section1 = dividefaceBuilder1.SelectDividingObject.CurvesToOffset;
                section1.DistanceTolerance = 0.01;
                section1.ChainingTolerance = 0.01;

                //Face Collector from body
                var scCollector1 = workPart.ScCollectors.CreateCollector();
                SelectionIntentRuleOptions selectionIntentRuleOptions1;
                selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions();
                selectionIntentRuleOptions1.SetSelectedFromInactive(false);
                Body body1 = iBody;
                FaceBodyRule faceBodyRule1;
                faceBodyRule1 = workPart.ScRuleFactory.CreateRuleFaceBody(body1, selectionIntentRuleOptions1);
                selectionIntentRuleOptions1.Dispose();
                SelectionIntentRule[] rules1 = new SelectionIntentRule[1];
                rules1[0] = faceBodyRule1;
                scCollector1.ReplaceRules(rules1, false);
                dividefaceBuilder1.FacesToDivide = scCollector1;

                var section2 = workPart.Sections.CreateSection(0.01, 0.01, 0.5);
                section2.SetAllowedEntityTypes(Section.AllowTypes.OnlyCurves);
                bool added1;
                added1 = dividefaceBuilder1.SelectDividingObject.DividingObjectsList.Add(section2);

               var selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions();
                selectionIntentRuleOptions2.SetSelectedFromInactive(false);

                IBaseCurve[] curves1 = new IBaseCurve[iCurves.Count];
                for (int i = 0; i < iCurves.Count; i++)
                {
                    curves1[i] = iCurves[i];
                }
                CurveDumbRule curveDumbRule1;
                curveDumbRule1 = workPart.ScRuleFactory.CreateRuleBaseCurveDumb(curves1, selectionIntentRuleOptions2);
                selectionIntentRuleOptions2.Dispose();
                section2.AllowSelfIntersection(true);
                section2.AllowDegenerateCurves(false);

                SelectionIntentRule[] rules2 = new SelectionIntentRule[1];
                rules2[0] = curveDumbRule1;
                Point3d[] askCurveEnds = AskCurveEnds(iCurves[0]);
                Point3d helpPoint1 = askCurveEnds[0];
                section2.AddToSection(rules2, iCurves[0], null, null, helpPoint1, Section.Mode.Create, false);

                projectionOptions1.ProjectDirectionMethod = ProjectionOptions.DirectionType.FaceNormal;

                
                projectionOptions1.ProjectVector = null;



                Session.UndoMarkId markId5;
                markId5 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, "Divide Face");

                Feature feature1;
                feature1 = dividefaceBuilder1.CommitFeature();

                theSession.DeleteUndoMark(markId5, null);

                theSession.SetUndoMarkName(markId1, "Divide Face");

                dividefaceBuilder1.Destroy();

                theSession.CleanUpFacetedFacesAndEdges();
                if (feature1 != null)
                {
                    partData.DivideSurfaceFeatures.Add(feature1);
                    Body[] bodies = feature1.GetBodies();
                    foreach (Body body in bodies)
                    {
                        body.SetName("DF_" + partData.LinkedBodyFeature.Name);
                        SetAttribute(body,Constants.PARENT_PART_NO, partData.PartNumber + "_" + partData.PartId);
                    }
                }
            }
            catch (Exception e)
            {
                
            }
        }

        public Point3d[] AskCurveEnds(Curve theCurve)
        {
            double[] limits = new double[2];
            IntPtr evaluator;
            double[] start = new double[3];
            double[] end = new double[3];

            _sessionData.TheUfSession.Eval.Initialize2(theCurve.Tag, out evaluator);
            _sessionData.TheUfSession.Eval.AskLimits(evaluator, limits);
            _sessionData.TheUfSession.Eval.Evaluate(evaluator, 0, limits[0], start, new double[] { });
            _sessionData.TheUfSession.Eval.Evaluate(evaluator, 0, limits[1], end, new double[] { });
            _sessionData.TheUfSession.Eval.Free(evaluator);

            return new[]
            { new Point3d(start[0], start[1], start[2]),
                new Point3d(end[0], end[1], end[2]) };
        }
        public void DivideFace(string iOffset, Body iBody, List<Edge> iEdges)
        {
            Session.UndoMarkId markId1;
            markId1 = _sessionData.TheSession.SetUndoMark(Session.MarkVisibility.Visible, "Start");
            try
            {
                Part workPart = _sessionData.TheSession.Parts.Work;
                DividefaceBuilder divideFaceBuilder =
                    _sessionData.TheSession.Parts.Work.Features.CreateDividefaceBuilder(null);
                divideFaceBuilder.SelectDividingObject.ToolOption =
                    SelectDividingObjectBuilder.ToolType.OffsetCurveInFace;
                divideFaceBuilder.SelectDividingObject.OffsetDistance.SetFormula(iOffset);
                divideFaceBuilder.BlankOption = true;
                var projectionOptions1 = divideFaceBuilder.ProjectionOption;
                var section1 = divideFaceBuilder.SelectDividingObject.CurvesToOffset;
                section1.DistanceTolerance = 0.01;
                section1.ChainingTolerance = 0.0094999999999999998;
                var scCollector1 = workPart.ScCollectors.CreateCollector();
                var selectionIntentRuleOptions1 = workPart.ScRuleFactory.CreateRuleOptions();
                selectionIntentRuleOptions1.SetSelectedFromInactive(false);
                var faceBodyRule1 = workPart.ScRuleFactory.CreateRuleFaceBody(iBody, selectionIntentRuleOptions1);
                selectionIntentRuleOptions1.Dispose();
                SelectionIntentRule[] rules1 = new SelectionIntentRule[1];
                rules1[0] = faceBodyRule1;
                scCollector1.ReplaceRules(rules1, false);
                divideFaceBuilder.FacesToDivide = scCollector1;
                section1.SetAllowedEntityTypes(Section.AllowTypes.OnlyCurves);
                var selectionIntentRuleOptions2 = workPart.ScRuleFactory.CreateRuleOptions();
                selectionIntentRuleOptions2.SetSelectedFromInactive(false);
                Edge[] edges1 = new Edge[iEdges.Count];
                for (int i = 0; i < iEdges.Count; i++)
                {
                    edges1[i] = iEdges[i];
                }
                
                var edgeDumbRule1 = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges1, selectionIntentRuleOptions2);
                selectionIntentRuleOptions2.Dispose();
                section1.AllowSelfIntersection(true);
                section1.AllowDegenerateCurves(false);
                SelectionIntentRule[] rules2 = new SelectionIntentRule[1];
                rules2[0] = edgeDumbRule1;
                double[] circularEdgeCenter = GetCircularEdgeCenter(iEdges[0]);
                Point3d helpPoint1 = new Point3d(circularEdgeCenter[0], circularEdgeCenter[1], circularEdgeCenter[2]);
                section1.AddToSection(rules2, iEdges[0], null, null, helpPoint1,
                    Section.Mode.Create, false);
                var section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5);
                projectionOptions1.ProjectDirectionMethod =
                    ProjectionOptions.DirectionType.FaceNormal;
                divideFaceBuilder.SelectDividingObject.OffsetDirection = true;
                projectionOptions1.ProjectVector = null;
                projectionOptions1.ProjectDirectionMethod =
                    ProjectionOptions.DirectionType.FaceNormal;
                divideFaceBuilder.CommitFeature();
                Expression expression1 = divideFaceBuilder.SelectDividingObject.OffsetDistance;
                divideFaceBuilder.Destroy();
                section2.Destroy();
                _sessionData.TheSession.CleanUpFacetedFacesAndEdges();
            }
            catch (Exception e)
            {
                Log.Error("Error in creating Divide Face...", e);
                _sessionData.TheSession.UndoToMark(markId1, "Divide Face");
            }
            _sessionData.TheSession.SetUndoMarkName(markId1, "Divide Face");
            _sessionData.TheSession.DeleteUndoMark(markId1, null);

            
        }

        public double[] GetCircularEdgeCenter(Edge iEdge)
        {
            double[] center = new double[3];
            if (iEdge.SolidEdgeType == Edge.EdgeType.Circular)
            {
                IntPtr arcEvaluator;
                UFEval.Arc arcData;

                _sessionData.TheUfSession.Eval.Initialize(iEdge.Tag, out arcEvaluator);
                _sessionData.TheUfSession.Eval.AskArc(arcEvaluator, out arcData);
                center = arcData.center;
                _sessionData.TheUfSession.Eval.Free(arcEvaluator);
            }
            return center;
        }
        public double GetCircularEdgeDiameter(Edge iEdge)
        {
            double dia = 0.0;
            
            if (iEdge.SolidEdgeType == Edge.EdgeType.Circular)
            {
                IntPtr arcEvaluator;
                UFEval.Arc arcData;

                _sessionData.TheUfSession.Eval.Initialize(iEdge.Tag, out arcEvaluator);
                _sessionData.TheUfSession.Eval.AskArc(arcEvaluator, out arcData);
                _sessionData.TheUfSession.Eval.Free(arcEvaluator);
                dia = Math.Round(arcData.radius *2, 1);
            }
            return dia;
        }
        /// <summary>
        /// Get Circular Edges of the face
        /// </summary>
        /// <param name="iFace"></param>
        /// <returns></returns>
        //public List<Edge> GetFullCircularEdgesOfFace(Face iFace)
        //{
        //    List<Edge> circularEdge = new List<Edge>(0);
        //    Edge[] edges = iFace.GetEdges();
        //    foreach (Edge edge in edges)
        //    {
        //        if (edge.SolidEdgeType == Edge.EdgeType.Circular && IsEdgeClosed(edge))
        //        {
        //            EdgeData edgeData = new EdgeData(edge);
        //            edgeData.Diameter = GetCircularEdgeDiameter(edge);
        //            edgeData.Center = GetCircularEdgeCenter(edge);
        //            circularEdge.Add(edge);
        //        }
        //    }

        //    return circularEdge;
        //}

        public List<EdgeData> GetFullCircularEdgesOfFace(Face iFace)
        {
            List<EdgeData> circularEdge = new List<EdgeData>(0);
            Edge[] edges = iFace.GetEdges();
            foreach (Edge edge in edges)
            {
                if (edge.SolidEdgeType == Edge.EdgeType.Circular && IsEdgeClosed(edge))
                {
                    EdgeData edgeData = new EdgeData(edge);
                    edgeData.Diameter = GetCircularEdgeDiameter(edge);
                    edgeData.Center = GetCircularEdgeCenter(edge);
                    if (FastenersSizes.ContainsKey(edgeData.Diameter))
                    {
                        double washerSize = FastenersSizes[edgeData.Diameter];
                        edgeData.IsWasherSizeInDb = true;
                        edgeData.WasherSize = washerSize;
                    }
                    circularEdge.Add(edgeData);
                }
            }

            return circularEdge;
        }

        /// <summary>
        /// Returns whether a curve is a closed curve or not.
        /// </summary>
        /// <param name="theEdge"></param>
        /// <returns>true/false</returns>
        public bool IsEdgeClosed(Edge theEdge)
        {
            bool isClosed = false;
            int askCurveClosed = _sessionData.TheUfSession.Modl.AskCurveClosed(theEdge.Tag);
            switch (askCurveClosed)
            {
                case 0:
                    isClosed = false;
                    break;
                case 1:
                    isClosed = true;
                    break;
            }
            return isClosed;
        }

        /// <summary>
        /// Get Parent component of Linked feature
        /// </summary>
        /// <param name="iLinkedFeature"></param>
        public Component GetLinkedFeatureParentComponent(Feature iLinkedFeature)
        {
            try
            {
                Tag xform;
               _sessionData.TheUfSession.Wave.AskLinkXform(iLinkedFeature.Tag, out xform);
                Tag from_part_occ;
                _sessionData.TheUfSession.So.AskAssyCtxtPartOcc(xform, _sessionData.TheSession.Parts.Work.ComponentAssembly.RootComponent.Tag, out from_part_occ);
                Component theComponent = (Component)NXObjectManager.Get(from_part_occ);
                return theComponent;
                //theSession.Information.DisplayObjectsDetails(new DisplayableObject[] { theComponent });
                //theComponent.Highlight();
                //theUFSession.Ui.DisplayMessage("Linked from " + theComponent.DisplayName, 1);
                //theComponent.Unhighlight();
            }
            catch (NXException ex)
            {
                Log.Error("Error in finding parent component of linked feature...",ex);
            }

            return null;
        }

        /// <summary>
        /// returns true when the passed workpart is a assembly
        /// </summary>
        /// <param name="workpart"></param>
        /// <returns></returns>
        public bool WorkPartIsAssembly(Part workpart)
        {
            bool isAssembly = workpart.ComponentAssembly.RootComponent == null ? false : true;
            return isAssembly;
        }

        /// <summary>
        /// returns true when the passed component is a assembly
        /// </summary>
        /// <param name="iComponent"></param>
        /// <returns></returns>
        public bool ComponentIsAssembly(Component iComponent)
        {
            bool isAssembly = iComponent.GetChildren().Any();
            return isAssembly;
        }

        /// <summary>
        /// Set display state of NX
        /// </summary>
        /// <param name="iState"></param>
        public void DisplaySupress(int iState)
        {
            if (iState == 0)
            {
                _sessionData.TheUfSession.Disp.SetDisplay(UFConstants.UF_DISP_SUPPRESS_DISPLAY);
            }
            if (iState == 1)
            {
                _sessionData.TheUfSession.Disp.SetDisplay(UFConstants.UF_DISP_UNSUPPRESS_DISPLAY);
                _sessionData.TheUfSession.Disp.RegenerateDisplay();
            }

        }

        /// <summary>
        /// Setting Work in Progress state
        /// </summary>
        /// <param name="state"></param>
        public void WorkInProgress(int state)
        {
            if (state == 0)
            {
                _sessionData.TheUfSession.Abort.EnableAbort();
            }
            else
            {
                _sessionData.TheUfSession.Abort.DisableAbort();
            }
            
        }

        /// <summary>
        /// Get All tangent faces for a given face
        /// </summary>
        /// <param name="iFace"></param>
        /// <returns></returns>
        public List<Face> GetTangentFaces(Face iFace)
        {
            FaceTangentRule faceTangent =
                _sessionData.TheSession.Parts.Work.ScRuleFactory.CreateRuleFaceTangent(iFace, new Face[] { });
            ScCollector scCollector1 = _sessionData.TheSession.Parts.Work.ScCollectors.CreateCollector();
            scCollector1.ReplaceRules(new SelectionIntentRule[] { faceTangent }, false);
            TaggedObject[] tanFaces = scCollector1.GetObjects();
            List<Face> faceList =
                new List<Face>();
            foreach (TaggedObject taggedObject in tanFaces)
            {
                Face face = taggedObject as Face;
                faceList.Add(face);
            }
            return faceList;
        }

        /// <summary>
        /// Hide displayable object
        /// </summary>
        /// <param name="iDisplayableObject"></param>
        public void Hide(DisplayableObject iDisplayableObject)
        {
            iDisplayableObject.Blank();
        }

        /// <summary>
        /// Show displayable Object
        /// </summary>
        /// <param name="iDisplayableObject"></param>
        public void Show(DisplayableObject iDisplayableObject)
        {
            iDisplayableObject.Unblank();
        }

        public void SetAttribute(Body iBody,string iName,string iValue)
        {
            if (iBody != null)
            {
                iBody.SetUserAttribute(iName,-1,iValue,Update.Option.Now);
            }
        }

        public string GetAttribute(Body iBody, string iName)
        {
            if (iBody != null && iBody.HasUserAttribute(iName,NXObject.AttributeType.String,-1))
            {
                NXObject.AttributeInformation attributeInformation = 
                    iBody.GetUserAttribute(iName,NXObject.AttributeType.String,-1);
                return attributeInformation.StringValue;
            }

            return string.Empty;
        }

        public string GetAttribute(NXObject nxobject, string iName)
        {
            if (nxobject != null && nxobject.HasUserAttribute(iName, NXObject.AttributeType.String, -1))
            {
                NXObject.AttributeInformation attributeInformation =
                    nxobject.GetUserAttribute(iName, NXObject.AttributeType.String, -1);
                return attributeInformation.StringValue;
            }

            return string.Empty;
        }
        public string GetAttribute(Component iComponent, string iName)
        {
            if (iComponent != null && iComponent.HasUserAttribute(iName, NXObject.AttributeType.String, -1))
            {
                NXObject.AttributeInformation attributeInformation =
                    iComponent.GetUserAttribute(iName, NXObject.AttributeType.String, -1);
                return attributeInformation.StringValue;
            }

            return string.Empty;
        }
        public string GetAttribute(CAEBody iBody, string iName)
        {
            if (iBody != null && iBody.HasUserAttribute(iName, NXObject.AttributeType.String, -1))
            {
                NXObject.AttributeInformation attributeInformation =
                    iBody.GetUserAttribute(iName, NXObject.AttributeType.String, -1);
                return attributeInformation.StringValue;
            }

            return string.Empty;
        }

        public void Highlight(PartData iPartData)
        {
            PartCleanUp();
            iPartData.CadComponent.Highlight();
        }
        public void UnHighlight(Component iComponent)
        {
            iComponent.Unhighlight();
        }



        public ClearanceSet ClearanceAnalysisBetweenAllBodies(Body[] iBodies, double dClearanceThreshold)
        {
            ClearanceSet objClearanceSet = null;
            ClearanceAnalysisBuilder objClearanceAnalysisBuilder = null;
            Expression expression1 = null;
            Unit objUnit = null;
            NXObject nXObject1 = null;

            objClearanceAnalysisBuilder =
                _sessionData.TheSession.Parts.Work.AssemblyManager.CreateClearanceAnalysisBuilder(null);

            expression1 = objClearanceAnalysisBuilder.CreateClearanceZoneExpression("0.0");
            objClearanceAnalysisBuilder.SetDefaultClearanceZone(expression1);

            objUnit = _sessionData.TheSession.Parts.Work.UnitCollection.FindObject("MilliMeter");
            expression1.Units = objUnit;

            objClearanceAnalysisBuilder.CalculationMethod =
                ClearanceAnalysisBuilder.CalculationMethodType.Exact;

            objClearanceAnalysisBuilder.IsCalculatePenetrationDepth = false;

            objClearanceAnalysisBuilder.ClearanceSetName = "VectraSet";

            objClearanceAnalysisBuilder.CollectionOneRange = ClearanceAnalysisBuilder.CollectionRange.SelectedObjects;

            objClearanceAnalysisBuilder.ClearanceBetween = ClearanceAnalysisBuilder.ClearanceBetweenEntity.Bodies;

            //expression1.RightHandSide = "5"
            expression1.RightHandSide = "0.0";

            //one Set
            foreach (Body iBody in iBodies)
            {
                if (!iBody.IsBlanked)
                {
                    objClearanceAnalysisBuilder.CollectionOneObjects.Add(iBody);
                }
            }

            //Commit the analysis
            nXObject1 = objClearanceAnalysisBuilder.Commit();
            objClearanceAnalysisBuilder.Destroy();

            objClearanceSet = (ClearanceSet)nXObject1;
            objClearanceSet.PerformAnalysis(ClearanceSet.ReanalyzeOutOfDateExcludedPairs.False);

            return objClearanceSet;
        }

        public void PartCleanUp()
        {
            PartCleanup partCleanup = _sessionData.TheSession.NewPartCleanup();
            partCleanup.TurnOffHighlighting = true;
            partCleanup.DoCleanup();
            _sessionData.TheSession.CleanUpFacetedFacesAndEdges();
        }

        public void Create2DMesh(List<PartData> iPartsData)
        {
            foreach (PartData partData in iPartsData)
            {
                if (partData.MeshType == Constants.MeshType.Mesh2D)
                {
                    Mesh2D(partData);
                }
            }
        }

        private void Mesh2D(PartData iPartData)
        {
            Session theSession = _sessionData.TheSession;
            FemPart workFemPart = ((FemPart)theSession.Parts.BaseWork);
            FemPart displayFemPart = ((FemPart)theSession.Parts.BaseDisplay);
            /*Assume that a FEM part is work part*/
            FemPart femPart = (FemPart)theSession.Parts.BaseWork;
            BaseFEModel feModel = femPart.BaseFEModel;

            try
            {
                DisplayableObject[] objects1 = new DisplayableObject[1];
                BodyCollection bodyCollection = workFemPart.Bodies;
                foreach (CAEBody body in bodyCollection)
                {
                    string attribute = GetAttribute(body, Constants.PARENT_PART_NO);
                    if (!string.IsNullOrEmpty(attribute))
                    {
                        if (attribute.Equals(iPartData.PartNumber + "_" + iPartData.PartId, StringComparison.CurrentCultureIgnoreCase))
                        {
                            objects1[0] = body;
                            break;
                        }
                    }

                }

                if (objects1[0] != null)
                {
                    // ----------------------------------------------
                    //   Menu: Insert->Mesh->2D Mesh...
                    // ----------------------------------------------
                    Session.UndoMarkId markId1;
                    markId1 = theSession.SetUndoMark(Session.MarkVisibility.Visible, "Start");


                    MeshManager meshManager1 = (MeshManager)feModel.MeshManager;
                    Mesh2dBuilder mesh2dBuilder1 = meshManager1.CreateMesh2dBuilder(null);

                    mesh2dBuilder1.ElementType.ElementTypeName = iPartData.MeshElementType.ToString(); //"CQUAD4";
                    mesh2dBuilder1.ElementType.DestinationCollector.AutomaticMode = false;
                    bool added1;
                    added1 = mesh2dBuilder1.SelectionList.Add(objects1);

                    Unit unit1 = workFemPart.UnitCollection.FindObject("MilliMeter");
                    Unit unit2 = workFemPart.UnitCollection.FindObject("Degrees");

                    //Mesh Parameters
                    mesh2dBuilder1.PropertyTable.SetIntegerPropertyValue("meshing method", 1); //Paver
                    mesh2dBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("quad mesh overall edge size", "6.35",
                        unit1);
                    mesh2dBuilder1.PropertyTable.SetBooleanPropertyValue("mesh transition bool", false);

                    //Advance Property
                    mesh2dBuilder1.PropertyTable.SetBooleanPropertyValue("block decomposition option bool", false);
                    mesh2dBuilder1.PropertyTable.SetBooleanPropertyValue("mapped mesh option bool", true);
                    mesh2dBuilder1.PropertyTable.SetIntegerPropertyValue("quad only option", 2); // oN minimize triangle
                    mesh2dBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("mesh size variation", "10.3", null);
                    mesh2dBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("surface curvature threshold",
                        "5.7024905", unit1);
                    mesh2dBuilder1.PropertyTable.SetIntegerPropertyValue("mesh individual geometry option enum", 0);

                    //Model Cleanup Option
                    mesh2dBuilder1.PropertyTable.SetBooleanPropertyValue("alternate feature abstraction bool", false);
                    mesh2dBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("small feature tolerance", "10", null);
                    mesh2dBuilder1.PropertyTable.SetBooleanPropertyValue("suppress hole option bool", false);
                    mesh2dBuilder1.PropertyTable.SetBooleanPropertyValue("merge edge toggle bool", true);
                    mesh2dBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("edge angle", "15", unit2);
                    mesh2dBuilder1.PropertyTable.SetBooleanPropertyValue("quad mesh edge match toggle", true);
                    mesh2dBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("quad mesh edge match tolerance",
                        "0.02", unit1);


                    //Mesh Collector
                    MeshCollectorBuilder meshCollectorBuilder1 = meshManager1.CreateCollectorBuilder(null, "ThinShell");
                    meshCollectorBuilder1.CollectorName = iPartData.PartNumber; // Collector Name

                    //Physical Properties of Material Selected
                    CaePart caePart1 = workFemPart;
                    PhysicalPropertyTable[] physicalPropertyTables = caePart1.PhysicalPropertyTables.ToArray();
                    int length = physicalPropertyTables.Length;
                    PhysicalPropertyTable physicalPropertyTable1 =
                        caePart1.PhysicalPropertyTables.CreatePhysicalPropertyTable("PSHELL",
                            "NX NASTRAN - Structural", "NX NASTRAN", iPartData.PartNumber + "_"+iPartData.PartId + "_" + length, randomInt.Next());
                    PropertyTable propertyTable1 = physicalPropertyTable1.PropertyTable;

                    Session.UndoMarkId markId6;

                    markId6 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, null);
                    PhysicalMaterial physicalMaterial1 =
                        ((PhysicalMaterial)workFemPart.MaterialManager.PhysicalMaterials.FindObject(
                            "PhysicalMaterial[Steel]"));
                    propertyTable1.SetMaterialPropertyValue("material", false, physicalMaterial1);
                    propertyTable1.SetBaseScalarWithDataPropertyValue("element thickness", iPartData.Thickness,
                        unit1); //Custom Thickness
                    meshCollectorBuilder1.PropertyTable.SetNamedPropertyTablePropertyValue("Shell Property",
                        physicalPropertyTable1);

                    int nErrs1;
                    nErrs1 = theSession.UpdateManager.DoUpdate(markId6);
                    theSession.DeleteUndoMark(markId6, null);
                    MeshCollector meshCollector1 = meshCollectorBuilder1.Commit() as MeshCollector;
                    meshCollectorBuilder1.Destroy();


                    mesh2dBuilder1.ElementType.DestinationCollector.ElementContainer = meshCollector1;
                    Session.UndoMarkId id1;
                    id1 = theSession.NewestVisibleUndoMark;
                    int nErrs2;
                    nErrs2 = theSession.UpdateManager.DoUpdate(id1);

                    Mesh[] meshes1;
                    meshes1 = mesh2dBuilder1.CommitMesh();

                    theSession.SetUndoMarkName(id1, "2D Mesh");

                    mesh2dBuilder1.Destroy();

                    theSession.CleanUpFacetedFacesAndEdges();
                }
            }
            catch (Exception e)
            {
                Log.Error("2D mesh creation failed for " + iPartData.PartNumber);
                Log.Error("Error message",e);
            }
            
        }

        public void Create3DMesh(List<PartData> iPartsData)
        {
            foreach (PartData partData in iPartsData)
            {
                if (partData.MeshType == Constants.MeshType.Mesh3D)
                {
                    Mesh3D(partData);
                }
            }
        }

        private void Mesh3D(PartData iPartData)
        {
            Session theSession = _sessionData.TheSession;
            FemPart workFemPart = ((FemPart)theSession.Parts.BaseWork);
            FemPart displayFemPart = ((FemPart)theSession.Parts.BaseDisplay);
            /*Assume that a FEM part is work part*/
            FemPart femPart = (FemPart)theSession.Parts.BaseWork;
            BaseFEModel feModel = femPart.BaseFEModel;

            try
            {
                DisplayableObject[] objects1 = new DisplayableObject[1];
                BodyCollection bodyCollection = workFemPart.Bodies;
                foreach (CAEBody body in bodyCollection)
                {
                    string attribute = GetAttribute(body, Constants.PARENT_PART_NO);
                    if (!string.IsNullOrEmpty(attribute))
                    {
                        if (attribute.Equals(iPartData.PartNumber + "_" + iPartData.PartId, StringComparison.CurrentCultureIgnoreCase))
                        {
                            objects1[0] = body;
                            break;
                        }
                    }

                }

                if (objects1[0] != null)
                {


                    MeshManager meshManager1 = (MeshManager)feModel.MeshManager;
                    Mesh3dTetBuilder mesh3dTetBuilder1 = meshManager1.CreateMesh3dTetBuilder(null);
                    if (iPartData.MeshElementType == Constants.MeshElementType.CTETRA10)
                    {
                        mesh3dTetBuilder1.ElementType.ElementTypeName = Constants.CTETRA10; //3D elements
                    }
                    if (iPartData.MeshElementType == Constants.MeshElementType.CTETRA4)
                    {
                        mesh3dTetBuilder1.ElementType.ElementTypeName = Constants.CTETRA4; //3D elements
                    }

                    mesh3dTetBuilder1.ElementType.DestinationCollector.AutomaticMode = false;
                    bool added1;
                    added1 = mesh3dTetBuilder1.SelectionList.Add(objects1);
                    mesh3dTetBuilder1.ElementType.ElementDimension = ElementTypeBuilder.ElementType.FreeSolid;

                    Unit unit1 = workFemPart.UnitCollection.FindObject("MilliMeter");
                    Unit unit2 = workFemPart.UnitCollection.FindObject("Degrees");

                    //mesh parameters
                    mesh3dTetBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("quad mesh overall edge size",
                        "3.44", unit1);
                    mesh3dTetBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("maximum growth rate", "1.3",
                        null);
                    mesh3dTetBuilder1.PropertyTable.SetIntegerPropertyValue("surface meshing method", 0);

                    //surface mesh settings
                    mesh3dTetBuilder1.PropertyTable.SetBooleanPropertyValue("mapped mesh option bool", true);
                    mesh3dTetBuilder1.PropertyTable.SetBooleanPropertyValue("multiblock cylinder option bool", false);
                    mesh3dTetBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("surface mesh size variation",
                        "10", null);
                    mesh3dTetBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("surface curvature threshold",
                        "3.09944", unit1);

                    //volume mesh settings
                    mesh3dTetBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("internal mesh gradation",
                        "1.05", null);
                    mesh3dTetBuilder1.PropertyTable.SetBooleanPropertyValue("internal max edge option bool", false);
                    mesh3dTetBuilder1.PropertyTable.SetBooleanPropertyValue("two elements through thickness bool",
                        true);
                    mesh3dTetBuilder1.PropertyTable.SetBooleanPropertyValue("remesh on bad quality bool", true);

                    //model clean up option
                    mesh3dTetBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("small feature tolerance", "10",
                        null);
                    mesh3dTetBuilder1.PropertyTable.SetBaseScalarWithDataPropertyValue("small feature value", "0.344",
                        null);

                    //mesh collector builder
                    MeshCollectorBuilder meshCollectorBuilder1;
                    meshCollectorBuilder1 = meshManager1.CreateCollectorBuilder(null, "Solid");
                    meshCollectorBuilder1.CollectorName = iPartData.PartNumber;

                    CaePart caePart1 = workFemPart;
                    PhysicalPropertyTable[] physicalPropertyTables = caePart1.PhysicalPropertyTables.ToArray();
                    int length = physicalPropertyTables.Length;
                    PhysicalPropertyTable physicalPropertyTable1;
                    physicalPropertyTable1 = caePart1.PhysicalPropertyTables.CreatePhysicalPropertyTable("PSOLID",
                        "NX NASTRAN - Structural", "NX NASTRAN",
                        iPartData.PartNumber + "_" + iPartData.PartId + "_" + length, randomInt.Next(100, 5000));

                    var propertyTable1 = physicalPropertyTable1.PropertyTable;

                    Session.UndoMarkId markId6;
                    markId6 = theSession.SetUndoMark(Session.MarkVisibility.Invisible, null);
                    PhysicalMaterial physicalMaterial1 = ((PhysicalMaterial)workFemPart.MaterialManager.PhysicalMaterials.FindObject("PhysicalMaterial[Steel]"));
                    propertyTable1.SetMaterialPropertyValue("material", false, physicalMaterial1);
                    int nErrs1;
                    nErrs1 = theSession.UpdateManager.DoUpdate(markId6);
                    meshCollectorBuilder1.PropertyTable.SetNamedPropertyTablePropertyValue("Solid Property", physicalPropertyTable1);

                    MeshCollector meshCollector1;
                    meshCollector1 = meshCollectorBuilder1.Commit() as MeshCollector;
                    meshCollectorBuilder1.Destroy();

                    mesh3dTetBuilder1.ElementType.DestinationCollector.ElementContainer = meshCollector1;

                    Session.UndoMarkId id1;
                    id1 = theSession.NewestVisibleUndoMark;

                    int nErrs2;
                    nErrs2 = theSession.UpdateManager.DoUpdate(id1);

                    Mesh[] meshes1;
                    meshes1 = mesh3dTetBuilder1.CommitMesh();

                    theSession.SetUndoMarkName(id1, "3D Tetrahedral Mesh");

                    mesh3dTetBuilder1.Destroy();

                    theSession.CleanUpFacetedFacesAndEdges();

                }
            }
            catch (Exception e)
            {
                Log.Error("3D mesh creation failed for " + iPartData.PartNumber);
                Log.Error("Error message", e);
            }
        }
        private void CreatePropertyTable()
        {

        }

        public List<Edge> GetCircularEdgesOfFace(Face iFace)
        {
            List<Edge> circularEdge = new List<Edge>(0);
            Edge[] edges = iFace.GetEdges();
            foreach (Edge edge in edges)
            {
                if (edge.SolidEdgeType == Edge.EdgeType.Circular ||
                    edge.SolidEdgeType == Edge.EdgeType.Elliptical)
                {
                    circularEdge.Add(edge);
                }
            }

            return circularEdge;
        }

        #region New Methods added

        public void FindMatingParts1(List<PartData> iPartDatas)
        {
            List<Body> bodyOccs = new List<Body>(0);
            AabbTree componentBodyTree = new AabbTree(true);
            foreach (PartData iPartData in iPartDatas)
            {
                componentBodyTree.Add(new AabbExternalNode() { Data = iPartData }, iPartData.AabbBBox);
            }
            componentBodyTree.finalize();
            // get all the overlapping pairs of Components
            List<Tuple<AabbExternalNode, AabbExternalNode>> overlappingComponents =
                new List<Tuple<AabbExternalNode, AabbExternalNode>>(0);
            int matingPairs = componentBodyTree.GetOverlappingPairs(overlappingComponents);
            //Parallel.ForEach(overlappingComponents, (overlappingComponentPairs) =>
                foreach (Tuple<AabbExternalNode, AabbExternalNode> overlappingComponentPairs in overlappingComponents)
            {
                PartData matingPart1 = overlappingComponentPairs.Item1.Data as PartData;
                PartData matingPart2 = overlappingComponentPairs.Item2.Data as PartData;

                //Find if really they are mating pairs by checking if any planar to planar mating faces exists
                if (matingPart1 == null || matingPart2 == null)
                {
                    return;
                }

                AabbTree faceTree = new AabbTree(true);
                foreach (FaceData matVecFaceComp1 in matingPart1.PlanarFacesData)
               // Parallel.ForEach(matingPart1.PlanarFacesData, (matVecFaceComp1) =>
                {
                    if (matVecFaceComp1.FaceType == Constants.FaceType.Planar)
                    {
                        faceTree.Add(new AabbExternalNode() { Data = matVecFaceComp1 },
                            matVecFaceComp1.AabbBox);
                    }
                }//); //uncomment for Parallel foreach

                foreach (FaceData matVecFaceComp2 in matingPart2.PlanarFacesData) 
                //Parallel.ForEach(matingPart2.PlanarFacesData, (matVecFaceComp2) =>
                {
                    if (matVecFaceComp2.FaceType == Constants.FaceType.Planar)
                    {
                        faceTree.Add(new AabbExternalNode() { Data = matVecFaceComp2 },
                            matVecFaceComp2.AabbBox);
                    }
                }//); //uncomment for Parallel foreach
                faceTree.finalize();
                List<Tuple<AabbExternalNode, AabbExternalNode>> overlappingFaceNodes =
                    new List<Tuple<AabbExternalNode, AabbExternalNode>>(0);
                int overlappingFaceCnt = faceTree.GetOverlappingPairs(overlappingFaceNodes);
                foreach (var overlappingFacePairs in overlappingFaceNodes)
                //Parallel.ForEach(overlappingFaceNodes, (overlappingFacePairs) =>
                {
                    try
                    {
                        FaceData vecFaceData1 = (FaceData)overlappingFacePairs.Item1.Data;
                        FaceData vecFaceData2 = (FaceData)overlappingFacePairs.Item2.Data;

                        PartData matingFace1CompData = vecFaceData1.ParentPartData;
                        PartData matingFace2CompData = vecFaceData2.ParentPartData;
                        if (matingFace1CompData == matingFace2CompData)
                        {
                            return;
                        }

                        if (vecFaceData2 != null && vecFaceData1 != null &&
                            matingFace1CompData.PartId != matingFace2CompData.PartId)
                        {
                            if (vecFaceData1.FaceType == Constants.FaceType.Planar &&
                                vecFaceData2.FaceType == Constants.FaceType.Planar)
                            {
                                //Check if the direction of the faces are in opposite direction
                                bool isOppositeDir = IsParallelAndOppositeFaces(vecFaceData1.OFace, vecFaceData2.OFace);

                                double distance = DistanceBetweenTwoPlanarFaces(vecFaceData1, vecFaceData2);
                                if (isOppositeDir && Math.Abs(distance) <= double.Epsilon)
                                    //if (isOppositeDir)
                                {
                                    Log.Info("Distance: " + Math.Round(distance, 2));

                                    vecFaceData1.IsMatingFace = true;
                                    vecFaceData1.MatingFaces.Add(vecFaceData2);

                                    vecFaceData2.IsMatingFace = true;
                                    vecFaceData2.MatingFaces.Add(vecFaceData1);

                                    vecFaceData1.OFace.SetName("MATING_FACE");
                                    vecFaceData2.OFace.SetName("MATING_FACE");

                                    if (!matingPart1.MatingParts.Contains(matingPart2))
                                    {
                                        matingPart1.MatingParts.Add(matingPart2);
                                    }

                                    if (!matingPart2.MatingParts.Contains(matingPart1))
                                    {
                                        matingPart2.MatingParts.Add(matingPart1);
                                    }
                                }
                            }
                        }
                    }
                    catch (AggregateException ex)
                    {
                        Log.Error("Error", ex);
                    }


                }//); //--> Uncoment for parallel foreach

                overlappingFaceNodes.Clear();
                faceTree.Clear();
            }//);//--> Uncoment for parallel foreach
        }
        public double DistanceBetweenTwoPlanarFaces(FaceData vecFaceData1, FaceData vecFaceData2)
        {
            double[] face1Center = vecFaceData1.FaceCenter;
            double[] face1Normal = vecFaceData1.FaceNormal;
            double[] face2Center = vecFaceData2.FaceCenter;
            // double[] face2Normal = vecFaceData2.FaceNormal;
            double c = face1Center[0] * face1Normal[0] + face1Center[1] * face1Normal[1] + face1Center[2] * face1Normal[2];
            double distance = face2Center[0] * face1Normal[0] + face2Center[1] * face1Normal[1] + face2Center[2] * face1Normal[2] - c;
            return distance;
        }
        public double[] GetFaceCenterPoint(Face iFace)
        {
            int faceType;
            double[] axisPnt = new double[3];
            double[] axisDirection = new double[3];
            double[] faceBox = new double[6];
            double radius;
            double radData;
            int normDir;
            _sessionData.TheUfSession.Modl.AskFaceData(iFace.Tag, out faceType, axisPnt, axisDirection, faceBox, out radius,
                out radData, out normDir);
            return axisPnt;
        }
        public double GetFaceRadius(Face iFace)
        {
            double radius = 0.0;
            List<double> radiusList = new List<double>(0);
            Edge[] edges = iFace.GetEdges();
            foreach (Edge edge in edges)
            {
                if (edge.SolidEdgeType == Edge.EdgeType.Circular)
                {
                    IntPtr edgeEvaluator;
                    _sessionData.TheUfSession.Eval.Initialize(edge.Tag, out edgeEvaluator);
                    UFEval.Arc arcInfo;
                    _sessionData.TheUfSession.Eval.AskArc(edgeEvaluator, out arcInfo);
                    double arcRadius = Math.Round(arcInfo.radius, 2);

                    radiusList.Add(arcRadius);
                }
            }
            radius = radiusList.Max();
            return radius;
        }

        public void FillBodyPlanarFacesData(PartData iPartData)
        {
            List<Face> faceList = new List<Face>(0);
            Body iFinalBody = iPartData.ComponentBody;
            Face[] faces = null;
            try
            {
                faces = iFinalBody.GetFaces();
                if (faces != null)
                {
                    foreach (Face face in faces)
                    {
                        if (face.SolidFaceType == Face.FaceType.Planar)
                        {
                            FaceData faceData = new FaceData(face);
                            faceData.ParentPartData = iPartData;
                            faceData.AabbBox = AskAabbBoxOfFace(face);
                            iPartData.PlanarFacesData.Add(faceData);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Log.Error("Error in getting faces");
            }

            
        }

        public AabbBox AskAabbBoxOfFace(Face iFace)
        {
            AabbBox oAabbBBox = new AabbBox(new Point3(0, 0, 0), new Point3(0, 0, 0));
            try
            {
                int faceType;
                double[] axisPnt = new double[3];
                double[] axisDirection = new double[3];
                double[] faceBox = new double[6];
                double radius;
                double radData;
                int normDir;
                _sessionData.TheUfSession.Modl.AskFaceData(iFace.Tag, out faceType, axisPnt, axisDirection, faceBox,
                    out radius,
                    out radData, out normDir);
                Point3 min = new Point3(faceBox[0], faceBox[1], faceBox[2]);
                Point3 max = new Point3(faceBox[3], faceBox[4], faceBox[5]);
                oAabbBBox = new AabbBox(min, max);
            }
            catch (Exception e)
            {
                Log.Error("Error in Finding Bounding box of Face");
            }

            return oAabbBBox;
        }

        #endregion
    }
}