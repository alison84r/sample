﻿using System.Collections.Generic;
using AABB;
using NXOpen;

namespace FemAutomation
{
    public class FaceData
    {
        private Face _face { get; set; }
        private NxHelper _nxHelper;
        public Face OFace
        {
            get { return _face; }
        }

        public AabbBox AabbBox { get; set; }
        public PartData ParentPartData { get; set; }
        public List<FaceData> MatingFaces { get; set; }

        /// <summary>
        /// Face axis in case of cylindrical face
        /// </summary>
        /// <returns></returns>
        public double[] FaceAxis { get; set; }

        /// <summary>
        /// Planar face normal
        /// </summary>
        public double[] FaceNormal
        {
            get
            {
                if (_face != null)
                {
                    if (_face.SolidFaceType == Face.FaceType.Planar)
                    {
                        return _nxHelper.GetFaceNormal(_face);
                    }
                }

                return new double[] { 0.0, 0.0, 0.0 };
            }

        }

        /// <summary>
        /// Planar face Center
        /// </summary>
        public double[] FaceCenter
        {
            get
            {
                if (_face != null)
                {
                    return _nxHelper.GetFaceCenterPoint(_face);
                }

                return new double[] { 0.0, 0.0, 0.0 };
            }

        }
        /// <summary>
        /// Dia in case of Cylindrical Face
        /// </summary>
        /// <returns></returns>
        public double Diameter 
        {
            get
            {
                if (_face != null)
                {
                    if (FaceType == Constants.FaceType.Cylindrical)
                    {
                        return _nxHelper.GetFaceRadius(_face) * 2;
                    }
                }

                return 0.0;
            }
            
        }


        /// <summary>
        /// Face type : Cylindrical, Planar, Conical, or Undefined
        /// </summary>
        public Constants.FaceType FaceType
        {
            get
            {
                if (_face == null)
                {
                    return Constants.FaceType.Undefined;
                }

                if (_face.SolidFaceType == Face.FaceType.Conical)
                {
                    return Constants.FaceType.Conical;
                }
                if (_face.SolidFaceType == Face.FaceType.Planar)
                {
                    return Constants.FaceType.Planar;
                }
                if (_face.SolidFaceType == Face.FaceType.Cylindrical)
                {
                    return Constants.FaceType.Cylindrical;
                }
                return Constants.FaceType.Undefined;
            }
        }
        public bool IsMatingFace { get; set; }
        public FaceData(Face iFace)
        {
            _face = iFace;
            _nxHelper = new NxHelper(new SessionData());
            MatingFaces = new List<FaceData>(0);
            IsMatingFace = false;
        }
    }
}