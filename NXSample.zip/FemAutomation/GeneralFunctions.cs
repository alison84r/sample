﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using FemAutomation.ConfigFilesReadingHelper;
using NXOpen.Assemblies;

namespace FemAutomation
{
    public static class GeneralFunctions
    {
        public static bool InitializeSettings()
        {
            #region Setting Log File

            try
            {
                //Log folder Settings.
                string outPutFolderPath = Path.GetTempPath();
                string ModuleName = @"FeaAutomation";
                string appLogDir = Path.Combine(outPutFolderPath, ModuleName);
                if (!Directory.Exists(appLogDir))
                {
                    Directory.CreateDirectory(appLogDir);
                }

                DateTime datetime = DateTime.Now;
                string uniqueId = string.Format("{0:0000}{1:00}{2:00}{3:00}{4:00}{5:00}{6:000}",
                    datetime.Year, datetime.Month, datetime.Day,
                    datetime.Hour, datetime.Minute, datetime.Second, datetime.Millisecond);
                string logFilePath = Path.Combine(appLogDir, uniqueId + ".log");

                var targetLogFile = new FileInfo(logFilePath);
                Logger.Start(targetLogFile);
            }
            catch (Exception e)
            {
                return false;
            }

            return true;

            #endregion

        }
        public static List<Component> FilteredComponents(List<Component> iComponents,
            List<FastenerStandardPart> iFastStdParts)
        {
            List<Component> filteredComps = new List<Component>(0);
            foreach (Component iComponent in iComponents)
            {
                foreach (FastenerStandardPart fastenerStandardPart in iFastStdParts)
                {
                    if (!fastenerStandardPart.PartNumber.ToUpper().Contains(iComponent.DisplayName.ToUpper()))
                    {
                        filteredComps.Add(iComponent);
                        break;
                    }
                }
            }

            return filteredComps;
        }
        public static List<PartData> FilteredComponents(List<PartData> iComponents,
            List<FastenerStandardPart> iFastStdParts)
        {
            List<PartData> filteredComps = new List<PartData>(0);
            foreach (PartData partData in iComponents)
            {
                Component iComponent = partData.CadComponent;
                foreach (FastenerStandardPart fastenerStandardPart in iFastStdParts)
                {
                    if (!fastenerStandardPart.PartNumber.ToUpper().Contains(iComponent.DisplayName.ToUpper()))
                    {
                        filteredComps.Add(partData);
                        break;
                    }
                }
            }

            return filteredComps;
        }
        public static List<Component> FilteredComponents(List<Component> iComponents,
            List<Component> iExceptionParts)
        {
            List<Component> filteredComps = new List<Component>(0);
            foreach (Component iComponent in iComponents)
            {
                foreach (Component iExceptionPart in iExceptionParts)
                {
                    if (!iComponent.DisplayName.ToUpper().Contains(iExceptionPart.DisplayName.ToUpper()))
                    {
                        filteredComps.Add(iComponent);
                        break;
                    }
                }
            }

            return filteredComps;
        }
    }
}