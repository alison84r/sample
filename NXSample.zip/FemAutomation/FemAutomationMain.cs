﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FemAutomation.ConfigFilesReadingHelper;
using NXOpen;
using NXOpen.Assemblies;

namespace FemAutomation
{
    public class FemAutomationMain
    {
        public static SessionData SessionData;
        public static Component MainRootComponent;
        public static void Main1(string[] args)
        {
            SessionData = new SessionData();

            //Reading config files
            ConfigFilesReading configFiles = new ConfigFilesReading();
            List<FastenerStandardPart> fastenerStandardParts = configFiles.ReadFastenersAndStandardsConfigFile();
            NxHelper nxHelper = new NxHelper(SessionData);
            
            Part idealizedPart = nxHelper.CreateFemSimulationSolution();
            if (idealizedPart != null)
            {
                //Create a wave linked body. 
                //Get the required bodies from the root component
                Component rootComponent = SessionData.TheWorkPart.ComponentAssembly.RootComponent;
                if (rootComponent != null)
                {
                   nxHelper.CreateWaveLinkBodies(fastenerStandardParts);
                }

            }

            SessionData.TheUi.NXMessageBox.Show("SIM creation", NXMessageBox.DialogType.Information,
                "FEM and SIM solution created");

        }

        public static int GetUnloadOption(string dummy)
        {
            return (int)Session.LibraryUnloadOption.Immediately;
        }
    }
}
