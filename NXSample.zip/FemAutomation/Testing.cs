﻿using System;
using NXOpen;
using NXOpen.CAE;
using NXOpen.UF;
using NXOpen.Utilities;

namespace FemAutomation
{
    public class NXJournal
    {

        public static Session theSession = null;

        public static UFSession theUFSession = null;

        public static Part workPart = null;

        static void DoIt()
        {
            NXObject[] theCurves = NXJournal.SelectCurvesOrEdges("Show offset in face direction");
            if (((theCurves == null)
                 || (theCurves.Length == 0)))
            {
                return;
            }

            Face theTarget = NXJournal.SelectAFace("Offset Onto");
            if ((theTarget == null))
            {
                return;
            }

            Section section1;
            if (workPart.PartUnits.Equals(BasePart.Units.Inches))
            {
                section1 = workPart.Sections.CreateSection(0.00038, 0.0004, 0.5);
            }
            else
            {
                section1 = workPart.Sections.CreateSection(0.02413, 0.0254, 0.5);
            }

            SelectionIntentRule[] rules1 = new SelectionIntentRule[theCurves.Length];
            for (int ii = 0; (ii < theCurves.Length); ii++)
            {
                if ((theCurves[ii] is Edge))
                {
                    Edge[] edges1 = new Edge[] {
                        ((Edge)(theCurves[ii]))};
                    rules1[ii] = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges1);
                }
                else
                {
                    Curve[] curves1 = new Curve[] {
                        ((Curve)(theCurves[ii]))};
                    rules1[ii] = workPart.ScRuleFactory.CreateRuleBaseCurveDumb(curves1);
                }

            }

            //  This is using the start point of the first curve so the
            //  Section direction will be in the natural direction of that curve
            Point3d[] curveEnds = NXJournal.askCurveEnds(theCurves[0] as Edge);
            section1.AddToSection(rules1, theCurves[0], null, null, curveEnds[0], NXOpen.Section.Mode.Create, false);
            Direction theAOCSDirection = NXJournal.GetAOCSDirection(section1, theTarget);

        }

        static Point3d[] askCurveEnds(Curve theCurve)
        {
            double[] limits = new double[2];
            IntPtr evaluator;
            double[] start = new double[3];
            double[] end = new double[3];

            theUFSession.Eval.Initialize2(theCurve.Tag, out evaluator);
            theUFSession.Eval.AskLimits(evaluator, limits);
            theUFSession.Eval.Evaluate(evaluator, 0, limits[0], start, new double[] { });
            theUFSession.Eval.Evaluate(evaluator, 0, limits[1], end, new double[] { });
            theUFSession.Eval.Free(evaluator);

            return new Point3d[]
            { new Point3d(start[0], start[1], start[2]),
                new Point3d(end[0], end[1], end[2]) };
        }
        static Point3d[] askCurveEnds(Edge theCurve)
        {
            double[] limits = new double[2];
            IntPtr evaluator;
            double[] start = new double[3];
            double[] end = new double[3];

            theUFSession.Eval.Initialize2(theCurve.Tag, out evaluator);
            theUFSession.Eval.AskLimits(evaluator, limits);
            theUFSession.Eval.Evaluate(evaluator, 0, limits[0], start, new double[] { });
            theUFSession.Eval.Evaluate(evaluator, 0, limits[1], end, new double[] { });
            theUFSession.Eval.Free(evaluator);

            return new Point3d[]
            { new Point3d(start[0], start[1], start[2]),
                new Point3d(end[0], end[1], end[2]) };
        }

        ////A recorded journal which uses the AOCSBuilder initially sets the "flip flag" to true, e.g.:
        //expressionSectionSet1.setItemFlipFlag(true);
        //So this example predicts the direction when that flag is set to true.  Please be aware that "true" means "do not flip" which is anti-logical!
        //When calling the Section class method AddToSection, the direction of the section is set according to which end of the seed(2nd argument) the helpPoint(5th argument) is closest to.
        //If it is at (or closer to) the StartPoint of the seed curve the section direction is in the natural direction of that seed curve(from the start toward the end).
        //If however the helpPoint is closer to the EndPoint of the seed curve the section will go the other way from the end toward its start.
        //    The direction of the Section is crossed into the face normal direction to determine the default direction of the offset.

        static Direction GetAOCSDirection(Section theSection, Face theFace)
        {
            NXObject[] theCurves = null;
                theSection.GetOutputCurves(out theCurves);

                StringList inputCurves = new StringList();
                theUFSession.Modl.InitStringList(ref inputCurves);
                theUFSession.Modl.CreateStringList(1, theCurves.Length, ref inputCurves);
                inputCurves._string[0] = theCurves.Length;
                inputCurves.dir[0] = 1;
                
            //UFModl.str inputCurves = new UFModl.StringList(1,
            //    new int[] { theCurves.length }, new int[] { 1 },
            //    new Tag[theCurves.length]);

            for (int ii = 0; ii < theCurves.Length; ii++)
            {
                inputCurves.id[ii] = theCurves[ii].Tag;
            }
                

            ICurve strEle;
            Point3d startPoint;
            Vector3d direction;
            theSection.GetStartAndDirection(out strEle, out startPoint, out direction);
            Point loc = workPart.Points.CreatePoint(startPoint);
            NXJournal.displayConehead(startPoint, direction, "Section Direction");
            Vector3d faceNormal = NXJournal.askFaceNormal(theFace, loc);
            NXJournal.displayConehead(startPoint, faceNormal, "Face Normal");
            double[] theDir = new double[3];
                theUFSession.Vec3.Cross(new double[] {
                direction.X,
                direction.Y,
                direction.Z}, new double[] {
                faceNormal.X,
                faceNormal.Y,
                faceNormal.Z}, theDir);
            Vector3d vector1 = new Vector3d(theDir[0], theDir[1], theDir[2]);
            Direction direction1;
            direction1 = workPart.Directions.CreateDirection(startPoint, vector1, SmartObject.UpdateOption.WithinModeling);
            NXJournal.displayConehead(startPoint, vector1, "AOCS Dir");
            return direction1;
        }

        static Vector3d askFaceNormal(Face theFace, Point where)
        {
            Direction dir = workPart.Directions.CreateDirection(theFace, where, Sense.Forward, SmartObject.UpdateOption.WithinModeling);
            return dir.Vector;
        }

        static void displayConehead(Point3d where, Vector3d direction, String label)
        {
            double[] origin = new double[] {
                where.X,
                where.Y,
                where.Z};
            double[] dir = new double[] {
                direction.X,
                direction.Y,
                direction.Z};
            theUFSession.Disp.LabeledConehead(UFConstants.UF_DISP_WORK_VIEW_ONLY, origin, dir, 0, label);
        }

        public static NXObject[] SelectCurvesOrEdges(String Prompt)
        {
            UI theUI = UI.GetUI();
            Selection.MaskTriple[] mask = new Selection.MaskTriple[] {
                new Selection.MaskTriple(UFConstants.UF_line_type, 0, 0),
                new Selection.MaskTriple(UFConstants.UF_circle_type, 0, 0),
                new Selection.MaskTriple(UFConstants.UF_conic_type, 0, 0),
                new Selection.MaskTriple(UFConstants.UF_spline_type, 0, 0),
                new Selection.MaskTriple(UFConstants.UF_solid_type, 0, UFConstants.UF_UI_SEL_FEATURE_ANY_EDGE)};
           

            TaggedObject[] selobjs;
            Point3d cursor;
            Selection.Response resp = theUI.SelectionManager.SelectTaggedObjects(
                Prompt, "Select Curves and/or Edges", Selection.SelectionScope.WorkPart,
                Selection.SelectionAction.ClearAndEnableSpecific,
                false, false, mask, out selobjs);

            if ((resp == Selection.Response.Ok))
            {
                NXObject[] theNXObjects = new NXObject[selobjs.Length];
                for (int ii = 0; (ii < selobjs.Length); ii++)
                {
                    theNXObjects[ii] = ((NXObject)(selobjs[ii]));
                }

                return theNXObjects;
            }
            else
            {
                return null;
            }

        }

        
        public static Face SelectAFace(string prompt)
        {
            TaggedObject selobj = null;
            Point3d cursor = default(Point3d);
            Selection.SelectionType[] faces = { Selection.SelectionType.Faces };

            Selection.Response resp = UI.GetUI().SelectionManager.SelectTaggedObject(prompt,
                "Select a face", Selection.SelectionScope.AnyInAssembly, false,
                faces, out selobj, out cursor);

            return (Face)selobj;
        }
        public static void Main1(String[] args)
        {
            theSession = Session.GetSession();
            theUFSession = UFSession.GetUFSession();
            workPart = theSession.Parts.Work;
            if ((workPart != null))
            {
                NXJournal.DoIt();
                return;
            }
            else
            {
                NXJournal.Echo("Please open a part first.");
            }

        }

        static void Echo(String output)
        {
            theSession.ListingWindow.Open();
            theSession.ListingWindow.WriteLine(output);
            theUFSession.Ui.UpdateListingWindow();
            theSession.LogFile.WriteLine(output);
        }

        public static int getUnloadOption()
        {
            return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);
        }
    }
}