﻿using NXOpen;

namespace FemAutomation
{
    public class EdgeData
    {
        private Edge _edge { get; set; }

        public Edge OEdge
        {
            get { return _edge; }

        }
        public double Diameter { get; set; }
        public double[] Center { get; set; }
        public double StartAngle { get; set; }
        public double EndAngle { get; set; }

        public double WasherSize { get; set; }
        public bool IsWasherSizeInDb { get; set; }

        public EdgeData(Edge iEdge)
        {
            _edge = iEdge;
            Diameter = 0.0;
            Center = new[] { 0.0, 0.0, 0.0 };
            StartAngle = 0.0;
            EndAngle = 0.0;
            WasherSize = 0.0;
            IsWasherSizeInDb = false;
        }
    }
}