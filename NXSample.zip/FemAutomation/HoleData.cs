﻿using System.Collections.Generic;
using System.Linq;
using AABB;
using NXOpen;
using Operation = AABB.Operation;


namespace FemAutomation
{
    public class HoleData
    {
        public AabbBox AabbBox { get; set; }
        public PartData ParentPartData { get; set; }
        public Face HoleFace { get; set; }
        public List<Edge> HoleEdges { get; set; }
        public int ID { get; set; }
        public double[] HoleDirection { get; set; }

        public List<HoleData>MatingHoles { get; set; }

        
        public AabbBox OverAllAaBbBox
        {
            get
            {
                if (MatingHoles.Any())
                {
                    List<AabbBox> matHolesAabbBoxes = new List<AabbBox>(0);
                    matHolesAabbBoxes.Add(this.AabbBox);
                    foreach (HoleData matingHole in MatingHoles)
                    {
                        matHolesAabbBoxes.Add(matingHole.AabbBox);
                    }

                    AabbBox mergeAabbBox = Operation.MergeAabbBox(matHolesAabbBoxes);
                    return mergeAabbBox;
                }

                return null;
            }

        }
        public HoleData()
        {
            AabbBox = new AabbBox(new Point3(0,0,0),new Point3(0,0,0));
            ParentPartData = null;
            HoleDirection = new double[3];
            ID = 0;
            HoleFace = null;
            HoleEdges = new List<Edge>(0);
            MatingHoles = new List<HoleData>(0);
        }

    }
}