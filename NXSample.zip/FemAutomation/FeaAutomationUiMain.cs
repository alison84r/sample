﻿//==============================================================================
//  Purpose:  This TEMPLATE file contains C# source to guide you in the
//  construction of your Block application dialog. The generation of your
//  dialog file (.dlx extension) is the first step towards dialog construction
//  within NX.  You must now create a NX Open application that
//  utilizes this file (.dlx).
//
//  The information in this file provides you with the following:
//
//  1.  Help on how to load and display your Block UI Styler dialog in NX
//      using APIs provided in NXOpen.BlockStyler namespace
//  2.  The empty callback methods (stubs) associated with your dialog items
//      have also been placed in this file. These empty methods have been
//      created simply to start you along with your coding requirements.
//      The method name, argument list and possible return values have already
//      been provided for you.
//==============================================================================

//------------------------------------------------------------------------------
//These imports are needed for the following template code
//------------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.IO;
using FemAutomation;
using FemAutomation.ConfigFilesReadingHelper;
using NXOpen;
using NXOpen.Assemblies;
using NXOpen.BlockStyler;
using NXOpen.UF;
using Assembly = System.Reflection.Assembly;

//------------------------------------------------------------------------------
//Represents Block Styler application class
//------------------------------------------------------------------------------
public class FeaAutomationUiMain
{
    //class members
    private static Session theSession = null;
    public static SessionData SessionData;
    private static UI theUI = null;
    private string theDlxFileName;
    private NXOpen.BlockStyler.BlockDialog theDialog;
    private NXOpen.BlockStyler.Group SolutionTypeGrp;// Block type: Group
    private NXOpen.BlockStyler.ListBox SolTypeLstBx;// Block type: List Box
    private NXOpen.BlockStyler.SelectObject FacePairMidSurfCompsSel;// Block type: Selection
    private NXOpen.BlockStyler.SelectObject OffsetMidSurfCompsSel;// Block type: Selection
    //------------------------------------------------------------------------------
    //Bit Option for Property: SnapPointTypesEnabled
    //------------------------------------------------------------------------------
    public static readonly int              SnapPointTypesEnabled_UserDefined = (1 << 0);
    public static readonly int                 SnapPointTypesEnabled_Inferred = (1 << 1);
    public static readonly int           SnapPointTypesEnabled_ScreenPosition = (1 << 2);
    public static readonly int                 SnapPointTypesEnabled_EndPoint = (1 << 3);
    public static readonly int                 SnapPointTypesEnabled_MidPoint = (1 << 4);
    public static readonly int             SnapPointTypesEnabled_ControlPoint = (1 << 5);
    public static readonly int             SnapPointTypesEnabled_Intersection = (1 << 6);
    public static readonly int                SnapPointTypesEnabled_ArcCenter = (1 << 7);
    public static readonly int            SnapPointTypesEnabled_QuadrantPoint = (1 << 8);
    public static readonly int            SnapPointTypesEnabled_ExistingPoint = (1 << 9);
    public static readonly int             SnapPointTypesEnabled_PointonCurve = (1 <<10);
    public static readonly int           SnapPointTypesEnabled_PointonSurface = (1 <<11);
    public static readonly int         SnapPointTypesEnabled_PointConstructor = (1 <<12);
    public static readonly int     SnapPointTypesEnabled_TwocurveIntersection = (1 <<13);
    public static readonly int             SnapPointTypesEnabled_TangentPoint = (1 <<14);
    public static readonly int                    SnapPointTypesEnabled_Poles = (1 <<15);
    public static readonly int         SnapPointTypesEnabled_BoundedGridPoint = (1 <<16);
    public static readonly int         SnapPointTypesEnabled_FacetVertexPoint = (1 <<17);
    public static readonly int            SnapPointTypesEnabled_DefiningPoint = (1 <<18);
    //------------------------------------------------------------------------------
    //Bit Option for Property: SnapPointTypesOnByDefault
    //------------------------------------------------------------------------------
    public static readonly int             SnapPointTypesOnByDefault_EndPoint = (1 << 3);
    public static readonly int             SnapPointTypesOnByDefault_MidPoint = (1 << 4);
    public static readonly int         SnapPointTypesOnByDefault_ControlPoint = (1 << 5);
    public static readonly int         SnapPointTypesOnByDefault_Intersection = (1 << 6);
    public static readonly int            SnapPointTypesOnByDefault_ArcCenter = (1 << 7);
    public static readonly int        SnapPointTypesOnByDefault_QuadrantPoint = (1 << 8);
    public static readonly int        SnapPointTypesOnByDefault_ExistingPoint = (1 << 9);
    public static readonly int         SnapPointTypesOnByDefault_PointonCurve = (1 <<10);
    public static readonly int       SnapPointTypesOnByDefault_PointonSurface = (1 <<11);
    public static readonly int     SnapPointTypesOnByDefault_PointConstructor = (1 <<12);
    public static readonly int     SnapPointTypesOnByDefault_BoundedGridPoint = (1 <<16);
    public static readonly int     SnapPointTypesOnByDefault_FacetVertexPoint = (1 <<17);

    public static Logger Log;
    //------------------------------------------------------------------------------
    //Constructor for NX Styler class
    //------------------------------------------------------------------------------
    public FeaAutomationUiMain()
    {
        try
        {
            SessionData = new SessionData();
            theSession = SessionData.TheSession;
            theUI = SessionData.TheUi;
            var executingAssemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            theDlxFileName = executingAssemblyPath + @"\FeaAutomationUiMain.dlx";
            theDialog = theUI.CreateDialog(theDlxFileName);
            theDialog.AddApplyHandler(new NXOpen.BlockStyler.BlockDialog.Apply(apply_cb));
            theDialog.AddOkHandler(new NXOpen.BlockStyler.BlockDialog.Ok(ok_cb));
            theDialog.AddUpdateHandler(new NXOpen.BlockStyler.BlockDialog.Update(update_cb));
            theDialog.AddInitializeHandler(new NXOpen.BlockStyler.BlockDialog.Initialize(initialize_cb));
            theDialog.AddDialogShownHandler(new NXOpen.BlockStyler.BlockDialog.DialogShown(dialogShown_cb));
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            throw ex;
        }
    }
    //------------------------------- DIALOG LAUNCHING ---------------------------------
    //
    //    Before invoking this application one needs to open any part/empty part in NX
    //    because of the behavior of the blocks.
    //
    //    Make sure the dlx file is in one of the following locations:
    //        1.) From where NX session is launched
    //        2.) $UGII_USER_DIR/application
    //        3.) For released applications, using UGII_CUSTOM_DIRECTORY_FILE is highly
    //            recommended. This variable is set to a full directory path to a file 
    //            containing a list of root directories for all custom applications.
    //            e.g., UGII_CUSTOM_DIRECTORY_FILE=$UGII_BASE_DIR\ugii\menus\custom_dirs.dat
    //
    //    You can create the dialog using one of the following way:
    //
    //    1. Journal Replay
    //
    //        1) Replay this file through Tool->Journal->Play Menu.
    //
    //    2. USER EXIT
    //
    //        1) Create the Shared Library -- Refer "Block UI Styler programmer's guide"
    //        2) Invoke the Shared Library through File->Execute->NX Open menu.
    //
    //------------------------------------------------------------------------------
    public static void Main1()
    {
        FeaAutomationUiMain theFeaAutomationUiMain = null;
        try
        {
            theFeaAutomationUiMain = new FeaAutomationUiMain();
            bool isInitializeSettings = GeneralFunctions.InitializeSettings();
            if (isInitializeSettings)
            {
                Log = new Logger("Main UI");
                Log.Info("Logging Started...");
                // The following method shows the dialog immediately
                theFeaAutomationUiMain.Show();
            }
            else
            {
                theUI.NXMessageBox.Show("FEA Automation Error", NXMessageBox.DialogType.Error, "APP initial settings failed");
            }
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            theUI.NXMessageBox.Show("Block Styler", NXMessageBox.DialogType.Error, ex.ToString());
        }
        finally
        {
            if(theFeaAutomationUiMain != null)
                theFeaAutomationUiMain.Dispose();
            theFeaAutomationUiMain = null;
        }
    }
    //------------------------------------------------------------------------------
    // This method specifies how a shared image is unloaded from memory
    // within NX. This method gives you the capability to unload an
    // internal NX Open application or user  exit from NX. Specify any
    // one of the three constants as a return value to determine the type
    // of unload to perform:
    //
    //
    //    Immediately : unload the library as soon as the automation program has completed
    //    Explicitly  : unload the library from the "Unload Shared Image" dialog
    //    AtTermination : unload the library when the NX session terminates
    //
    //
    // NOTE:  A program which associates NX Open applications with the menubar
    // MUST NOT use this option since it will UNLOAD your NX Open application image
    // from the menubar.
    //------------------------------------------------------------------------------
     public static int GetUnloadOption(string arg)
    {
        //return System.Convert.ToInt32(Session.LibraryUnloadOption.Explicitly);
         return System.Convert.ToInt32(Session.LibraryUnloadOption.Immediately);
        // return System.Convert.ToInt32(Session.LibraryUnloadOption.AtTermination);
    }
    
    //------------------------------------------------------------------------------
    // Following method cleanup any housekeeping chores that may be needed.
    // This method is automatically called by NX.
    //------------------------------------------------------------------------------
    public static void UnloadLibrary(string arg)
    {
        try
        {
            //---- Enter your code here -----
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            theUI.NXMessageBox.Show("Block Styler", NXMessageBox.DialogType.Error, ex.ToString());
        }
    }
    
    //------------------------------------------------------------------------------
    //This method shows the dialog on the screen
    //------------------------------------------------------------------------------
    public NXOpen.UIStyler.DialogResponse Show()
    {
        try
        {
            theDialog.Show();
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            theUI.NXMessageBox.Show("Block Styler", NXMessageBox.DialogType.Error, ex.ToString());
        }
        return 0;
    }
    
    //------------------------------------------------------------------------------
    //Method Name: Dispose
    //------------------------------------------------------------------------------
    public void Dispose()
    {
        if(theDialog != null)
        {
            theDialog.Dispose();
            theDialog = null;
        }
    }
    
    //------------------------------------------------------------------------------
    //---------------------Block UI Styler Callback Functions--------------------------
    //------------------------------------------------------------------------------
    
    //------------------------------------------------------------------------------
    //Callback Name: initialize_cb
    //------------------------------------------------------------------------------
    public void initialize_cb()
    {
        try
        {
            SolutionTypeGrp = (NXOpen.BlockStyler.Group)theDialog.TopBlock.FindBlock("SolutionTypeGrp");
            SolTypeLstBx = (NXOpen.BlockStyler.ListBox)theDialog.TopBlock.FindBlock("SolTypeLstBx");
            FacePairMidSurfCompsSel = (NXOpen.BlockStyler.SelectObject)theDialog.TopBlock.FindBlock("FacePairMidSurfCompsSel");
            OffsetMidSurfCompsSel = (NXOpen.BlockStyler.SelectObject)theDialog.TopBlock.FindBlock("OffsetMidSurfCompsSel");
            //------------------------------------------------------------------------------
            //Registration of ListBox specific callbacks
            //------------------------------------------------------------------------------
            //SolTypeLstBx.SetAddHandler(new NXOpen.BlockStyler.ListBox.AddCallback(AddCallback));
            
            //SolTypeLstBx.SetDeleteHandler(new NXOpen.BlockStyler.ListBox.DeleteCallback(DeleteCallback));
            
            //------------------------------------------------------------------------------
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            theUI.NXMessageBox.Show("Block Styler", NXMessageBox.DialogType.Error, ex.ToString());
        }
    }
    
    //------------------------------------------------------------------------------
    //Callback Name: dialogShown_cb
    //This callback is executed just before the dialog launch. Thus any value set 
    //here will take precedence and dialog will be launched showing that value. 
    //------------------------------------------------------------------------------
    public void dialogShown_cb()
    {
        try
        {
            //Initialize the Log in the temp Directory
           
            {
                //Default selection
                SolTypeLstBx.SelectedItemIndex = 0;
                Log.Info("Default Solution type is set...");

                //Component Selection Filter
               
                Selection.MaskTriple[] filter =
                {
                    new Selection.MaskTriple(UFConstants.UF_component_type, UFConstants.UF_all_subtype,
                        UFConstants.UF_UI_SEL_FEATURE_SOLID_BODY)
                };
                FacePairMidSurfCompsSel.SetSelectionFilter(Selection.SelectionAction.ClearAndEnableSpecific, filter);
                OffsetMidSurfCompsSel.SetSelectionFilter(Selection.SelectionAction.ClearAndEnableSpecific, filter);
                Log.Info("Components Filter is set...");
            }
           
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            theUI.NXMessageBox.Show("Block Styler", NXMessageBox.DialogType.Error, ex.ToString());
        }
    }
    
    //------------------------------------------------------------------------------
    //Callback Name: apply_cb
    //------------------------------------------------------------------------------
    public int apply_cb()
    {
        int errorCode = 0;
        NxHelper nxHelper = new NxHelper(SessionData);
        try
        {
            nxHelper.DisplaySupress(UFConstants.UF_DISP_SUPPRESS_DISPLAY);
            nxHelper.WorkInProgress(Constants.START);
            //Collect all components for which mid surface has to be created using Face Pairs Option
            List<Component> facePairComps = new List<Component>(0);
            TaggedObject[] selectedFacePairCompObjects = FacePairMidSurfCompsSel.GetSelectedObjects();
            foreach (TaggedObject selectedObject in selectedFacePairCompObjects)
            {
                if (selectedObject is Component)
                {
                    facePairComps.Add(selectedObject as Component);
                }
            }

            //Collect all components for which mid surface has to be created using Offset Option
            List<Component> offsetComps = new List<Component>(0);
            TaggedObject[] selectedOffsetCompObjects = OffsetMidSurfCompsSel.GetSelectedObjects();
            foreach (TaggedObject selectedObject in selectedOffsetCompObjects)
            {
                if (selectedObject is Component)
                {
                    offsetComps.Add(selectedObject as Component);
                }
            }

            ConfigFilesReading configFiles = new ConfigFilesReading();
            List<FastenerStandardPart> fastenerStandardParts = configFiles.ReadFastenersAndStandardsConfigFile();
            Log.Info("Config files reading completed...");


            Part idealizedPart = nxHelper.CreateFemSimulationSolution();
            Log.Info("Idealized part and Solution Files are created...");
            if (idealizedPart != null)
            {
                //Create a wave linked body. 
                //Get the required bodies from the root component
                Component rootComponent = SessionData.TheWorkPart.ComponentAssembly.RootComponent;
                if (rootComponent != null)
                {
                    nxHelper.CreateWaveLinkBodies(fastenerStandardParts);
                    Log.Info("Wave linking of all the parts are created...");

                    nxHelper.CreateMidSurfaces(facePairComps,offsetComps);
                    Log.Info("Mid surfaces created...");

                    nxHelper.CreateWasherImprint();
                    Log.Info("washer imprint created successfully...");
                }
            }
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            errorCode = 1;
            theUI.NXMessageBox.Show("SIM creation", NXMessageBox.DialogType.Error, ex.ToString());
        }
        finally
        {
            Log.Info("iPart is created successfully...");
            Log.Info("******************** END ********************");
            Logger.ShutDown();
        }
        nxHelper.DisplaySupress(UFConstants.UF_DISP_UNSUPPRESS_DISPLAY);
        nxHelper.WorkInProgress(Constants.STOP);
        SessionData.TheUi.NXMessageBox.Show("SIM creation", NXMessageBox.DialogType.Information,
            "FEM and SIM solution created");
       
        return errorCode;
    }
    
    //------------------------------------------------------------------------------
    //Callback Name: update_cb
    //------------------------------------------------------------------------------
    public int update_cb( NXOpen.BlockStyler.UIBlock block)
    {
        try
        {
            if(block == SolTypeLstBx)
            {
            //---------Enter your code here-----------
            }
            else if(block == FacePairMidSurfCompsSel)
            {
            //---------Enter your code here-----------
            }
            else if(block == OffsetMidSurfCompsSel)
            {
            //---------Enter your code here-----------
            }
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            theUI.NXMessageBox.Show("Block Styler", NXMessageBox.DialogType.Error, ex.ToString());
        }
        return 0;
    }
    
    //------------------------------------------------------------------------------
    //Callback Name: ok_cb
    //------------------------------------------------------------------------------
    public int ok_cb()
    {
        int errorCode = 0;
        try
        {
            errorCode = apply_cb();
            //---- Enter your callback code here -----
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            errorCode = 1;
            theUI.NXMessageBox.Show("Block Styler", NXMessageBox.DialogType.Error, ex.ToString());
        }
        return errorCode;
    }
    //------------------------------------------------------------------------------
    //ListBox specific callbacks
    //------------------------------------------------------------------------------
    //public int  AddCallback (NXOpen.BlockStyler.ListBox list_box)
    //{
    //}
    
    //public int  DeleteCallback(NXOpen.BlockStyler.ListBox list_box)
    //{
    //}
    
    //------------------------------------------------------------------------------
    
    //------------------------------------------------------------------------------
    //Function Name: GetBlockProperties
    //Returns the propertylist of the specified BlockID
    //------------------------------------------------------------------------------
    public PropertyList GetBlockProperties(string blockID)
    {
        PropertyList plist =null;
        try
        {
            plist = theDialog.GetBlockProperties(blockID);
        }
        catch (Exception ex)
        {
            //---- Enter your exception handling code here -----
            theUI.NXMessageBox.Show("Block Styler", NXMessageBox.DialogType.Error, ex.ToString());
        }
        return plist;
    }
    
}
