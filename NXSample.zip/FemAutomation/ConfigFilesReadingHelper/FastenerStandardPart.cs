﻿using Newtonsoft.Json;

namespace FemAutomation.ConfigFilesReadingHelper
{
    public class FastenerStandardPart
    {
        [JsonProperty("Descriptive Part Number")]
        public string PartNumber { get; set; }

        [JsonProperty("Nomenclature")]
        public string Nomenclature { get; set; }

        public FastenerStandardPart()
        {
            PartNumber = string.Empty;
            Nomenclature = string.Empty;
        }
    }
}