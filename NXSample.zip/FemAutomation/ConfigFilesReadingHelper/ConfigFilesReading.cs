﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using DataTable = System.Data.DataTable;

namespace FemAutomation.ConfigFilesReadingHelper
{
    public class ConfigFilesReading
    {
        string _configFolderDir;
        public List<FastenerStandardPart> FastenersAndStdParts;
        public static Logger Log = new Logger("Config File Reading");
        public ConfigFilesReading()
        {
            var executingAssemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            _configFolderDir = executingAssemblyPath + "\\" + Constants.CONFIG_DIR;
            FastenersAndStdParts = new List<FastenerStandardPart>(0);
        }

        public List<FastenerStandardPart> ReadFastenersAndStandardsConfigFile()
        {
            try
            {
                if (FastenersAndStdParts.Any())
                {
                    return FastenersAndStdParts;
                }

                string fastAndStdDbFileFullPath = Path.Combine(_configFolderDir, Constants.FASTENER_STANDARD_DB_FILE_NAME);
                if (!File.Exists(fastAndStdDbFileFullPath))
                {
                    return FastenersAndStdParts;
                }
                string bracketDbLText = File.ReadAllText(fastAndStdDbFileFullPath);
                FastenersAndStdParts = JsonConvert.DeserializeObject<List<FastenerStandardPart>>(bracketDbLText);
            }
            catch (Exception e)
            {
                Log.Error("Error in reading Fasteners and Standard Config Files...",e);
            }
            return FastenersAndStdParts;
        }
    }
}