﻿using System.Collections.Generic;

namespace FemAutomation
{
    public class Constants
    {
        public const string CONFIG_DIR = "Config";
        public const string FASTENER_STANDARD_DB_FILE_NAME = "FastenersAndStandardParts.json";
        public const int START = 0;
        public const int STOP = 1;

        public enum PartType
        {
            PipeOrTube =0,
            SheetMetal=1,
            CastingOrForging=2,
            Plastics=3
        }
        public enum MeshType
        {
            Mesh2D =0,
            Mesh3D=1
        }

        public enum MeshElementType
        {
            CTETRA4 = 0,
            CTETRA10 =1,
            CQUAD4=2,
            CQUAD8=3
        }

        public enum FaceType
        {
            Conical,
            Cylindrical,
            Planar,
            Undefined
        }
        public const string CTETRA4 = "CTETRA(4)";
        public const string CTETRA10 = "CTETRA(10)";
        public enum YesOrNo
        {
            Yes = 0,
            No =1
        }

        public enum Columns
        {
            PartNumber = 0,
            GeometryType = 1,
            MeshType = 2,
            Thickness = 3,
            MeshElementType = 4,
            Material = 5,
            SurfaceContact = 6

        }

        public const string PART_ID = "FEM_ID";
        public const string PARENT_PART_NO = "PARENT_PART_NO";
        public const string MATERIAL_ATTR_NAME = "j0Material2";
    }
}