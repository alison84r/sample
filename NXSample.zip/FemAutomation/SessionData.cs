﻿using NXOpen;
using NXOpen.UF;

namespace FemAutomation
{

    public class SessionData
    {
        public Session TheSession { get; set; }
        public UFSession TheUfSession { get; set; }
        public Part TheWorkPart { get; set; }
        public UI TheUi { get; set; }

        public SessionData()
        {
            Initialize();
        }

        /// <summary>
        /// Initialize the SiemensNX session data
        /// </summary>
        private void Initialize()
        {
            this.TheSession = Session.GetSession();
            this.TheUfSession = UFSession.GetUFSession();
            this.TheWorkPart = Session.GetSession().Parts.Work;
            this.TheUi = UI.GetUI();
        }
    }

}