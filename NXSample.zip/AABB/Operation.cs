﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AABB
{
    public static class Operation
    {
        public static bool IsRayIntersect(AabbTreeRay ray, AabbBox aabb, out double minPoint)
        {
            minPoint = double.Epsilon;
            var minX = aabb[0];
            var minY = aabb[1];
            var minZ = aabb[2];
            var maxX = aabb[3];
            var maxY = aabb[4];
            var maxZ = aabb[5];

            double t1 = (minX - ray.Origin.X) / ray.Direction.X;
            double t2 = (maxX - ray.Origin.X) / ray.Direction.X;
            double t3 = (minY - ray.Origin.Y) / ray.Direction.Y;
            double t4 = (maxY - ray.Origin.Y) / ray.Direction.Y;
            double t5 = (minZ - ray.Origin.Z) / ray.Direction.Z;
            double t6 = (maxZ - ray.Origin.Z) / ray.Direction.Z;

            double tmin = Math.Max(Math.Max(Math.Min(t1, t2), Math.Min(t3, t4)), Math.Min(t5, t6));
            double tmax = Math.Min(Math.Min(Math.Max(t1, t2), Math.Max(t3, t4)), Math.Max(t5, t6));

            // if tmax < 0, ray (line) is intersecting AABB, but the whole AABB is behind us
            if (tmax < 0)
            {
                //t = tmax;
                return false;
            }

            // if tmin > tmax, ray doesn't intersect AABB
            if (tmin > tmax)
            {
                //t = tmax;
                return false;
            }
            minPoint = tmin;
            return true;
        }

        public static bool IsRayIntersect(AabbTreeRay ray, AabbBox aabb)
        {
            //minPoint = double.Epsilon;
            var minX = aabb[0];
            var minY = aabb[1];
            var minZ = aabb[2];
            var maxX = aabb[3];
            var maxY = aabb[4];
            var maxZ = aabb[5];

            double t1 = (minX - ray.Origin.X) / ray.Direction.X;
            double t2 = (maxX - ray.Origin.X) / ray.Direction.X;
            double t3 = (minY - ray.Origin.Y) / ray.Direction.Y;
            double t4 = (maxY - ray.Origin.Y) / ray.Direction.Y;
            double t5 = (minZ - ray.Origin.Z) / ray.Direction.Z;
            double t6 = (maxZ - ray.Origin.Z) / ray.Direction.Z;

            double tmin = Math.Max(Math.Max(Math.Min(t1, t2), Math.Min(t3, t4)), Math.Min(t5, t6));
            double tmax = Math.Min(Math.Min(Math.Max(t1, t2), Math.Max(t3, t4)), Math.Max(t5, t6));

            // if tmax < 0, ray (line) is intersecting AABB, but the whole AABB is behind us
            if (tmax < 0)
            {
                //t = tmax;
                return false;
            }

            // if tmin > tmax, ray doesn't intersect AABB
            if (tmin > tmax)
            {
                //t = tmax;
                return false;
            }
            //minPoint = tmin;
            return true;
        }

        public static bool IntersectRay2(AabbBox box, AabbTreeRay ray)
        {
            //https://gamedev.stackexchange.com/questions/18436/most-efficient-aabb-vs-ray-collision-algorithms
            //double t = 0.0;
            // r.dir is unit direction vector of ray
            ray.Direction.X = 1.0f / ray.Direction.X;
            ray.Direction.Y = 1.0f / ray.Direction.Y;
            ray.Direction.Z = 1.0f / ray.Direction.Z;
            // lb is the corner of AABB with minimal coordinates - left bottom, rt is maximal corner
            // r.org is origin of ray
            double t1 = (box.min.X - ray.Origin.X) * ray.Direction.X;
            double t2 = (box.max.X - ray.Origin.X) * ray.Direction.X;
            double t3 = (box.min.Y - ray.Origin.Y) * ray.Direction.Y;
            double t4 = (box.max.Y - ray.Origin.Y) * ray.Direction.Y;
            double t5 = (box.min.Z - ray.Origin.Z) * ray.Direction.Z;
            double t6 = (box.max.Z - ray.Origin.Z) * ray.Direction.Z;

            double tmin = Math.Max(Math.Max(Math.Min(t1, t2), Math.Min(t3, t4)), Math.Min(t5, t6));
            double tmax = Math.Min(Math.Min(Math.Max(t1, t2), Math.Max(t3, t4)), Math.Max(t5, t6));

            // if tmax < 0, ray (line) is intersecting AABB, but the whole AABB is behind us
            if (tmax < 0)
            {
                //t = tmax;
                return true;
            }
            // if tmin < 0 then the ray origin is inside of the AABB and tmin is behind the start of the ray so tmax is the first intersection
            if (tmin < 0)
            {
                return true;
            }

            // if tmin > tmax, ray doesn't intersect AABB
            if (tmin > tmax)
            {
               // t = tmax;
                return false;
            }
            return true;
        }
        public static bool IntersectRayBox1(AabbBox box, AabbTreeRay ray)
        {
            var min = box.min;
            var max = box.max;
            double near = double.MinValue;
            double far = double.MaxValue;

            // X
            double t1 = min.X / ray.Direction.X;
            double t2 = max.Y / ray.Direction.X;
            double tMin = Math.Min(t1, t2);
            double tMax = Math.Max(t1, t2);
            if (tMin > near) near = tMin;
            if (tMax < far) far = tMax;
            if (near > far || far < 0)
            {
                //point1 = Vec3.zero;
                //point2 = Vec3.zero;
                return false;
            }

            // Y
            t1 = min.Y / ray.Direction.Y;
            t2 = max.Y / ray.Direction.Y;
            tMin = Math.Min(t1, t2);
            tMax = Math.Max(t1, t2);
            if (tMin > near) near = tMin;
            if (tMax < far) far = tMax;
            if (near > far || far < 0)
            {
                //point1 = Vec3.zero;
                //point2 = Vec3.zero;
                return false;
            }

            // Z
            t1 = min.Z / ray.Direction.Z;
            t2 = max.Z / ray.Direction.Z;
            tMin = Math.Min(t1, t2);
            tMax = Math.Max(t1, t2);
            if (tMin > near) near = tMin;
            if (tMax < far) far = tMax;
            if (near > far || far < 0)
            {
                //point1 = Vec3.zero;
                //point2 = Vec3.zero;
                return false;
            }

            //point1 = origin + direction * near;
            //point2 = origin + direction * far;
            return true;
        }

        // Given a ray and an aabb:
        // return t at which the ray intersects the aabb. 
        // return -1 if there is no intersection
        public static bool IntersectRayBox4(AabbBox aabb,AabbTreeRay ray)
        {
            double t1 = (aabb.min.X - ray.Origin.X) / ray.Direction.X;
            double t2 = (aabb.max.X - ray.Origin.X) / ray.Direction.X;
            double t3 = (aabb.min.Y - ray.Origin.Y) / ray.Direction.Y;
            double t4 = (aabb.max.Y - ray.Origin.Y) / ray.Direction.Y;
            double t5 = (aabb.min.Z - ray.Origin.Z) / ray.Direction.Z;
            double t6 = (aabb.max.Z - ray.Origin.Z) / ray.Direction.Z;

            double tmin = Math.Max(Math.Max(Math.Min(t1, t2), Math.Min(t3, t4)), Math.Min(t5, t6));
            double tmax = Math.Min(Math.Min(Math.Max(t1, t2), Math.Max(t3, t4)), Math.Max(t5, t6));

            // if tmax < 0, ray (line) is intersecting AABB, but whole AABB is behing us
            if (tmax < 0)
            {
                return false;
            }

            // if tmin > tmax, ray doesn't intersect AABB
            if (tmin > tmax)
            {
                return false;
            }

            if (tmin < 0d)
            {
                return true;
            }
            return true;
        }
        public static AabbBox MergeAabbBox(List<AabbBox> iAabbBoxes)
        {
            if (!iAabbBoxes.Any())
            {
                AabbBox emptyAabbBox = new AabbBox();
                return emptyAabbBox;
            }
            List<double> xCoord = new List<double>(0);
            List<double> yCoord = new List<double>(0);
            List<double> zCoord = new List<double>(0);
            foreach (AabbBox iAabbBox in iAabbBoxes)
            {
                xCoord.Add(iAabbBox.min.X);
                xCoord.Add(iAabbBox.max.X);
                yCoord.Add(iAabbBox.min.Y);
                yCoord.Add(iAabbBox.max.Y);
                zCoord.Add(iAabbBox.min.Z);
                zCoord.Add(iAabbBox.max.Z);
            }

            double minX = xCoord.Min();
            double maxX = xCoord.Max();

            double minY = yCoord.Min();
            double maxY = yCoord.Max();

            double minZ = zCoord.Min();
            double maxZ = zCoord.Max();

            Point3 min = new Point3(minX, minY, minZ);
            Point3 max = new Point3(maxX, maxY, maxZ);
            AabbBox mergedAabbBox = new AabbBox(min, max);

            return mergedAabbBox;
        }

        public static bool IsIntersectWith(AabbBox aabb1, AabbBox aabb2)
        {
            //if (x1Min <= x2Max && x2Min <= x1Max &&
            //    y1Min <= y2Max && y2Min <= y1Max &&
            //    z1Min <= z2Max && z2Min <= z1Max)
            if (aabb1.min != null && aabb1.max != null && aabb2.min != null && aabb2 != null)
            {
                bool isIntersect = (aabb1.min.X <= aabb2.max.X && aabb1.max.X >= aabb2.min.X) &&
                                   (aabb1.min.Y <= aabb2.max.Y && aabb1.max.Y >= aabb2.min.Y) &&
                                   (aabb1.min.Z <= aabb2.max.Z && aabb1.max.Z >= aabb2.min.Z);
                return isIntersect;
            }

            return false;

        }

        public static bool PointIsInAabb(double pX, double pY, double pZ, AabbBox aabb)
        {
            pX = Math.Round(pX, 2, MidpointRounding.AwayFromZero);
            pY = Math.Round(pY, 2, MidpointRounding.AwayFromZero);
            pZ = Math.Round(pZ, 2, MidpointRounding.AwayFromZero);
            double maxX = Math.Round(aabb.max.X, 2, MidpointRounding.AwayFromZero);
            double maxY = Math.Round(aabb.max.Y, 2, MidpointRounding.AwayFromZero);
            double maxZ = Math.Round(aabb.max.Z, 2, MidpointRounding.AwayFromZero);
            double minX = Math.Round(aabb.min.X, 2, MidpointRounding.AwayFromZero);
            double minY = Math.Round(aabb.min.Y, 2, MidpointRounding.AwayFromZero);
            double minZ = Math.Round(aabb.min.Z, 2, MidpointRounding.AwayFromZero);
            bool xPass = false;
            bool yPass = false;
            bool zPass = false;

            if (pX <= maxX && pX >= minX)
            {
                xPass = true;
            }

            if (pY <= maxY && pY >= minY)
            {
                yPass = true;
            }

            if (pZ <= maxZ && pZ >= minZ)
            {
                zPass = true;
            }

            if (xPass && yPass && zPass)
            {
                return true;
            }

            return false;
        }

        public static AabbBox ScaleBoundingBox(double scale, AabbBox b)
        {
            //Get delta values
            double dx = Math.Abs(b.max.X - b.min.X);
            double dy = Math.Abs(b.max.Y - b.min.Y);
            double dz = Math.Abs(b.max.Z - b.min.Z);

            //get new delta values
            double newdx = dx * scale;
            double newdy = dy * scale;
            double newdz = dz * scale;

            AabbBox aabbBox = new AabbBox(
                //new min vector
                //oldvalue + removed delta, of course divided by 2(half for max and half for min).
                new Point3(b.min.X + ((dx - newdx) / 2),
                    b.min.Y + ((dy - newdy) / 2),
                    b.min.Z + ((dz - newdz) / 2)), //new max vector
                //oldvalue - removed delta, of course divided by 2(half for max and half for min).
                new Point3(b.max.X - ((dx - newdx) / 2),
                    b.max.Y - ((dy - newdy) / 2),
                    b.max.Z - ((dz - newdz) / 2)));

            return aabbBox;
        }

        public static bool PointIsInAabb1(double pX, double pY, double pZ, AabbBox aabb,bool scaleAabb = false,double scalePct = 0.1)
        {
            AabbBox orgAabb = new AabbBox();
            orgAabb.min = aabb.min;
            orgAabb.max = aabb.max;



            if (scaleAabb)
            {
                aabb.min.X -= scalePct * (aabb.max.X - aabb.min.X);
                aabb.max.X += scalePct * (aabb.max.X - aabb.min.X);
                aabb.min.Y -= scalePct * (aabb.max.Y - aabb.min.Y);
                aabb.max.Y += scalePct * (aabb.max.Y - aabb.min.Y);
                aabb.min.Z -= scalePct * (aabb.max.Z - aabb.min.Z);
                aabb.max.Z += scalePct * (aabb.max.Z - aabb.min.Z);
            }

            AabbBox scaleBoundingBox = ScaleBoundingBox(scalePct, aabb);

            pX = Math.Round(pX, 2, MidpointRounding.AwayFromZero);
            pY = Math.Round(pY, 2, MidpointRounding.AwayFromZero);
            pZ = Math.Round(pZ, 2, MidpointRounding.AwayFromZero);
            double maxX = Math.Round(aabb.max.X, 2, MidpointRounding.AwayFromZero);
            double maxY = Math.Round(aabb.max.Y, 2, MidpointRounding.AwayFromZero);
            double maxZ = Math.Round(aabb.max.Z, 2, MidpointRounding.AwayFromZero);
            double minX = Math.Round(aabb.min.X, 2, MidpointRounding.AwayFromZero);
            double minY = Math.Round(aabb.min.Y, 2, MidpointRounding.AwayFromZero);
            double minZ = Math.Round(aabb.min.Z, 2, MidpointRounding.AwayFromZero);
            bool xPass = false;
            bool yPass = false;
            bool zPass = false;

           
            if (pX <= maxX && pX >= minX)
            {
                xPass = true;
            }

            if (pY <= maxY && pY >= minY)
            {
                yPass = true;
            }

            if (pZ <= maxZ && pZ >= minZ)
            {
                zPass = true;
            }

            if (xPass && yPass && zPass)
            {
                return true;
            }

            return false;
        }
    }
}