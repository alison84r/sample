﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AABB
{
    public class AabbTreeRay
    {
        public Point3 Origin;    // v3
        public Vector3 Direction; // v3
    }
}
