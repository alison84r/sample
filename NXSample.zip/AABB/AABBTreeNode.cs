﻿using System;

namespace AABB
{
    //
    // tree node
    //
    public class AabbTreeNode
    {
        static int _version = 1;
        public int EscapeNodeOffset;
        public AabbExternalNode ExternalNode; // user data
        public AabbBox Extents; // bounding box

        public AabbTreeNode(AabbBox extents, int escapeNodeOffset, AabbExternalNode externalNode)
        {
            this.EscapeNodeOffset = escapeNodeOffset;
            this.ExternalNode = externalNode;
            this.Extents = extents;
        }

        public bool IsLeaf()
        {
            return this.ExternalNode != null;
        }

        public void Reset(double minX, double minY, double minZ,
            double maxX, double maxY, double maxZ,
            int escapeNodeOffset, AabbExternalNode externalNode = null)
        {
            this.EscapeNodeOffset = escapeNodeOffset;
            this.ExternalNode = externalNode;
            var oldExtents = this.Extents;
            oldExtents[0] = minX;
            oldExtents[1] = minY;
            oldExtents[2] = minZ;
            oldExtents[3] = maxX;
            oldExtents[4] = maxY;
            oldExtents[5] = maxZ;
        }

        public void Clear()
        {
            this.EscapeNodeOffset = 1;
            this.ExternalNode = null;
            var oldExtents = this.Extents;
            var maxNumber = double.MaxValue;
            oldExtents[0] = maxNumber;
            oldExtents[1] = maxNumber;
            oldExtents[2] = maxNumber;
            oldExtents[3] = -maxNumber;
            oldExtents[4] = -maxNumber;
            oldExtents[5] = -maxNumber;
        }
    }

    public class AabbExternalNode
    {
        public int SpatialIndex { get; set; }
        public object Data { get; set; }

        public void Print()
        {
            Console.WriteLine($"Node: {Data}");
        }
    }

    public class AabbBox
    {
        private double[] _box = new double[6];
        public double this[int index]
        {
            get { return _box[index]; }
            set { _box[index] = value; }
        }

        public Point3 min;
        public Point3 max;

        public AabbBox()
        {
            for (int i = 0; i < 6; i++)
            {
                _box[i] = 0;
            }

            
        }

        public AabbBox(Point3 min, Point3 max)
        {
            _box[0] = min.X;
            _box[1] = min.Y;
            _box[2] = min.Z;
            _box[3] = max.X;
            _box[4] = max.Y;
            _box[5] = max.Z;

            this.min = min;
            this.max = max;
        }
    }
}
