﻿using System.Collections.Generic;

namespace AABB.Sort
{
    class AabbTreeNodeSortHighQuality : AabbTreeNodeSortBase
    {
        double GetkeyXfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return (extents[0] + extents[3]);
        }

        double GetkeyYfn(AabbTreeNode node) 
        {
            var extents = node.Extents;
            return (extents[1] + extents[4]);
        }

        double GetkeyZfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return (extents[2] + extents[5]);
        }

        double GetkeyXZfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return (extents[0] + extents[2] + extents[3] + extents[5]);
        }

        double GetkeyZXfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return (extents[0] - extents[2] + extents[3] - extents[5]);
        }

        double GetreversekeyXfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return -(extents[0] + extents[3]);
        }

        double GetreversekeyYfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return -(extents[1] + extents[4]);
        }

        double GetreversekeyZfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return -(extents[2] + extents[5]);
        }

        double GetreversekeyXZfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return -(extents[0] + extents[2] + extents[3] + extents[5]);
        }

        double GetreversekeyZXfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return -(extents[0] - extents[2] + extents[3] - extents[5]);
        }

        protected override void SortNodesRecursive(List<AabbTreeNode> nodes, int startIndex, int endIndex, int axis)
        {
            var splitNodeIndex = ((startIndex + endIndex) >> 1);

            NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyXfn);
            var sahX = (CalculateSah(nodes, startIndex, splitNodeIndex) +
                CalculateSah(nodes, splitNodeIndex, endIndex));

            NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyYfn);
            var sahY = (CalculateSah(nodes, startIndex, splitNodeIndex) +
                CalculateSah(nodes, splitNodeIndex, endIndex));

            NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyZfn);
            var sahZ = (CalculateSah(nodes, startIndex, splitNodeIndex) +
                CalculateSah(nodes, splitNodeIndex, endIndex));

            NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyXZfn);
            var sahXz = (CalculateSah(nodes, startIndex, splitNodeIndex) +
                CalculateSah(nodes, splitNodeIndex, endIndex));

            NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyZXfn);
            var sahZx = (CalculateSah(nodes, startIndex, splitNodeIndex) +
                CalculateSah(nodes, splitNodeIndex, endIndex));

            if (sahX <= sahY &&
                sahX <= sahZ &&
                sahX <= sahXz &&
                sahX <= sahZx)
            {
                if (Reverse)
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetreversekeyXfn);
                }
                else
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyXfn);
                }
            }
            else if (sahZ <= sahY &&
                sahZ <= sahXz &&
                sahZ <= sahZx)
            {
                if (Reverse)
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetreversekeyZfn);
                }
                else
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyZfn);
                }
            }
            else if (sahY <= sahXz &&
                sahY <= sahZx)
            {
                if (Reverse)
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetreversekeyYfn);
                }
                else
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyYfn);
                }
            }
            else if (sahXz <= sahZx)
            {
                if (Reverse)
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetreversekeyXZfn);
                }
                else
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyXZfn);
                }
            }
            else //if (sahZX <= sahXZ)
            {
                if (Reverse)
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetreversekeyZXfn);
                }
                else
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyZXfn);
                }
            }

            Reverse = !Reverse;

            if ((startIndex + NumNodesLeaf) < splitNodeIndex)
            {
                SortNodesRecursive(nodes, startIndex, splitNodeIndex, axis);
            }

            if ((splitNodeIndex + NumNodesLeaf) < endIndex)
            {
                SortNodesRecursive(nodes, splitNodeIndex, endIndex, axis);
            }
        }

        double CalculateSah(List<AabbTreeNode> buildNodes, int startIndex, int endIndex)
        {
            AabbTreeNode buildNode;
            AabbBox extents;
            double minX, minY, minZ, maxX, maxY, maxZ;

            buildNode = buildNodes[startIndex];
            extents = buildNode.Extents;
            minX = extents[0];
            minY = extents[1];
            minZ = extents[2];
            maxX = extents[3];
            maxY = extents[4];
            maxZ = extents[5];

            for (var n = (startIndex + 1); n < endIndex; n += 1)
            {
                buildNode = buildNodes[n];
                extents = buildNode.Extents;
                /*jshint white: false*/
                if (minX > extents[0]) { minX = extents[0]; }
                if (minY > extents[1]) { minY = extents[1]; }
                if (minZ > extents[2]) { minZ = extents[2]; }
                if (maxX < extents[3]) { maxX = extents[3]; }
                if (maxY < extents[4]) { maxY = extents[4]; }
                if (maxZ < extents[5]) { maxZ = extents[5]; }
                /*jshint white: true*/
            }

            return ((maxX - minX) + (maxY - minY) + (maxZ - minZ));
        }
    }
}
