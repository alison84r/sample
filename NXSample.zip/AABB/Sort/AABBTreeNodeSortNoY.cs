﻿using System.Collections.Generic;

namespace AABB.Sort
{
    class AabbTreeNodeSortNoY : AabbTreeNodeSortBase
    {
        double GetkeyXfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return (extents[0] + extents[3]);
        }

        double GetkeyZfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return (extents[2] + extents[5]);
        }

        double GetreversekeyXfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return -(extents[0] + extents[3]);
        }

        double GetreversekeyZfn(AabbTreeNode node)
        {
            var extents = node.Extents;
            return -(extents[2] + extents[5]);
        }

        protected override void SortNodesRecursive(List<AabbTreeNode> nodes, int startIndex, int endIndex, int axis)
        {
            var splitNodeIndex = ((startIndex + endIndex) >> 1);

            if (axis == 0)
            {
                if (Reverse)
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetreversekeyXfn);
                }
                else
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyXfn);
                }
            }
            else //if (axis === 2)
            {
                if (Reverse)
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetreversekeyZfn);
                }
                else
                {
                    NthElement(nodes, startIndex, splitNodeIndex, endIndex, GetkeyZfn);
                }
            }

            if (axis == 0)
            {
                axis = 2;
            }
            else //if (axis === 2)
            {
                axis = 0;
            }

            Reverse = !Reverse;

            if ((startIndex + NumNodesLeaf) < splitNodeIndex)
            {
                SortNodesRecursive(nodes, startIndex, splitNodeIndex, axis);
            }

            if ((splitNodeIndex + NumNodesLeaf) < endIndex)
            {
                SortNodesRecursive(nodes, splitNodeIndex, endIndex, axis);
            }
        }
    }
}
